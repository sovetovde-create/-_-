package com.example.engine

import com.example.model.Block
import com.example.model.BlockType
import kotlinx.coroutines.delay
import java.util.Random

enum class LogType {
    STDOUT, STDERR, INFO, PROMPT
}

data class ConsoleOutput(
    val text: String,
    val type: LogType = LogType.STDOUT
)

class PythonSimulator(
    private val onOutput: (ConsoleOutput) -> Unit,
    private val onPromptInput: suspend (prompt: String) -> String
) {
    private val variables = mutableMapOf<String, Any?>()
    private val functions = mutableMapOf<String, Pair<List<String>, List<Block>>>()
    private val random = Random()
    private var isTerminated = false
    private var stepCount = 0
    private val maxSteps = 20000

    suspend fun execute(blocks: List<Block>) {
        variables.clear()
        functions.clear()
        isTerminated = false
        stepCount = 0

        onOutput(ConsoleOutput("▶ Программа запущена...", LogType.INFO))
        val startTime = System.currentTimeMillis()

        try {
            executeBlockList(blocks)
            val elapsed = System.currentTimeMillis() - startTime
            onOutput(ConsoleOutput("\n✔ Завершено успешно (${elapsed} мс)", LogType.INFO))
        } catch (e: InterruptedException) {
            onOutput(ConsoleOutput("\n⏹ Остановлено пользователем", LogType.INFO))
        } catch (e: Exception) {
            onOutput(ConsoleOutput("\n❌ Ошибка программы: ${e.message ?: "Неизвестная ошибка"}", LogType.STDERR))
        }
    }

    fun terminate() {
        isTerminated = true
    }

    private suspend fun executeBlockList(blocks: List<Block>): ReturnSignal? {
        for (block in blocks) {
            if (isTerminated) throw InterruptedException()
            stepCount++
            if (stepCount > maxSteps) {
                throw RuntimeException("Слишком много шагов выполнения (возможно бесконечный цикл)")
            }

            val signal = executeSingleBlock(block)
            if (signal != null) {
                return signal
            }
        }
        return null
    }

    private sealed class ReturnSignal {
        data class ReturnValue(val value: Any?) : ReturnSignal()
        object Break : ReturnSignal()
        object Continue : ReturnSignal()
    }

    private suspend fun executeSingleBlock(block: Block): ReturnSignal? {
        when (block.type) {
            // 1. Диалог
            BlockType.ASK_INPUT -> {
                val varName = block.getField("var", "ответ").trim()
                val promptVal = evalSlotOrExpr(block, "question", "")
                val prompt = cleanQuotes(promptVal?.toString() ?: "")
                onOutput(ConsoleOutput(prompt, LogType.PROMPT))
                val input = onPromptInput(prompt)
                variables[varName] = input
            }

            BlockType.ASK_NUMBER -> {
                val varName = block.getField("var", "число").trim()
                val promptVal = evalSlotOrExpr(block, "question", "")
                val prompt = cleanQuotes(promptVal?.toString() ?: "")
                onOutput(ConsoleOutput(prompt, LogType.PROMPT))
                val input = onPromptInput(prompt)
                val number = input.trim().toLongOrNull() ?: input.trim().toDoubleOrNull() ?: 0L
                variables[varName] = number
            }

            BlockType.SAY -> {
                val value = evalSlotOrExpr(block, "text", "")
                onOutput(ConsoleOutput(value?.toString() ?: "", LogType.STDOUT))
            }

            BlockType.SAY_PHRASE -> {
                val template = block.getField("template", "")
                val interpolated = interpolateTemplate(template)
                onOutput(ConsoleOutput(interpolated, LogType.STDOUT))
            }

            BlockType.CLEAR_SCREEN -> {
                onOutput(ConsoleOutput("--- [Очистка экрана] ---", LogType.INFO))
            }

            // 2. Переменные
            BlockType.SET_VARIABLE -> {
                val varName = block.getField("var", "x").trim()
                val evaluated = evalSlotOrExpr(block, "value", "0")
                variables[varName] = evaluated
            }

            BlockType.CHANGE_BY -> {
                val varName = block.getField("var", "x").trim()
                val current = variables[varName] ?: 0
                val delta = evalSlotOrExpr(block, "value", "1")
                val updated: Any = when {
                    current is Number && delta is Number -> addNumbers(current, delta)
                    else -> current.toString() + delta.toString()
                }
                variables[varName] = updated
            }

            BlockType.CALCULATE_INTO -> {
                val varName = block.getField("var", "итог").trim()
                val left = evalSlotOrExpr(block, "left", "0")
                val right = evalSlotOrExpr(block, "right", "0")
                val op = block.getField("op", "+").trim()
                val result = when (op) {
                    "+" -> if (left is Number && right is Number) addNumbers(left, right) else "$left$right"
                    "-" -> subtractNumbers(left, right)
                    "*" -> multiplyNumbers(left, right)
                    "/" -> divideNumbers(left, right)
                    "//" -> intDivideNumbers(left, right)
                    "%" -> moduloNumbers(left, right)
                    else -> 0
                }
                variables[varName] = result
            }

            // 3. Управление
            BlockType.IF_SIMPLE -> {
                val condition = resolveCondition(block, "condition")
                if (evalCondition(condition)) {
                    val sig = executeBlockList(block.children)
                    if (sig != null) return sig
                }
            }

            BlockType.IF_ELSE_SIMPLE -> {
                val condition = resolveCondition(block, "condition")
                if (evalCondition(condition)) {
                    val sig = executeBlockList(block.children)
                    if (sig != null) return sig
                } else {
                    val sig = executeBlockList(block.secondaryChildren)
                    if (sig != null) return sig
                }
            }

            BlockType.REPEAT_TIMES -> {
                val varName = block.getField("var", "i").trim()
                val times = (evalSlotOrExpr(block, "times", "5") as? Number)?.toLong() ?: 5L
                for (i in 0 until times) {
                    if (isTerminated) throw InterruptedException()
                    variables[varName] = i
                    val sig = executeBlockList(block.children)
                    if (sig is ReturnSignal.Break) break
                    if (sig is ReturnSignal.ReturnValue) return sig
                }
            }

            BlockType.WHILE_LOOP -> {
                while (true) {
                    if (isTerminated) throw InterruptedException()
                    val cond = resolveCondition(block, "condition")
                    if (!evalCondition(cond)) break
                    stepCount++
                    if (stepCount > maxSteps) {
                        throw RuntimeException("Бесконечный цикл: превышен лимит шагов")
                    }
                    val sig = executeBlockList(block.children)
                    if (sig is ReturnSignal.Break) break
                    if (sig is ReturnSignal.ReturnValue) return sig
                }
            }

            BlockType.FOR_EACH_ITEM -> {
                val itemVar = block.getField("item", "элемент").trim()
                val collection = evalSlotOrExpr(block, "list", "[]")
                val items: List<Any?> = when (collection) {
                    is List<*> -> collection
                    is String -> collection.map { it.toString() }
                    else -> emptyList()
                }
                for (it in items) {
                    if (isTerminated) throw InterruptedException()
                    variables[itemVar] = it
                    val sig = executeBlockList(block.children)
                    if (sig is ReturnSignal.Break) break
                    if (sig is ReturnSignal.ReturnValue) return sig
                }
            }

            BlockType.WAIT_SECONDS -> {
                val sec = (evalSlotOrExpr(block, "seconds", "1") as? Number)?.toDouble() ?: 1.0
                delay((sec * 1000).toLong().coerceIn(10, 10000))
            }

            BlockType.STOP_LOOP -> return ReturnSignal.Break
            BlockType.NEXT_ROUND -> return ReturnSignal.Continue
            BlockType.STOP_ALL -> {
                onOutput(ConsoleOutput("Программа остановлена блоком Завершить", LogType.INFO))
                isTerminated = true
                throw InterruptedException()
            }

            // 4. Текст
            BlockType.TEXT_TO_UPPER -> {
                val v = block.getField("var", "текст").trim()
                val saveTo = block.getField("save_to", "громкий").trim()
                val str = variables[v]?.toString() ?: ""
                variables[saveTo] = str.uppercase()
            }

            BlockType.TEXT_TO_LOWER -> {
                val v = block.getField("var", "текст").trim()
                val saveTo = block.getField("save_to", "тихий").trim()
                val str = variables[v]?.toString() ?: ""
                variables[saveTo] = str.lowercase()
            }

            BlockType.TEXT_REPLACE -> {
                val targetVar = block.getField("target", "текст").trim()
                val oldVal = cleanQuotes(block.getField("old", ""))
                val newVal = cleanQuotes(block.getField("new", ""))
                val saveTo = block.getField("save_to", "новый_текст").trim()
                val src = variables[targetVar]?.toString() ?: ""
                variables[saveTo] = src.replace(oldVal, newVal)
            }

            // 5. Списки
            BlockType.CREATE_LIST -> {
                val varName = block.getField("var", "числа").trim()
                val itemsRaw = block.getField("items", "")
                val list = if (itemsRaw.isBlank()) {
                    mutableListOf<Any?>()
                } else {
                    splitArguments(itemsRaw).map { evalExpression(it) }.toMutableList()
                }
                variables[varName] = list
            }

            BlockType.ADD_TO_LIST -> {
                val listName = block.getField("list", "числа").trim()
                val item = evalSlotOrExpr(block, "item", "0")
                val list = variables[listName] as? MutableList<Any?>
                if (list != null) {
                    list.add(item)
                } else {
                    variables[listName] = mutableListOf(item)
                }
            }

            BlockType.GET_FROM_LIST -> {
                val listName = block.getField("list", "числа").trim()
                val index = (evalSlotOrExpr(block, "index", "0") as? Number)?.toInt() ?: 0
                val saveTo = block.getField("save_to", "элемент").trim()
                val list = variables[listName] as? List<*>
                val value = if (list != null && index >= 0 && index < list.size) list[index] else null
                variables[saveTo] = value
            }

            BlockType.REMOVE_FROM_LIST -> {
                val listName = block.getField("list", "числа").trim()
                val item = evalSlotOrExpr(block, "item", "0")
                val list = variables[listName] as? MutableList<Any?>
                list?.remove(item)
            }

            BlockType.REVERSE_LIST -> {
                val listName = block.getField("list", "числа").trim()
                val list = variables[listName] as? MutableList<Any?>
                list?.reverse()
            }

            // 6. Функции
            BlockType.CUSTOM_COMMAND_DEF -> {
                val name = block.getField("name", "команда").trim()
                val params = block.getField("params", "")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                functions[name] = Pair(params, block.children)
            }

            BlockType.CUSTOM_COMMAND_RUN -> {
                val call = block.getField("call", "").trim()
                evalCall(call)
            }

            BlockType.GIVE_RESULT -> {
                val retVal = evalSlotOrExpr(block, "value", "")
                return ReturnSignal.ReturnValue(retVal)
            }

            // 7. Библиотеки и Расширения
            BlockType.IMPORT_LIBRARY -> {
                val libId = block.getField("lib", "neural_net")
                val name = block.getField("name", libId)
                onOutput(ConsoleOutput("📦 Подключено дополнение: $name", LogType.INFO))
            }

            // Нейросети
            BlockType.NN_CREATE_MODEL -> {
                val varName = block.getField("var", "нейросеть").trim()
                val inputs = block.getField("inputs", "4")
                val hidden = block.getField("hidden", "16")
                val outputs = block.getField("outputs", "2")
                variables[varName] = mapOf("type" to "Sequential", "in" to inputs, "hidden" to hidden, "out" to outputs)
                onOutput(ConsoleOutput("🧠 [Нейросеть] Модель '$varName' создана ($inputs входов -> $hidden скрытых -> $outputs выходов)", LogType.INFO))
            }
            BlockType.NN_TRAIN_EPOCHS -> {
                val m = block.getField("model", "нейросеть").trim()
                val epochs = block.getField("epochs", "10").toIntOrNull() ?: 10
                val lr = block.getField("lr", "0.01")
                onOutput(ConsoleOutput("🧠 [Нейросеть] Старт обучения '$m' на $epochs эпох (lr=$lr)...", LogType.INFO))
                delay(120)
                onOutput(ConsoleOutput("   ▶ Эпоха 1/$epochs  | Loss: 0.6124 | Точность: 64.2%", LogType.STDOUT))
                delay(120)
                val mid = (epochs / 2).coerceAtLeast(2)
                onOutput(ConsoleOutput("   ▶ Эпоха $mid/$epochs | Loss: 0.1450 | Точность: 91.8%", LogType.STDOUT))
                delay(120)
                onOutput(ConsoleOutput("   ▶ Эпоха $epochs/$epochs | Loss: 0.0182 | Точность: 99.4%", LogType.STDOUT))
                onOutput(ConsoleOutput("✔ [Нейросеть] Обучение успешно завершено! Веса сохранены.", LogType.INFO))
            }
            BlockType.NN_PREDICT -> {
                val m = block.getField("model", "нейросеть").trim()
                val inputVal = block.getField("input", "[0.5, 0.2, 0.9, 0.1]")
                val saveTo = block.getField("save_to", "ответ").trim()
                val prediction = listOf(0.984, 0.016)
                variables[saveTo] = prediction
                onOutput(ConsoleOutput("🧠 [Нейросеть] Предсказание для $inputVal: Класс 0 (98.4%) -> $saveTo = $prediction", LogType.STDOUT))
            }
            BlockType.NN_CALC_LOSS -> {
                val saveTo = block.getField("save_to", "ошибка").trim()
                val loss = 0.0182
                variables[saveTo] = loss
                onOutput(ConsoleOutput("🧠 [Нейросеть] Ошибка MSE Loss = $loss", LogType.STDOUT))
            }

            // Сеть и API
            BlockType.API_GET_REQUEST -> {
                val url = cleanQuotes(evalSlotOrExpr(block, "url", "")?.toString() ?: "")
                val v = block.getField("var", "ответ_сервера").trim()
                onOutput(ConsoleOutput("🌐 [HTTP GET] Отправка запроса к $url...", LogType.INFO))
                delay(150)
                val responseData = mapOf("status" to 200, "ip" to "178.62.204.15", "city" to "Moscow", "country" to "RU", "ok" to true)
                variables[v] = responseData
                onOutput(ConsoleOutput("🌐 [HTTP 200 OK] Получен JSON ответ: $responseData", LogType.STDOUT))
            }
            BlockType.API_POST_JSON -> {
                val url = cleanQuotes(evalSlotOrExpr(block, "url", "")?.toString() ?: "")
                val v = block.getField("var", "ответ").trim()
                val data = block.getField("data", "{}")
                onOutput(ConsoleOutput("🌐 [HTTP POST] Отправка данных на $url (body: $data)...", LogType.INFO))
                delay(150)
                variables[v] = mapOf("status" to 201, "message" to "Saved successfully")
                onOutput(ConsoleOutput("🌐 [HTTP 201 Created] Данные успешно приняты сервером", LogType.STDOUT))
            }
            BlockType.API_GET_MY_IP -> {
                val v = block.getField("var", "мой_ip").trim()
                val myIp = "178.62.204.15"
                variables[v] = myIp
                onOutput(ConsoleOutput("🌐 [IP Service] Ваш публичный IP: $myIp", LogType.STDOUT))
            }
            BlockType.API_PARSE_FIELD -> {
                val jv = block.getField("json_var", "ответ_сервера").trim()
                val rawF = evalSlotOrExpr(block, "field", "")?.toString() ?: "ip"
                val f = cleanQuotes(rawF)
                val saveTo = block.getField("save_to", "ip_адрес").trim()
                val obj = variables[jv]
                val extracted = when (obj) {
                    is Map<*, *> -> obj[f] ?: obj[f.lowercase()] ?: "178.62.204.15"
                    else -> "178.62.204.15"
                }
                variables[saveTo] = extracted
                onOutput(ConsoleOutput("🌐 [JSON] Извлечено '$f' = $extracted (сохранено в $saveTo)", LogType.STDOUT))
            }

            // Случайность
            BlockType.RANDOM_INT_RANGE -> {
                val from = (evalSlotOrExpr(block, "from", "1") as? Number)?.toInt() ?: 1
                val to = (evalSlotOrExpr(block, "to", "100") as? Number)?.toInt() ?: 100
                val v = block.getField("var", "случайное").trim()
                val res = if (to >= from) random.nextInt(to - from + 1) + from else from
                variables[v] = res
            }
            BlockType.RANDOM_CHOICE_ITEM -> {
                val listName = block.getField("list", "числа").trim()
                val v = block.getField("var", "выбор").trim()
                val list = variables[listName] as? List<*>
                val item = if (!list.isNullOrEmpty()) list[random.nextInt(list.size)] else null
                variables[v] = item
            }
            BlockType.RANDOM_SHUFFLE_LIST -> {
                val listName = block.getField("list", "числа").trim()
                val list = (variables[listName] as? List<*>)?.toMutableList()
                if (list != null) {
                    list.shuffle()
                    variables[listName] = list
                }
            }
            BlockType.RANDOM_FLOAT_01 -> {
                val v = block.getField("var", "дробь").trim()
                variables[v] = random.nextDouble()
            }

            // OS & Sys
            BlockType.OS_LIST_FILES -> {
                val v = block.getField("var", "файлы").trim()
                val files = listOf("main.py", "model.pt", "dataset.csv", "заметка.txt")
                variables[v] = files
                onOutput(ConsoleOutput("💻 [os.listdir] Файлы в каталоге: $files", LogType.STDOUT))
            }
            BlockType.OS_CREATE_FOLDER -> {
                val p = cleanQuotes(block.getField("path", "новая_папка"))
                onOutput(ConsoleOutput("💻 [os.mkdir] Создана папка: $p", LogType.INFO))
            }
            BlockType.OS_GET_SYSTEM -> {
                val v = block.getField("var", "система").trim()
                val osName = "Android Linux (POSIX)"
                variables[v] = osName
                onOutput(ConsoleOutput("💻 [os.name] ОС: $osName", LogType.STDOUT))
            }
            BlockType.OS_EXIT_APP -> {
                onOutput(ConsoleOutput("💻 [sys.exit] Завершение работы программы по команде", LogType.INFO))
                terminate()
            }

            // Time & Date
            BlockType.TIME_SLEEP_MS -> {
                val ms = block.getField("ms", "500").toLongOrNull() ?: 500L
                delay(ms.coerceIn(20L, 3000L))
            }
            BlockType.TIME_CURRENT_TIMESTAMP -> {
                val v = block.getField("var", "время_сек").trim()
                variables[v] = System.currentTimeMillis() / 1000L
            }
            BlockType.TIME_FORMATTED_DATE -> {
                val v = block.getField("var", "дата").trim()
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                val nowStr = sdf.format(java.util.Date())
                variables[v] = nowStr
                onOutput(ConsoleOutput("⏰ [datetime] Текущее время: $nowStr", LogType.STDOUT))
            }
            BlockType.TIME_BENCHMARK -> {
                val t0 = System.currentTimeMillis()
                val sig = executeBlockList(block.children)
                val dt = System.currentTimeMillis() - t0
                onOutput(ConsoleOutput("⏰ [Benchmark] Время выполнения блока: ${dt} мс", LogType.INFO))
                if (sig != null) return sig
            }

            // Math & Stats
            BlockType.MATH_SQRT -> {
                val num = (evalSlotOrExpr(block, "num", "16") as? Number)?.toDouble() ?: 16.0
                val v = block.getField("var", "корень").trim()
                variables[v] = kotlin.math.sqrt(num)
            }
            BlockType.MATH_POW -> {
                val num = (evalSlotOrExpr(block, "num", "2") as? Number)?.toDouble() ?: 2.0
                val p = (evalSlotOrExpr(block, "power", "8") as? Number)?.toDouble() ?: 8.0
                val v = block.getField("var", "результат").trim()
                variables[v] = Math.pow(num, p)
            }
            BlockType.MATH_TRIG_SIN_COS -> {
                val fn = block.getField("func", "sin").trim()
                val a = (evalSlotOrExpr(block, "angle", "0") as? Number)?.toDouble() ?: 0.0
                val v = block.getField("var", "синус").trim()
                val res = when (fn.lowercase()) {
                    "cos" -> Math.cos(a)
                    "tan" -> Math.tan(a)
                    else -> Math.sin(a)
                }
                variables[v] = res
            }
            BlockType.MATH_CONSTANTS -> {
                val c = block.getField("const", "pi").trim()
                val v = block.getField("var", "число_пи").trim()
                variables[v] = if (c.contains("e")) Math.E else Math.PI
            }
            BlockType.STAT_MEAN_MEDIAN -> {
                val l = block.getField("list", "числа").trim()
                val list = variables[l] as? List<*>
                val nums = list?.mapNotNull { (it as? Number)?.toDouble() ?: it?.toString()?.toDoubleOrNull() } ?: listOf(10.0, 20.0, 30.0)
                val v = block.getField("var", "среднее").trim()
                val avg = if (nums.isNotEmpty()) nums.average() else 0.0
                variables[v] = avg
                onOutput(ConsoleOutput("📊 [Статистика] Среднее значение списка = $avg", LogType.STDOUT))
            }

            // Turtle Graphics
            BlockType.TURTLE_FORWARD, BlockType.TURTLE_TURN, BlockType.TURTLE_PEN_UP_DOWN, BlockType.TURTLE_SET_COLOR -> {
                val details = block.fields.entries.joinToString(", ") { "${it.key}: ${it.value}" }
                onOutput(ConsoleOutput("🐢 [Черепашка] ${block.type.displayName} ($details)", LogType.STDOUT))
            }

            // SQLite
            BlockType.SQLITE_CONNECT -> {
                val db = cleanQuotes(block.getField("db", "app.db"))
                val v = block.getField("var", "база").trim()
                variables[v] = "<SQLiteConnection '$db'>"
                onOutput(ConsoleOutput("💾 [SQLite] Успешно подключена база данных '$db'", LogType.INFO))
            }
            BlockType.SQLITE_EXECUTE -> {
                val sql = cleanQuotes(block.getField("sql", ""))
                onOutput(ConsoleOutput("💾 [SQLite] Выполнен SQL запрос: $sql", LogType.STDOUT))
            }
            BlockType.SQLITE_FETCH_ALL -> {
                val v = block.getField("var", "строки").trim()
                val sampleRows = listOf(
                    listOf(1, "Алексей", "Москва"),
                    listOf(2, "Мария", "Санкт-Петербург")
                )
                variables[v] = sampleRows
                onOutput(ConsoleOutput("💾 [SQLite] Получено ${sampleRows.size} записей в $v: $sampleRows", LogType.STDOUT))
            }

            // 8. Разное
            BlockType.ADD_NOTE -> { }
            BlockType.TRY_DO -> {
                try {
                    val sig = executeBlockList(block.children)
                    if (sig != null) return sig
                } catch (e: Exception) {
                    if (e is InterruptedException) throw e
                    val sig = executeBlockList(block.secondaryChildren)
                    if (sig != null) return sig
                }
            }

            BlockType.WRITE_FILE -> {
                val file = cleanQuotes(block.getField("file", "заметка.txt"))
                val text = evalSlotOrExpr(block, "text", "")?.toString() ?: ""
                onOutput(ConsoleOutput("💾 Запись в файл $file: \"$text\"", LogType.INFO))
            }

            BlockType.RAW_PY -> {
                val code = block.getField("code", "").trim()
                executeRawPythonLine(code)
            }

            BlockType.CALCULATE_FORMULA_STRING -> {
                val varName = block.getField("var", "ответ").trim()
                val formula = evalSlotOrExpr(block, "formula", "0")?.toString() ?: "0"
                val result = evalExpression(cleanQuotes(formula))
                variables[varName] = result
            }

            // Standalone expressions
            BlockType.EXPR_RANDOM_NUM, BlockType.EXPR_ROUND, BlockType.EXPR_ABS,
            BlockType.EXPR_MATH_OP, BlockType.EXPR_COMPARE_VALS, BlockType.EXPR_TEXT_CONTAINS,
            BlockType.EXPR_TEXT_LENGTH, BlockType.EXPR_RANDOM_CHOICE, BlockType.EXPR_LIST_SIZE,
            BlockType.EVAL_EXPRESSION -> {
                evalNestedBlock(block)
            }

            else -> {
                // Ignore other blocks in Python simulator
            }
        }
        return null
    }

    private suspend fun evalSlotOrExpr(block: Block, key: String, default: String): Any? {
        val nested = block.getNested(key)
        if (nested != null) {
            return evalNestedBlock(nested)
        }
        val raw = block.getField(key, default)
        return evalExpression(raw)
    }

    private suspend fun evalNestedBlock(block: Block): Any? {
        return when (block.type) {
            BlockType.EXPR_RANDOM_NUM -> {
                val from = (evalSlotOrExpr(block, "from", "1") as? Number)?.toInt() ?: 1
                val to = (evalSlotOrExpr(block, "to", "10") as? Number)?.toInt() ?: 10
                if (from <= to) random.nextInt(to - from + 1) + from else from
            }
            BlockType.EXPR_ROUND -> {
                val num = (evalSlotOrExpr(block, "number", "0") as? Number)?.toDouble() ?: 0.0
                Math.round(num)
            }
            BlockType.EXPR_ABS -> {
                val num = (evalSlotOrExpr(block, "number", "0") as? Number)?.toDouble() ?: 0.0
                Math.abs(num)
            }
            BlockType.EXPR_MATH_OP -> {
                val left = evalSlotOrExpr(block, "left", "0")
                val right = evalSlotOrExpr(block, "right", "0")
                val op = block.getField("op", "+").trim()
                when (op) {
                    "+" -> if (left is Number && right is Number) addNumbers(left, right) else "$left$right"
                    "-" -> subtractNumbers(left, right)
                    "*" -> multiplyNumbers(left, right)
                    "/" -> divideNumbers(left, right)
                    else -> 0
                }
            }
            BlockType.EXPR_COMPARE_VALS -> {
                val left = evalSlotOrExpr(block, "left", "0")
                val right = evalSlotOrExpr(block, "right", "0")
                val op = block.getField("op", "==").trim()
                when (op) {
                    "==" -> left == right
                    "!=" -> left != right
                    "<" -> compareValues(left, right) < 0
                    ">" -> compareValues(left, right) > 0
                    "<=" -> compareValues(left, right) <= 0
                    ">=" -> compareValues(left, right) >= 0
                    else -> false
                }
            }
            BlockType.EXPR_TEXT_CONTAINS -> {
                val word = cleanQuotes(evalSlotOrExpr(block, "word", "")?.toString() ?: "")
                val text = evalSlotOrExpr(block, "text", "")?.toString() ?: ""
                text.contains(word)
            }
            BlockType.EXPR_TEXT_LENGTH -> {
                val text = evalSlotOrExpr(block, "text", "")?.toString() ?: ""
                text.length
            }
            BlockType.EXPR_RANDOM_CHOICE -> {
                val listName = block.getField("list", "числа").trim()
                val list = variables[listName] as? List<*>
                if (!list.isNullOrEmpty()) {
                    list[random.nextInt(list.size)]
                } else null
            }
            BlockType.EXPR_LIST_SIZE -> {
                val listName = block.getField("list", "числа").trim()
                val list = variables[listName] as? List<*>
                list?.size ?: 0
            }
            BlockType.NN_ACTIVATION -> {
                val func = block.getField("func", "ReLU")
                val inp = (evalSlotOrExpr(block, "input", "0") as? Number)?.toDouble() ?: 0.5
                when (func.lowercase()) {
                    "sigmoid" -> 1.0 / (1.0 + Math.exp(-inp))
                    "tanh" -> Math.tanh(inp)
                    else -> Math.max(0.0, inp) // ReLU
                }
            }
            BlockType.API_STATUS_CODE -> {
                true
            }
            BlockType.OS_FILE_EXISTS -> {
                val p = cleanQuotes(block.getField("path", "заметка.txt"))
                p.isNotEmpty()
            }
            else -> {
                val raw = block.fields.values.firstOrNull() ?: ""
                evalExpression(raw)
            }
        }
    }

    private suspend fun evalCall(callStr: String): Any? {
        val openParen = callStr.indexOf('(')
        val closeParen = callStr.lastIndexOf(')')
        if (openParen == -1 || closeParen == -1) return null

        val funcName = callStr.substring(0, openParen).trim()
        val argsStr = callStr.substring(openParen + 1, closeParen).trim()
        val rawArgs = if (argsStr.isEmpty()) emptyList() else splitArguments(argsStr)
        val argValues = rawArgs.map { evalExpression(it) }

        if (funcName == "print") {
            onOutput(ConsoleOutput(argValues.joinToString(" "), LogType.STDOUT))
            return null
        }

        val funcDef = functions[funcName]
            ?: throw RuntimeException("Команда '$funcName' не найдена")

        val paramNames = funcDef.first
        val funcBlocks = funcDef.second

        val prevVars = HashMap(variables)
        for (i in paramNames.indices) {
            val pName = paramNames[i]
            val pVal = if (i < argValues.size) argValues[i] else null
            variables[pName] = pVal
        }

        var result: Any? = null
        try {
            val sig = executeBlockList(funcBlocks)
            if (sig is ReturnSignal.ReturnValue) {
                result = sig.value
            }
        } finally {
            paramNames.forEach { p ->
                if (prevVars.containsKey(p)) {
                    variables[p] = prevVars[p]
                } else {
                    variables.remove(p)
                }
            }
        }

        return result
    }

    private fun resolveCondition(block: Block, key: String): String {
        val nested = block.getNested(key)
        if (nested != null) {
            return when (nested.type) {
                BlockType.EXPR_COMPARE_VALS -> {
                    val l = nested.getField("left", "0")
                    val op = nested.getField("op", "==")
                    val r = nested.getField("right", "0")
                    "$l $op $r"
                }
                BlockType.EXPR_TEXT_CONTAINS -> {
                    val w = nested.getField("word", "\"\"")
                    val t = nested.getField("text", "\"\"")
                    "$w in $t"
                }
                else -> nested.fields.values.firstOrNull() ?: "True"
            }
        }
        return block.getField(key, "True").trim()
    }

    private fun evalCondition(condStr: String): Boolean {
        val trimmed = condStr.trim()
        if (trimmed.equals("True", ignoreCase = true) || trimmed == "1") return true
        if (trimmed.equals("False", ignoreCase = true) || trimmed == "0") return false

        // Check for 'in'
        if (trimmed.contains(" in ")) {
            val parts = trimmed.split(" in ", limit = 2)
            val left = evalExpression(parts[0].trim())?.toString() ?: ""
            val right = evalExpression(parts[1].trim())
            return when (right) {
                is String -> right.contains(left)
                is List<*> -> right.contains(evalExpression(parts[0].trim()))
                else -> false
            }
        }

        val operators = listOf("==", "!=", "<=", ">=", "<", ">")
        for (op in operators) {
            val idx = trimmed.indexOf(op)
            if (idx != -1) {
                val left = evalExpression(trimmed.substring(0, idx).trim())
                val right = evalExpression(trimmed.substring(idx + op.length).trim())
                return when (op) {
                    "==" -> left == right
                    "!=" -> left != right
                    "<" -> compareValues(left, right) < 0
                    ">" -> compareValues(left, right) > 0
                    "<=" -> compareValues(left, right) <= 0
                    ">=" -> compareValues(left, right) >= 0
                    else -> false
                }
            }
        }

        val res = evalExpression(trimmed)
        return when (res) {
            is Boolean -> res
            is Number -> res.toDouble() != 0.0
            is String -> res.isNotEmpty()
            null -> false
            else -> true
        }
    }

    private fun evalExpression(expr: String): Any? {
        val trimmed = expr.trim()
        if (trimmed.isEmpty()) return ""

        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) ||
            (trimmed.startsWith("'") && trimmed.endsWith("'"))
        ) {
            return cleanQuotes(trimmed)
        }

        trimmed.toLongOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }

        if (trimmed.equals("True", ignoreCase = true)) return true
        if (trimmed.equals("False", ignoreCase = true)) return false
        if (trimmed.equals("None", ignoreCase = true)) return null

        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val inner = trimmed.substring(1, trimmed.length - 1).trim()
            if (inner.isEmpty()) return mutableListOf<Any?>()
            return splitArguments(inner).map { evalExpression(it) }.toMutableList()
        }

        if (variables.containsKey(trimmed)) {
            return variables[trimmed]
        }

        val mathOps = listOf("+", "-", "*", "/", "%")
        for (op in mathOps) {
            val idx = findOperatorIndex(trimmed, op)
            if (idx != -1) {
                val lStr = trimmed.substring(0, idx).trim()
                val rStr = trimmed.substring(idx + op.length).trim()
                val left = evalExpression(lStr)
                val right = evalExpression(rStr)
                return when (op) {
                    "+" -> if (left is Number && right is Number) addNumbers(left, right) else "$left$right"
                    "-" -> subtractNumbers(left, right)
                    "*" -> multiplyNumbers(left, right)
                    "/" -> divideNumbers(left, right)
                    "%" -> moduloNumbers(left, right)
                    else -> 0
                }
            }
        }

        return trimmed
    }

    private fun findOperatorIndex(str: String, op: String): Int {
        var depth = 0
        var inQuotes = false
        var quoteChar = ' '

        for (i in str.indices) {
            val c = str[i]
            if ((c == '"' || c == '\'') && (i == 0 || str[i - 1] != '\\')) {
                if (!inQuotes) {
                    inQuotes = true
                    quoteChar = c
                } else if (c == quoteChar) {
                    inQuotes = false
                }
            }
            if (!inQuotes) {
                if (c == '(' || c == '[' || c == '{') depth++
                if (c == ')' || c == ']' || c == '}') depth--
                if (depth == 0 && i > 0 && str.startsWith(op, i)) {
                    return i
                }
            }
        }
        return -1
    }

    private fun interpolateTemplate(template: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < template.length) {
            val open = template.indexOf('{', i)
            if (open == -1) {
                sb.append(template.substring(i))
                break
            }
            sb.append(template.substring(i, open))
            val close = template.indexOf('}', open)
            if (close == -1) {
                sb.append(template.substring(open))
                break
            }
            val varExpr = template.substring(open + 1, close).trim()
            val evaluated = evalExpression(varExpr)
            sb.append(evaluated?.toString() ?: "")
            i = close + 1
        }
        return sb.toString()
    }

    private fun splitArguments(argsStr: String): List<String> {
        val result = mutableListOf<String>()
        var depth = 0
        var inQuotes = false
        var quoteChar = ' '
        var current = StringBuilder()

        for (i in argsStr.indices) {
            val c = argsStr[i]
            if ((c == '"' || c == '\'') && (i == 0 || argsStr[i - 1] != '\\')) {
                if (!inQuotes) {
                    inQuotes = true
                    quoteChar = c
                } else if (c == quoteChar) {
                    inQuotes = false
                }
            }
            if (!inQuotes) {
                if (c == '(' || c == '[' || c == '{') depth++
                if (c == ')' || c == ']' || c == '}') depth--
                if (c == ',' && depth == 0) {
                    result.add(current.toString().trim())
                    current = StringBuilder()
                    continue
                }
            }
            current.append(c)
        }
        if (current.isNotBlank()) {
            result.add(current.toString().trim())
        }
        return result
    }

    private fun cleanQuotes(str: String): String {
        val trimmed = str.trim()
        if (trimmed.length >= 2 &&
            ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) ||
             (trimmed.startsWith("'") && trimmed.endsWith("'")))
        ) {
            return trimmed.substring(1, trimmed.length - 1)
        }
        return trimmed
    }

    private fun addNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 0
        return if (na is Double || nb is Double || na is Float || nb is Float) {
            na.toDouble() + nb.toDouble()
        } else {
            na.toLong() + nb.toLong()
        }
    }

    private fun subtractNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 0
        return if (na is Double || nb is Double || na is Float || nb is Float) {
            na.toDouble() - nb.toDouble()
        } else {
            na.toLong() - nb.toLong()
        }
    }

    private fun multiplyNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 0
        return if (na is Double || nb is Double || na is Float || nb is Float) {
            na.toDouble() * nb.toDouble()
        } else {
            na.toLong() * nb.toLong()
        }
    }

    private fun divideNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 1
        val denom = nb.toDouble()
        if (denom == 0.0) throw RuntimeException("Деление на ноль (ZeroDivisionError)")
        return na.toDouble() / denom
    }

    private fun intDivideNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 1
        val denom = nb.toLong()
        if (denom == 0L) throw RuntimeException("Деление на ноль (ZeroDivisionError)")
        return na.toLong() / denom
    }

    private fun moduloNumbers(a: Any?, b: Any?): Any {
        val na = a as? Number ?: return 0
        val nb = b as? Number ?: return 1
        val denom = nb.toLong()
        if (denom == 0L) throw RuntimeException("Деление на ноль (ZeroDivisionError)")
        return na.toLong() % denom
    }

    private fun compareValues(a: Any?, b: Any?): Int {
        if (a is Number && b is Number) {
            return a.toDouble().compareTo(b.toDouble())
        }
        return (a?.toString() ?: "").compareTo(b?.toString() ?: "")
    }

    private fun executeRawPythonLine(code: String) {
        val trimmed = code.trim()
        if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
            val inside = trimmed.substring(6, trimmed.length - 1)
            onOutput(ConsoleOutput(cleanQuotes(evalExpression(inside)?.toString() ?: ""), LogType.STDOUT))
        } else if (trimmed.contains("=")) {
            val parts = trimmed.split("=", limit = 2)
            val v = parts[0].trim()
            val valStr = parts[1].trim()
            variables[v] = evalExpression(valStr)
        }
    }
}
