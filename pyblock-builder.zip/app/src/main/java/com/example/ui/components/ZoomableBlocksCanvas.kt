package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.model.Block
import kotlin.math.roundToInt

@Composable
fun ZoomableBlocksCanvas(
    blocks: List<Block>,
    onAddBlock: () -> Unit,
    onEditBlock: (Block) -> Unit,
    onMoveUp: (Int) -> Unit,
    onMoveDown: (Int) -> Unit,
    onReorder: (fromIndex: Int, toIndex: Int) -> Unit,
    onDuplicate: (Int) -> Unit,
    onDelete: (Int) -> Unit,
    onAddInside: (parentId: String, isSecondary: Boolean) -> Unit,
    onMoveChildUp: (parentId: String, childIdx: Int, isSecondary: Boolean) -> Unit,
    onMoveChildDown: (parentId: String, childIdx: Int, isSecondary: Boolean) -> Unit,
    onDuplicateChild: (parentId: String, childIdx: Int, isSecondary: Boolean) -> Unit,
    onDeleteChild: (parentId: String, childIdx: Int, isSecondary: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    // Zoom and pan state
    var scale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    // Drag-to-reorder state
    var draggingIndex by remember { mutableStateOf<Int?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    val density = LocalDensity.current
    val listState = rememberLazyListState()

    val dotColor = Color(0xFFD6D6D6)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCFCFC))
            .drawBehind {
                // Dot Grid Background
                val step = 26.dp.toPx() * scale
                if (step > 10f) {
                    val offsetX = (panOffset.x % step + step) % step
                    val offsetY = (panOffset.y % step + step) % step
                    var x = offsetX
                    while (x < size.width) {
                        var y = offsetY
                        while (y < size.height) {
                            drawCircle(
                                color = dotColor,
                                radius = 1.5f * scale,
                                center = Offset(x, y)
                            )
                            y += step
                        }
                        x += step
                    }
                }
            }
            .pointerInput(Unit) {
                // Pinch to Zoom and Canvas Pan
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.45f, 2.2f)
                    panOffset = Offset(
                        x = panOffset.x + pan.x,
                        y = panOffset.y + pan.y
                    )
                }
            }
    ) {
        // Scaled and Panned Canvas of Blocks
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
        ) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(
                    start = 32.dp,
                    end = 32.dp,
                    top = 24.dp,
                    bottom = 140.dp
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                // Start Hat Block ("▶ ПРИ СТАРТЕ ПРОГРАММЫ") - Clean White & Red Style
                item {
                    Surface(
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 6.dp, bottomEnd = 6.dp),
                        color = Color(0xFFE53935), // Primary Red
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .widthIn(max = 340.dp)
                            .border(
                                2.dp,
                                Color(0xFFC62828),
                                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 6.dp, bottomEnd = 6.dp)
                            )
                            .padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                modifier = Modifier.size(22.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Старт",
                                        tint = Color(0xFFE53935),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ПРИ СТАРТЕ ПРОГРАММЫ",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                if (blocks.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .padding(vertical = 12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddCircleOutline,
                                    contentDescription = null,
                                    tint = Color(0xFFE53935),
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Нажми на любой блок в меню, чтобы прикрепить его к скрипту!",
                                    fontSize = 12.sp,
                                    color = Color(0xFF666666),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    // Blocks List with Long-Press Drag-to-Reorder
                    itemsIndexed(blocks, key = { _, item -> item.id }) { index, block ->
                        val isBeingDragged = draggingIndex == index

                        val itemModifier = if (isBeingDragged) {
                            Modifier
                                .zIndex(2f)
                                .graphicsLayer {
                                    translationY = dragOffsetY
                                    shadowElevation = 14f
                                }
                        } else {
                            Modifier.zIndex(1f)
                        }

                        val dragHandleModifier = Modifier.pointerInput(Unit) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    draggingIndex = index
                                    dragOffsetY = 0f
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    dragOffsetY += dragAmount.y

                                    val itemHeightPx = with(density) { 68.dp.toPx() }
                                    val currentDragged = draggingIndex
                                    if (currentDragged != null) {
                                        val deltaItems = (dragOffsetY / itemHeightPx).roundToInt()
                                        val targetIndex = (currentDragged + deltaItems).coerceIn(0, blocks.size - 1)
                                        if (targetIndex != currentDragged) {
                                            onReorder(currentDragged, targetIndex)
                                            draggingIndex = targetIndex
                                            dragOffsetY -= (targetIndex - currentDragged) * itemHeightPx
                                        }
                                    }
                                },
                                onDragEnd = {
                                    draggingIndex = null
                                    dragOffsetY = 0f
                                },
                                onDragCancel = {
                                    draggingIndex = null
                                    dragOffsetY = 0f
                                }
                            )
                        }

                        ScratchBlockItem(
                            block = block,
                            index = index,
                            totalCount = blocks.size,
                            onEditBlock = onEditBlock,
                            onMoveUp = { onMoveUp(index) },
                            onMoveDown = { onMoveDown(index) },
                            onDuplicate = { onDuplicate(index) },
                            onDelete = { onDelete(index) },
                            onAddInside = { isSec -> onAddInside(block.id, isSec) },
                            onEditChildBlock = onEditBlock,
                            onMoveChildUp = { cIdx, isSec -> onMoveChildUp(block.id, cIdx, isSec) },
                            onMoveChildDown = { cIdx, isSec -> onMoveChildDown(block.id, cIdx, isSec) },
                            onDuplicateChild = { cIdx, isSec -> onDuplicateChild(block.id, cIdx, isSec) },
                            onDeleteChild = { cIdx, isSec -> onDeleteChild(block.id, cIdx, isSec) },
                            isBeingDragged = isBeingDragged,
                            dragModifier = dragHandleModifier,
                            modifier = itemModifier
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onAddBlock,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFE53935)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFE53935)),
                            modifier = Modifier.fillMaxWidth(0.5f)
                        ) {
                            Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Добавить блок", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Round Zoom Controls (bottom-right)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // [ = ] Center / 100% Zoom Button
            Surface(
                onClick = {
                    scale = 1.0f
                    panOffset = Offset.Zero
                },
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 3.dp,
                modifier = Modifier.size(36.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "=",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE53935)
                    )
                }
            }

            // [ + ] Zoom In Button
            Surface(
                onClick = { scale = (scale + 0.15f).coerceAtMost(2.2f) },
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 3.dp,
                modifier = Modifier.size(36.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Приблизить",
                        tint = Color(0xFF333333),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // [ - ] Zoom Out Button
            Surface(
                onClick = { scale = (scale - 0.15f).coerceAtLeast(0.45f) },
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 3.dp,
                modifier = Modifier.size(36.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Отдалить",
                        tint = Color(0xFF333333),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
