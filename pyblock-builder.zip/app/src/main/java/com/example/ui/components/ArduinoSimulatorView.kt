package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Block
import com.example.model.BlockType
import com.example.model.Localization
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArduinoSimulatorView(
    blocks: List<Block>,
    modifier: Modifier = Modifier,
    language: AppLanguage = AppLanguage.DEFAULT
) {
    // Simulator Virtual State
    var isRunning by remember { mutableStateOf(false) }

    // Pin states (0-13, A0-A5)
    var pin13State by remember { mutableStateOf(false) }
    var pinStates by remember { mutableStateOf(mapOf<String, Boolean>()) }
    var pinPwmValues by remember { mutableStateOf(mapOf<String, Int>()) }

    // Servo & Motors
    var servoAngle by remember { mutableStateOf(90f) }
    var motorASpeed by remember { mutableStateOf(0) }
    var motorADir by remember { mutableStateOf("Стоп") }
    var motorBSpeed by remember { mutableStateOf(0) }
    var motorBDir by remember { mutableStateOf("Стоп") }
    var stepperSteps by remember { mutableStateOf(0) }

    // Buzzer & Serial
    var buzzerActive by remember { mutableStateOf(false) }
    var buzzerFreq by remember { mutableStateOf(440) }
    val serialLogs = remember { mutableStateListOf<String>() }

    // Virtual Displays & Screens
    var lcdInitialized by remember { mutableStateOf(false) }
    var lcdBacklight by remember { mutableStateOf(true) }
    var lcdLine1 by remember { mutableStateOf("                ") }
    var lcdLine2 by remember { mutableStateOf("                ") }

    var oledInitialized by remember { mutableStateOf(false) }
    val oledLines = remember { mutableStateListOf<String>() }

    var tm1637Initialized by remember { mutableStateOf(false) }
    var tm1637DisplayValue by remember { mutableStateOf("----") }

    // Interactive sensor controls
    var buttonPressed by remember { mutableStateOf(false) }
    var analogA0Value by remember { mutableStateOf(512f) }
    var ultrasonicDistanceCm by remember { mutableStateOf(25f) }

    val primaryRed = Color(0xFFE53935)
    val darkRed = Color(0xFFC62828)

    // Motor A spinning rotation
    val infiniteTransitionA = rememberInfiniteTransition(label = "motor_a_anim")
    val motorARotation by infiniteTransitionA.animateFloat(
        initialValue = 0f,
        targetValue = if (motorADir.contains("Назад")) -360f else 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (motorASpeed > 0) (2500 / motorASpeed.coerceAtLeast(20)).coerceIn(80, 2000) else 1000000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_a"
    )

    // Motor B spinning rotation
    val infiniteTransitionB = rememberInfiniteTransition(label = "motor_b_anim")
    val motorBRotation by infiniteTransitionB.animateFloat(
        initialValue = 0f,
        targetValue = if (motorBDir.contains("Назад")) -360f else 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (motorBSpeed > 0) (2500 / motorBSpeed.coerceAtLeast(20)).coerceIn(80, 2000) else 1000000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_b"
    )

    // Simulation Execution Loop
    LaunchedEffect(isRunning, blocks, buttonPressed, analogA0Value, ultrasonicDistanceCm) {
        if (!isRunning) return@LaunchedEffect

        serialLogs.add("--- Запуск платы Arduino Uno ---")
        val variables = mutableMapOf<String, Long>()

        suspend fun executeBlocks(list: List<Block>) {
            for (block in list) {
                if (!isRunning) break
                when (block.type) {
                    BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> {
                        val p = block.getField("pin", "13")
                        if (p == "13") pin13State = true
                        pinStates = pinStates + (p to true)
                    }
                    BlockType.ARDUINO_DIGITAL_WRITE_LOW -> {
                        val p = block.getField("pin", "13")
                        if (p == "13") pin13State = false
                        pinStates = pinStates + (p to false)
                    }
                    BlockType.ARDUINO_BLINK_LED -> {
                        val p = block.getField("pin", "13")
                        val ms = block.getField("delay_ms", "500").toLongOrNull() ?: 500L
                        if (p == "13") pin13State = true
                        pinStates = pinStates + (p to true)
                        delay((ms / 2).coerceIn(80L, 1000L))
                        if (p == "13") pin13State = false
                        pinStates = pinStates + (p to false)
                        delay((ms / 2).coerceIn(80L, 1000L))
                    }
                    BlockType.ARDUINO_PWM_BRIGHTNESS -> {
                        val p = block.getField("pin", "9")
                        val pwm = block.getField("brightness", "128").toIntOrNull() ?: 128
                        pinPwmValues = pinPwmValues + (p to pwm)
                        if (p == "13") pin13State = pwm > 0
                    }
                    BlockType.ARDUINO_TOGGLE_PIN -> {
                        val p = block.getField("pin", "13")
                        val cur = pinStates[p] ?: false
                        pinStates = pinStates + (p to !cur)
                        if (p == "13") pin13State = !cur
                    }

                    // Servo
                    BlockType.ARDUINO_SERVO_WRITE -> {
                        val angle = block.getField("angle", "90").toFloatOrNull() ?: 90f
                        servoAngle = angle.coerceIn(0f, 180f)
                    }
                    BlockType.ARDUINO_SERVO_SWEEP -> {
                        val from = block.getField("from", "0").toFloatOrNull() ?: 0f
                        val to = block.getField("to", "180").toFloatOrNull() ?: 180f
                        servoAngle = from
                        delay(250)
                        servoAngle = to
                    }

                    // Motors & Drivers
                    BlockType.ARDUINO_MOTOR_FORWARD -> {
                        val spd = block.getField("speed", "255").toIntOrNull() ?: 255
                        motorASpeed = spd
                        motorADir = "Вперед"
                    }
                    BlockType.ARDUINO_MOTOR_BACKWARD -> {
                        val spd = block.getField("speed", "255").toIntOrNull() ?: 255
                        motorASpeed = spd
                        motorADir = "Назад"
                    }
                    BlockType.ARDUINO_MOTOR_STOP -> {
                        motorASpeed = 0
                        motorADir = "Стоп"
                    }
                    BlockType.ARDUINO_L298N_DRIVER -> {
                        val spd = block.getField("speed", "255").toIntOrNull() ?: 255
                        motorASpeed = spd
                        motorADir = "Вперед"
                    }
                    BlockType.ARDUINO_L298N_MOTOR_A -> {
                        val spd = block.getField("speed", "255").toIntOrNull() ?: 255
                        val dir = block.getField("dir", "Вперед")
                        motorASpeed = if (dir.contains("Стоп")) 0 else spd
                        motorADir = dir
                    }
                    BlockType.ARDUINO_L298N_MOTOR_B -> {
                        val spd = block.getField("speed", "255").toIntOrNull() ?: 255
                        val dir = block.getField("dir", "Вперед")
                        motorBSpeed = if (dir.contains("Стоп")) 0 else spd
                        motorBDir = dir
                    }
                    BlockType.ARDUINO_L298N_STOP_ALL -> {
                        motorASpeed = 0
                        motorADir = "Стоп"
                        motorBSpeed = 0
                        motorBDir = "Стоп"
                    }
                    BlockType.ARDUINO_L9110S_MOTOR -> {
                        val spd = block.getField("speed", "200").toIntOrNull() ?: 200
                        val dir = block.getField("dir", "Вперед")
                        motorASpeed = spd
                        motorADir = dir
                    }
                    BlockType.ARDUINO_STEPPER_STEP -> {
                        val steps = block.getField("steps", "500").toIntOrNull() ?: 500
                        stepperSteps += steps
                    }

                    // Buzzer
                    BlockType.ARDUINO_BUZZER_TONE -> {
                        buzzerActive = true
                        buzzerFreq = block.getField("freq", "440").toIntOrNull() ?: 440
                        val dur = block.getField("duration", "400").toLongOrNull() ?: 400L
                        delay(dur.coerceIn(100L, 800L))
                        buzzerActive = false
                    }
                    BlockType.ARDUINO_BUZZER_NOTONE -> {
                        buzzerActive = false
                    }
                    BlockType.ARDUINO_BUZZER_BEEP -> {
                        buzzerActive = true
                        buzzerFreq = 1000
                        delay(120)
                        buzzerActive = false
                    }

                    // Sensors
                    BlockType.ARDUINO_DIGITAL_READ -> {
                        val v = block.getField("var", "кнопка")
                        variables[v] = if (buttonPressed) 1L else 0L
                    }
                    BlockType.ARDUINO_ANALOG_READ -> {
                        val v = block.getField("var", "датчик")
                        variables[v] = analogA0Value.toLong()
                    }
                    BlockType.ARDUINO_ULTRASONIC -> {
                        val v = block.getField("var", "дистанция")
                        variables[v] = ultrasonicDistanceCm.toLong()
                    }
                    BlockType.ARDUINO_IF_BUTTON -> {
                        if (buttonPressed) {
                            executeBlocks(block.children)
                        }
                    }
                    BlockType.ARDUINO_IF_ELSE -> {
                        val cond = block.getField("condition", "true")
                        val isTrue = if (cond.contains("кнопка")) {
                            buttonPressed
                        } else if (cond.contains("дистанция")) {
                            ultrasonicDistanceCm < 20
                        } else if (cond.contains(">")) {
                            analogA0Value > 500
                        } else {
                            true
                        }
                        if (isTrue) {
                            executeBlocks(block.children)
                        } else if (block.secondaryChildren.isNotEmpty()) {
                            executeBlocks(block.secondaryChildren)
                        }
                    }

                    // Timing & Loops
                    BlockType.ARDUINO_DELAY_MS -> {
                        val ms = block.getField("ms", "500").toLongOrNull() ?: 500L
                        delay(ms.coerceIn(40L, 2000L))
                    }
                    BlockType.ARDUINO_DELAY_SEC -> {
                        val sec = block.getField("sec", "1").toLongOrNull() ?: 1L
                        delay((sec * 1000).coerceIn(100L, 3000L))
                    }
                    BlockType.ARDUINO_REPEAT_TIMES -> {
                        val times = block.getField("times", "5").toIntOrNull() ?: 5
                        for (i in 0 until times.coerceAtMost(20)) {
                            executeBlocks(block.children)
                        }
                    }
                    BlockType.ARDUINO_LOOP_FOREVER -> {
                        executeBlocks(block.children)
                    }

                    // Serial
                    BlockType.ARDUINO_SERIAL_PRINTLN -> {
                        var text = block.getField("text", "")
                        if (text.startsWith("\"") && text.endsWith("\"") && text.length >= 2) {
                            text = text.substring(1, text.length - 1)
                        }
                        serialLogs.add(text)
                    }
                    BlockType.ARDUINO_SERIAL_PRINT_VAR -> {
                        val v = block.getField("var", "датчик")
                        val value = variables[v] ?: when {
                            v.contains("датчик") -> analogA0Value.toLong()
                            v.contains("дистанция") -> ultrasonicDistanceCm.toLong()
                            v.contains("кнопка") -> (if (buttonPressed) 1L else 0L)
                            else -> 0L
                        }
                        serialLogs.add("$v = $value")
                    }

                    // Displays: LCD 1602 (I2C)
                    BlockType.ARDUINO_LCD_INIT -> {
                        lcdInitialized = true
                        lcdBacklight = true
                    }
                    BlockType.ARDUINO_LCD_CLEAR -> {
                        lcdLine1 = "                "
                        lcdLine2 = "                "
                    }
                    BlockType.ARDUINO_LCD_BACKLIGHT -> {
                        val st = block.getField("state", "ВКЛ")
                        lcdBacklight = (st == "ВКЛ" || st.equals("ON", ignoreCase = true))
                    }
                    BlockType.ARDUINO_LCD_PRINT -> {
                        lcdInitialized = true
                        var text = block.getField("text", "")
                        if (text.startsWith("\"") && text.endsWith("\"") && text.length >= 2) {
                            text = text.substring(1, text.length - 1)
                        }
                        val col = block.getField("col", "0").toIntOrNull() ?: 0
                        val row = block.getField("row", "0").toIntOrNull() ?: 0
                        if (row == 0) {
                            lcdLine1 = updateLcdLine(lcdLine1, text, col)
                        } else {
                            lcdLine2 = updateLcdLine(lcdLine2, text, col)
                        }
                    }
                    BlockType.ARDUINO_LCD_PRINT_VAR -> {
                        lcdInitialized = true
                        val v = block.getField("var", "датчик")
                        val value = variables[v] ?: when {
                            v.contains("датчик") -> analogA0Value.toLong()
                            v.contains("дистанция") -> ultrasonicDistanceCm.toLong()
                            v.contains("кнопка") -> (if (buttonPressed) 1L else 0L)
                            else -> 0L
                        }
                        val col = block.getField("col", "0").toIntOrNull() ?: 0
                        val row = block.getField("row", "0").toIntOrNull() ?: 0
                        if (row == 0) {
                            lcdLine1 = updateLcdLine(lcdLine1, value.toString(), col)
                        } else {
                            lcdLine2 = updateLcdLine(lcdLine2, value.toString(), col)
                        }
                    }

                    // Displays: OLED SSD1306
                    BlockType.ARDUINO_OLED_INIT -> {
                        oledInitialized = true
                    }
                    BlockType.ARDUINO_OLED_CLEAR -> {
                        oledLines.clear()
                    }
                    BlockType.ARDUINO_OLED_PRINT -> {
                        oledInitialized = true
                        var text = block.getField("text", "")
                        if (text.startsWith("\"") && text.endsWith("\"") && text.length >= 2) {
                            text = text.substring(1, text.length - 1)
                        }
                        if (oledLines.size >= 4) {
                            oledLines.removeAt(0)
                        }
                        oledLines.add(text)
                    }
                    BlockType.ARDUINO_OLED_PRINT_VAR -> {
                        oledInitialized = true
                        val v = block.getField("var", "датчик")
                        val value = variables[v] ?: when {
                            v.contains("датчик") -> analogA0Value.toLong()
                            v.contains("дистанция") -> ultrasonicDistanceCm.toLong()
                            v.contains("кнопка") -> (if (buttonPressed) 1L else 0L)
                            else -> 0L
                        }
                        if (oledLines.size >= 4) {
                            oledLines.removeAt(0)
                        }
                        oledLines.add("$v = $value")
                    }

                    // Displays: TM1637 (4-digit 7-segment)
                    BlockType.ARDUINO_TM1637_INIT -> {
                        tm1637Initialized = true
                    }
                    BlockType.ARDUINO_TM1637_CLEAR -> {
                        tm1637DisplayValue = "    "
                    }
                    BlockType.ARDUINO_TM1637_NUMBER -> {
                        tm1637Initialized = true
                        val rawNum = block.getField("num", "1234")
                        val vNum = variables[rawNum]
                        val displayNum = if (vNum != null) {
                            vNum.toString()
                        } else if (rawNum.toLongOrNull() != null) {
                            rawNum
                        } else when {
                            rawNum.contains("датчик") -> analogA0Value.toLong().toString()
                            rawNum.contains("дистанция") -> ultrasonicDistanceCm.toLong().toString()
                            else -> rawNum
                        }
                        tm1637DisplayValue = displayNum.takeLast(4).padStart(4, ' ')
                    }

                    else -> {}
                }
            }
        }

        while (isRunning) {
            executeBlocks(blocks)
            delay(250)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFECEFF1))
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Controls Top Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (isRunning) Color(0xFF4CAF50) else Color(0xFFBDBDBD),
                        modifier = Modifier.size(12.dp)
                    ) {}
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isRunning) "Плата Arduino Uno работает" else "Плата выключена",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF212121)
                        )
                        Text(
                            text = "ATmega328P • 16MHz • 5V",
                            fontSize = 10.sp,
                            color = Color(0xFF757575)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { isRunning = !isRunning },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRunning) darkRed else primaryRed
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("simulator_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isRunning) "Пауза" else "Запустить", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            isRunning = false
                            pin13State = false
                            pinStates = emptyMap()
                            pinPwmValues = emptyMap()
                            servoAngle = 90f
                            motorASpeed = 0
                            motorADir = "Стоп"
                            motorBSpeed = 0
                            motorBDir = "Стоп"
                            stepperSteps = 0
                            buzzerActive = false
                            serialLogs.clear()
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Сброс", fontSize = 12.sp)
                    }
                }
            }
        }

        // ==========================================
        // REAL ARDUINO UNO BOARD GRAPHIC
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF00878F)), // Authentic Arduino Teal/Blue
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // Board Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFFFD54F),
                            modifier = Modifier.size(10.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ARDUINO UNO",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Text(
                        text = "Made in Italy • Rev 3",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // TOP DIGITAL HEADER (Pins AREF, GND, 13, 12, 11, 10, 9, 8 | 7, 6, 5, 4, 3, 2, 1, 0)
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF1E1E1E),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val topPins = listOf(
                            "AREF" to false, "GND" to false,
                            "13" to pin13State,
                            "12" to (pinStates["12"] ?: false),
                            "~11" to (pinStates["11"] ?: false),
                            "~10" to (pinStates["10"] ?: false),
                            "~9" to (pinStates["9"] ?: false),
                            "8" to (pinStates["8"] ?: false),
                            "7" to (pinStates["7"] ?: false),
                            "~6" to (pinStates["6"] ?: false),
                            "~5" to (pinStates["5"] ?: false),
                            "4" to (pinStates["4"] ?: false),
                            "~3" to (pinStates["3"] ?: false),
                            "2" to buttonPressed,
                            "TX" to false, "RX" to false
                        )

                        topPins.forEach { (name, isActive) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 1.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isActive) Color(0xFFFFD54F) else Color(0xFF333333),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isActive) Color(0xFFFF8F00) else Color(0xFF555555)),
                                    modifier = Modifier.size(9.dp)
                                ) {}
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = name,
                                    fontSize = 7.5.sp,
                                    color = if (isActive) Color(0xFFFFD54F) else Color(0xFFB0BEC5),
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Board Middle Layout: USB, DC Jack, ATmega328P Chip & Status LEDs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: USB Port & 5V DC Jack
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(2.dp),
                            color = Color(0xFF9E9E9E),
                            modifier = Modifier.size(28.dp, 22.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("USB", color = Color(0xFF212121), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = Color(0xFF212121),
                            modifier = Modifier.size(22.dp, 20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("DC", color = Color.White, fontSize = 7.sp)
                            }
                        }
                    }

                    // Middle: ATmega328P DIP Chip
                    Surface(
                        shape = RoundedCornerShape(2.dp),
                        color = Color(0xFF1B1B1B),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF424242)),
                        modifier = Modifier.size(110.dp, 24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "ATMEGA328P-PU",
                                color = Color(0xFFE0E0E0),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Right: Status LEDs: ON (Green), L (Pin 13), TX, RX
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // ON LED
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = if (isRunning) Color(0xFF00E676) else Color(0xFF33691E),
                                modifier = Modifier.size(8.dp)
                            ) {}
                            Text("ON", color = Color.White, fontSize = 7.sp)
                        }

                        // L LED (Pin 13)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = if (pin13State) Color(0xFFFF1744) else Color(0xFF550000),
                                modifier = Modifier.size(8.dp)
                            ) {}
                            Text("L", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }

                        // TX/RX LEDs
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = if (serialLogs.isNotEmpty() && isRunning) Color(0xFFFFD54F) else Color(0xFF555500),
                                modifier = Modifier.size(7.dp)
                            ) {}
                            Text("TX", color = Color.White, fontSize = 6.5.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // BOTTOM ANALOG & POWER HEADER (IOREF, RESET, 3.3V, 5V, GND, VIN, A0, A1, A2, A3, A4, A5)
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF1E1E1E),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bottomPins = listOf(
                            "IOREF" to false, "RESET" to false, "3.3V" to false, "5V" to isRunning,
                            "GND" to false, "GND" to false, "VIN" to false,
                            "A0" to (analogA0Value > 100),
                            "A1" to false, "A2" to false, "A3" to false, "A4" to false, "A5" to false
                        )

                        bottomPins.forEach { (name, isActive) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 1.dp)
                            ) {
                                Text(
                                    text = name,
                                    fontSize = 7.5.sp,
                                    color = if (isActive) Color(0xFF81C784) else Color(0xFFB0BEC5),
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = if (isActive) Color(0xFF81C784) else Color(0xFF333333),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isActive) Color(0xFF388E3C) else Color(0xFF555555)),
                                    modifier = Modifier.size(9.dp)
                                ) {}
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // DRIVER L298N & DUAL MOTORS
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFD32F2F),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("L298", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Драйвер моторов L298N",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF212121)
                        )
                    }

                    Text(
                        text = "ШИМ: ENA=9, ENB=10",
                        fontSize = 10.sp,
                        color = Color(0xFF757575)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Motor A
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F9)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "Мотор A (IN1, IN2)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Icon(
                                imageVector = Icons.Default.Toys,
                                contentDescription = null,
                                tint = if (motorASpeed > 0) Color(0xFF43A047) else Color(0xFFBDBDBD),
                                modifier = Modifier
                                    .size(36.dp)
                                    .rotate(if (motorASpeed > 0) motorARotation else 0f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$motorADir • $motorASpeed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (motorASpeed > 0) Color(0xFF2E7D32) else Color(0xFF757575)
                            )
                        }
                    }

                    // Motor B
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F9)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "Мотор B (IN3, IN4)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Icon(
                                imageVector = Icons.Default.Toys,
                                contentDescription = null,
                                tint = if (motorBSpeed > 0) Color(0xFF1E88E5) else Color(0xFFBDBDBD),
                                modifier = Modifier
                                    .size(36.dp)
                                    .rotate(if (motorBSpeed > 0) motorBRotation else 0f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$motorBDir • $motorBSpeed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (motorBSpeed > 0) Color(0xFF1565C0) else Color(0xFF757575)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SERVO & BUZZER ROW
        // ==========================================
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Servo Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Сервопривод (Пин 9)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF333333)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Canvas(modifier = Modifier.size(54.dp, 36.dp)) {
                        val center = Offset(size.width / 2, size.height)
                        val radius = size.width * 0.45f
                        drawArc(
                            color = Color(0xFFE0E0E0),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = false,
                            style = Stroke(width = 6f, cap = StrokeCap.Round)
                        )
                        val rad = Math.toRadians((180f + servoAngle).toDouble())
                        val needleEnd = Offset(
                            (center.x + radius * cos(rad)).toFloat(),
                            (center.y + radius * sin(rad)).toFloat()
                        )
                        drawLine(
                            color = Color(0xFFFB8C00),
                            start = center,
                            end = needleEnd,
                            strokeWidth = 5f,
                            cap = StrokeCap.Round
                        )
                        drawCircle(color = Color(0xFF212121), radius = 5f, center = center)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Угол: ${servoAngle.toInt()}°",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE65100)
                    )
                }
            }

            // Buzzer Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Зуммер (Пин 8)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF333333)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = CircleShape,
                        color = if (buzzerActive) Color(0xFF8E24AA) else Color(0xFFF5F5F5),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (buzzerActive) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                                contentDescription = null,
                                tint = if (buzzerActive) Color.White else Color(0xFF757575),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (buzzerActive) "$buzzerFreq Гц" else "Тишина",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (buzzerActive) Color(0xFF8E24AA) else Color(0xFF757575)
                    )
                }
            }
        }

        // ==========================================
        // VIRTUAL DISPLAYS & SCREENS (LCD 1602, OLED, TM1637)
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF00897B),
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Tv,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Localization.get(language, "displays_and_screens"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF212121)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFE0F2F1),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LCD • OLED • TM1637",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00695C),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 1. LCD 1602 (I2C 0x27)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0D47A1), // Blue PCB bezel
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF1565C0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Localization.get(language, "lcd_display"),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (lcdBacklight) Color(0xFF00E676) else Color(0xFF757575),
                                    modifier = Modifier.size(7.dp)
                                ) {}
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (lcdBacklight) "${Localization.get(language, "backlight")}: ON" else "${Localization.get(language, "backlight")}: OFF",
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // LCD Glass Screen (16x2 characters)
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (lcdBacklight) Color(0xFF00B0FF) else Color(0xFF263238),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF01579B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = lcdLine1.ifBlank { "                " },
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp,
                                    color = if (lcdBacklight) Color(0xFF002171) else Color(0xFF90A4AE),
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = lcdLine2.ifBlank { "                " },
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp,
                                    color = if (lcdBacklight) Color(0xFF002171) else Color(0xFF90A4AE),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 2. OLED 0.96" SSD1306 & TM1637 side-by-side
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // OLED 0.96" (SSD1306)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E1E1E),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF424242)),
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "OLED 0.96\" (I2C)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFD54F)
                                )
                                Text(
                                    text = "128x64",
                                    fontSize = 8.5.sp,
                                    color = Color.LightGray
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // OLED Glass Screen
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(64.dp)
                                    .background(Color(0xFF0A0F14), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFF00ACC1).copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                    .padding(4.dp)
                            ) {
                                if (oledLines.isEmpty()) {
                                    Text(
                                        text = if (isRunning) "SSD1306 Ready\nWaiting text..." else "OLED OFF",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isRunning) Color(0xFF00E5FF).copy(alpha = 0.6f) else Color(0xFF555555),
                                        lineHeight = 12.sp
                                    )
                                } else {
                                    Column {
                                        oledLines.takeLast(4).forEach { line ->
                                            Text(
                                                text = line,
                                                fontSize = 9.5.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF00E5FF),
                                                lineHeight = 12.sp,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // TM1637 4-Digit 7-Segment Display
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1B1B1B),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF333333)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "TM1637 7-Seg",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 7-segment digital screen
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(64.dp)
                                    .background(Color(0xFF150303), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFFB71C1C), RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                val chars = tm1637DisplayValue.padEnd(4, ' ').take(4)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    chars.forEachIndexed { idx, ch ->
                                        Text(
                                            text = ch.toString(),
                                            fontSize = 20.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFFFF1744),
                                            modifier = Modifier.padding(horizontal = 1.dp)
                                        )
                                        if (idx == 1) {
                                            Text(
                                                text = ":",
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFFFF1744),
                                                modifier = Modifier.padding(horizontal = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // INTERACTIVE SENSORS (HC-SR04, A0, PIN 2)
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Интерактивные датчики (изменяй параметры):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Button Pin 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "Кнопка (Пин 2)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(
                            text = if (buttonPressed) "Сигнал: HIGH (нажата)" else "Сигнал: LOW (отпущена)",
                            fontSize = 10.sp,
                            color = if (buttonPressed) primaryRed else Color(0xFF757575)
                        )
                    }

                    FilledTonalButton(
                        onClick = { buttonPressed = !buttonPressed },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (buttonPressed) primaryRed else Color(0xFFEEEEEE),
                            contentColor = if (buttonPressed) Color.White else Color(0xFF212121)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(if (buttonPressed) "Отпустить" else "Нажать кнопку", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Ultrasonic HC-SR04 Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Дальномер HC-SR04 (Trig=7, Echo=6)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(text = "${ultrasonicDistanceCm.toInt()} см", fontWeight = FontWeight.Bold, color = Color(0xFF00838F), fontSize = 12.sp)
                    }

                    Slider(
                        value = ultrasonicDistanceCm,
                        onValueChange = { ultrasonicDistanceCm = it },
                        valueRange = 2f..200f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00ACC1),
                            activeTrackColor = Color(0xFF00ACC1)
                        )
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Analog A0 Potentiometer slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Аналоговый датчик (A0)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(text = "${analogA0Value.toInt()} / 1023", fontWeight = FontWeight.Bold, color = primaryRed, fontSize = 12.sp)
                    }

                    Slider(
                        value = analogA0Value,
                        onValueChange = { analogA0Value = it },
                        valueRange = 0f..1023f,
                        colors = SliderDefaults.colors(
                            thumbColor = primaryRed,
                            activeTrackColor = primaryRed
                        )
                    )
                }
            }
        }

        // ==========================================
        // VIRTUAL SERIAL MONITOR
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF81C784), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Монитор порта (Serial: 9600 бод)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = { serialLogs.clear() },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Очистить", tint = Color.LightGray, modifier = Modifier.size(15.dp))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .background(Color(0xFF121212), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    val listState = rememberLazyListState()
                    LaunchedEffect(serialLogs.size) {
                        if (serialLogs.isNotEmpty()) {
                            listState.animateScrollToItem(serialLogs.size - 1)
                        }
                    }

                    if (serialLogs.isEmpty()) {
                        Text(
                            text = "Вывод Serial.println() появится здесь при запуске...",
                            color = Color(0xFF757575),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    } else {
                        LazyColumn(state = listState) {
                            items(serialLogs) { log ->
                                Text(
                                    text = "> $log",
                                    color = Color(0xFFE0E0E0),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun updateLcdLine(currentLine: String, newText: String, col: Int): String {
    val clean = if (newText.startsWith("\"") && newText.endsWith("\"") && newText.length >= 2) {
        newText.substring(1, newText.length - 1)
    } else newText
    val padded = currentLine.padEnd(16, ' ').toCharArray()
    for (i in clean.indices) {
        val target = col + i
        if (target in 0 until 16) {
            padded[target] = clean[i]
        }
    }
    return String(padded)
}

