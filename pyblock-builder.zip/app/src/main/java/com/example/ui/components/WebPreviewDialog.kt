package com.example.ui.components

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.model.Localization

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPreviewDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var showHowToHostDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("web_preview_dialog"),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar
                Surface(
                    color = Color(0xFF1E293B),
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2563EB)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = Localization.get(currentLanguage, "web_version"),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = Localization.get(currentLanguage, "web_version_desc"),
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // How to host button
                            FilledTonalButton(
                                onClick = { showHowToHostDialog = true },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF334155),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(
                                    Icons.Default.HelpOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = Localization.get(currentLanguage, "how_to_host"),
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Reload button
                            IconButton(
                                onClick = { webViewInstance?.reload() },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "Reload",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Close button
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // WebView Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    loadWithOverviewMode = true
                                    useWideViewPort = true
                                    builtInZoomControls = true
                                    displayZoomControls = false
                                    cacheMode = WebSettings.LOAD_NO_CACHE
                                    allowFileAccess = true
                                }
                                webViewClient = WebViewClient()
                                loadUrl("file:///android_asset/web/index.html")
                                webViewInstance = this
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    // Modal with Hosting Instructions
    if (showHowToHostDialog) {
        AlertDialog(
            onDismissRequest = { showHowToHostDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Localization.get(currentLanguage, "how_to_host"),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = when (currentLanguage) {
                            AppLanguage.EN ->
                                "This project includes a complete HTML5 + JavaScript + CSS version of PyBlocks in the 'web/' directory!\n\n" +
                                "1. Standalone run:\nOpen 'web/pyblocks_standalone.html' in Chrome, Safari, or Edge — all CSS and JS are bundled in one file.\n\n" +
                                "2. Host online (Free on GitHub Pages):\nUpload files from 'web/' to a GitHub repository, enable Pages in Settings -> Pages -> Deploy from main. Your web editor is live!\n\n" +
                                "3. Vercel / Netlify:\nDrag and drop the 'web' folder into netlify.com/drop."
                            AppLanguage.UK ->
                                "Цей проєкт містить повну версію PyBlocks на HTML5 + JavaScript + CSS у папці 'web/'!\n\n" +
                                "1. Автономний запуск:\nВідкрийте 'web/pyblocks_standalone.html' у будь-якому браузері (Chrome, Safari, Edge) — всі стилі та код упаковані в 1 файл.\n\n" +
                                "2. Онлайн на GitHub Pages:\nЗавантажте файли з папки 'web/' у репозиторій GitHub і ввімкніть Settings -> Pages. Сайт запрацює для всіх!\n\n" +
                                "3. Vercel або Netlify:\nПеретягніть папку 'web' на netlify.com/drop для миттєвого безкоштовного хостингу."
                            AppLanguage.RU ->
                                "В этом проекте создана полноценная версия PyBlocks на HTML5 + JavaScript + CSS в папке 'web/'!\n\n" +
                                "1. Автономный запуск в 1 клик:\nОткройте 'web/pyblocks_standalone.html' в любом браузере (Chrome, Safari, Edge, Яндекс) — все стили и скрипты собраны в один файл.\n\n" +
                                "2. Бесплатно на GitHub Pages:\nЗагрузите файлы из папки 'web/' в репозиторий GitHub и включите Settings -> Pages. Сайт сразу станет доступен в интернете!\n\n" +
                                "3. Vercel или Netlify:\nПеретащите папку 'web' на netlify.com/drop и получите готовую ссылку для всех пользователей."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("PyBlocks Web Info", "https://github.com/ (web/ folder)")
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Инструкция в файле web/README.md", Toast.LENGTH_SHORT).show()
                        showHowToHostDialog = false
                    }
                ) {
                    Text("OK")
                }
            }
        )
    }
}
