package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArduinoCodeGenerator
import com.example.model.Block

@Composable
fun ArduinoConvertView(
    blocks: List<Block>,
    onOpenSimulator: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val arduinoCode = remember(blocks) {
        ArduinoCodeGenerator.generateArduinoIno(blocks)
    }

    var selectedTab by remember { mutableStateOf(0) } // 0: Код C++, 1: Пошаговая инструкция

    val primaryRed = Color(0xFFE53935)
    val darkRed = Color(0xFFC62828)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FA))
            .padding(12.dp)
    ) {
        // Top Card Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = primaryRed,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "Конвертация в скетч Arduino",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF212121)
                            )
                            Text(
                                text = "Готовый код C++ (.ino) для загрузки на плату",
                                fontSize = 12.sp,
                                color = Color(0xFF616161)
                            )
                        }
                    }

                    // Test on simulator button
                    OutlinedButton(
                        onClick = onOpenSimulator,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryRed),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(primaryRed)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Тест платы", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs: [Код C++] and [Как загрузить на плату]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFEEEEEE))
                        .padding(3.dp)
                ) {
                    TabPill(
                        title = "Скетч Arduino (.ino)",
                        icon = Icons.Default.Code,
                        isSelected = selectedTab == 0,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 0 }
                    )
                    TabPill(
                        title = "Инструкция по загрузке",
                        icon = Icons.Default.MenuBook,
                        isSelected = selectedTab == 1,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 1 }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action Buttons: Copy and Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Arduino Sketch", arduinoCode)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Код скопирован в буфер обмена!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_arduino_code_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Скопировать код", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, arduinoCode)
                                putExtra(Intent.EXTRA_TITLE, "Arduino_Sketch.ino")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Поделиться скетчем Arduino"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_arduino_code_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Поделиться (.ino)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main Content Area
        if (selectedTab == 0) {
            // Code Editor Viewer
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF263238), RoundedCornerShape(12.dp)),
                color = Color(0xFF1E1E1E)
            ) {
                val verticalScroll = rememberScrollState()
                val horizontalScroll = rememberScrollState()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    val formattedCode = remember(arduinoCode) {
                        highlightArduinoCode(arduinoCode)
                    }

                    Text(
                        text = formattedCode,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier
                            .verticalScroll(verticalScroll)
                            .horizontalScroll(horizontalScroll)
                            .testTag("arduino_code_text")
                    )
                }
            }
        } else {
            // Instruction Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Инструкция: как загрузить код в плату через компьютер",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E1E1E)
                    )

                    InstructionStep(
                        number = "1",
                        title = "Установите Arduino IDE на ПК",
                        desc = "Скачайте бесплатную программу Arduino IDE с официального сайта arduino.cc (или используйте онлайн Arduino Cloud Editor в браузере).",
                        icon = Icons.Default.Computer
                    )

                    InstructionStep(
                        number = "2",
                        title = "Подключите плату к компьютеру",
                        desc = "Вставьте USB-кабель от вашей платы (Arduino Uno, Nano, Mega, ESP32) в любой свободный USB-порт компьютера.",
                        icon = Icons.Default.Usb
                    )

                    InstructionStep(
                        number = "3",
                        title = "Скопируйте и вставьте скетч",
                        desc = "Нажмите кнопку «Скопировать код» вверху этого экрана, откройте Arduino IDE, создайте новый файл и вставьте скопированный код.",
                        icon = Icons.Default.ContentPaste
                    )

                    InstructionStep(
                        number = "4",
                        title = "Выберите плату и COM-порт",
                        desc = "В меню Arduino IDE перейдите в «Инструменты» (Tools) → «Плата» (Board) → выберите вашу плату (напр. Arduino Uno), затем в меню «Порт» (Port) выберите появившийся COM-порт.",
                        icon = Icons.Default.Settings
                    )

                    InstructionStep(
                        number = "5",
                        title = "Нажмите «Загрузить» (Upload)",
                        desc = "Нажмите круглую кнопку со стрелочкой (Загрузить) вверху Arduino IDE. Через несколько секунд код загрузится на плату, и она сразу начнет работать!",
                        icon = Icons.Default.Publish
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFE8F5E9),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF81C784)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Готово! Светодиоды, моторы и сервоприводы будут слушаться вашей программы.",
                                fontSize = 12.sp,
                                color = Color(0xFF1B5E20),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) Color.White else Color.Transparent,
        shadowElevation = if (isSelected) 2.dp else 0.dp,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(vertical = 7.dp, horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color(0xFFE53935) else Color(0xFF757575),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color(0xFFE53935) else Color(0xFF757575)
            )
        }
    }
}

@Composable
private fun InstructionStep(
    number: String,
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFE53935).copy(alpha = 0.12f),
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = number,
                    color = Color(0xFFE53935),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF212121)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                fontSize = 12.sp,
                color = Color(0xFF555555),
                lineHeight = 16.sp
            )
        }
    }
}

private fun highlightArduinoCode(code: String) = buildAnnotatedString {
    val lines = code.lines()
    for ((index, line) in lines.withIndex()) {
        val trimmed = line.trimStart()

        if (trimmed.startsWith("//")) {
            // Comment
            withStyle(SpanStyle(color = Color(0xFF78909C))) {
                append(line)
            }
        } else if (trimmed.startsWith("#")) {
            // Preprocessor #include
            withStyle(SpanStyle(color = Color(0xFFFF7043), fontWeight = FontWeight.Bold)) {
                append(line)
            }
        } else {
            var i = 0
            while (i < line.length) {
                if (line.startsWith("//", i)) {
                    withStyle(SpanStyle(color = Color(0xFF78909C))) {
                        append(line.substring(i))
                    }
                    break
                }

                // Check keywords
                val word = extractWord(line, i)
                if (word != null) {
                    when (word) {
                        "void", "int", "long", "float", "bool", "char", "Servo" -> {
                            withStyle(SpanStyle(color = Color(0xFF4DD0E1), fontWeight = FontWeight.Bold)) {
                                append(word)
                            }
                        }
                        "setup", "loop", "digitalWrite", "digitalRead", "analogWrite", "analogRead",
                        "pinMode", "delay", "delayMicroseconds", "tone", "noTone", "map", "pulseIn" -> {
                            withStyle(SpanStyle(color = Color(0xFFFFB74D), fontWeight = FontWeight.Bold)) {
                                append(word)
                            }
                        }
                        "Serial", "HIGH", "LOW", "OUTPUT", "INPUT", "INPUT_PULLUP", "true", "false" -> {
                            withStyle(SpanStyle(color = Color(0xFF81C784), fontWeight = FontWeight.Bold)) {
                                append(word)
                            }
                        }
                        "if", "else", "for", "while", "return" -> {
                            withStyle(SpanStyle(color = Color(0xFFBA68C8), fontWeight = FontWeight.Bold)) {
                                append(word)
                            }
                        }
                        else -> {
                            withStyle(SpanStyle(color = Color(0xFFECEFF1))) {
                                append(word)
                            }
                        }
                    }
                    i += word.length
                } else {
                    val ch = line[i]
                    val color = when (ch) {
                        '{', '}', '(', ')', ';', ',' -> Color(0xFFB0BEC5)
                        '+', '-', '*', '/', '=', '>', '<', '!' -> Color(0xFFFFAB91)
                        else -> Color(0xFFECEFF1)
                    }
                    withStyle(SpanStyle(color = color)) {
                        append(ch)
                    }
                    i++
                }
            }
        }
        if (index < lines.size - 1) append("\n")
    }
}

private fun extractWord(line: String, startIndex: Int): String? {
    if (!line[startIndex].isLetterOrDigit() && line[startIndex] != '_') return null
    var end = startIndex
    while (end < line.length && (line[end].isLetterOrDigit() || line[end] == '_')) {
        end++
    }
    return line.substring(startIndex, end)
}
