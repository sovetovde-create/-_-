package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PythonCodeView(
    pythonCode: String,
    onRunSimulator: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lines = remember(pythonCode) { pythonCode.lines() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF181825))
    ) {
        // Top Toolbar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1E1E2E),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "main.py",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFCDD6F4),
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF313244)
                        ) {
                            Text(
                                text = "Python 3",
                                fontSize = 11.sp,
                                color = Color(0xFFA6ADC8),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Строк: ${lines.size} • Готов к экспорту",
                        fontSize = 11.sp,
                        color = Color(0xFF6C7086)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Copy button
                    FilledTonalButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Python Code", pythonCode)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Код скопирован в буфер обмена!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF313244),
                            contentColor = Color(0xFFCDD6F4)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Копия", fontSize = 12.sp)
                    }

                    // Share button (.py)
                    FilledTonalButton(
                        onClick = {
                            val sendIntent: Intent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, pythonCode)
                                putExtra(Intent.EXTRA_TITLE, "main.py")
                                type = "text/plain"
                            }
                            val shareIntent = Intent.createChooser(sendIntent, "Экспортировать Python-код")
                            context.startActivity(shareIntent)
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF45475A),
                            contentColor = Color(0xFF89B4FA)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(".py", fontSize = 12.sp)
                    }

                    // Run button
                    Button(
                        onClick = onRunSimulator,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFE53935),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Старт", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Code Editor Canvas with Line Numbers
        SelectionContainer(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Line numbers gutter
                Column(
                    modifier = Modifier
                        .background(Color(0xFF11111B))
                        .padding(horizontal = 10.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    lines.indices.forEach { index ->
                        Text(
                            text = "${index + 1}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFF585B70),
                            lineHeight = 20.sp
                        )
                    }
                }

                // Code text with horizontal scroll
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = buildHighlightedCode(pythonCode),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

fun buildHighlightedCode(code: String): AnnotatedString {
    return buildAnnotatedString {
        val keywords = setOf(
            "def", "return", "if", "elif", "else", "for", "in", "while",
            "break", "continue", "pass", "import", "from", "as", "try",
            "except", "with", "open", "print", "input", "range", "len",
            "int", "str", "True", "False", "None", "not", "and", "or"
        )

        val lines = code.lines()
        lines.forEachIndexed { lineIdx, line ->
            var i = 0
            val len = line.length

            while (i < len) {
                // Comment
                if (line[i] == '#') {
                    val commentText = line.substring(i)
                    pushStyle(SpanStyle(color = Color(0xFF6C7086), fontStyle = androidx.compose.ui.text.font.FontStyle.Italic))
                    append(commentText)
                    pop()
                    i = len
                    break
                }

                // String literal (double or single quote)
                if (line[i] == '"' || line[i] == '\'') {
                    val quote = line[i]
                    val start = i
                    i++
                    while (i < len && line[i] != quote) {
                        if (line[i] == '\\' && i + 1 < len) i++
                        i++
                    }
                    if (i < len) i++ // include closing quote
                    val strLiteral = line.substring(start, i)
                    pushStyle(SpanStyle(color = Color(0xFFA6E3A1))) // Soft green
                    append(strLiteral)
                    pop()
                    continue
                }

                // f-string prefix
                if ((line[i] == 'f' || line[i] == 'F') && i + 1 < len && (line[i + 1] == '"' || line[i + 1] == '\'')) {
                    pushStyle(SpanStyle(color = Color(0xFFF38BA8), fontWeight = FontWeight.Bold))
                    append("f")
                    pop()
                    i++
                    continue
                }

                // Identifiers / words
                if (line[i].isLetter() || line[i] == '_') {
                    val start = i
                    while (i < len && (line[i].isLetterOrDigit() || line[i] == '_')) {
                        i++
                    }
                    val word = line.substring(start, i)
                    if (keywords.contains(word)) {
                        val color = when (word) {
                            "def", "return", "class" -> Color(0xFFCBA6F7) // Purple
                            "if", "elif", "else", "for", "while", "break", "continue" -> Color(0xFFF38BA8) // Coral Pink
                            "import", "from", "as", "try", "except", "with" -> Color(0xFFFAB387) // Peach/Orange
                            "True", "False", "None" -> Color(0xFF89B4FA) // Blue
                            "print", "input", "range", "len", "int", "str" -> Color(0xFF89DCEB) // Cyan built-in
                            else -> Color(0xFFF9E2AF)
                        }
                        pushStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold))
                        append(word)
                        pop()
                    } else {
                        // Regular variable / function name
                        pushStyle(SpanStyle(color = Color(0xFFCDD6F4)))
                        append(word)
                        pop()
                    }
                    continue
                }

                // Numbers
                if (line[i].isDigit()) {
                    val start = i
                    while (i < len && (line[i].isDigit() || line[i] == '.')) {
                        i++
                    }
                    pushStyle(SpanStyle(color = Color(0xFFFAB387))) // Warm amber
                    append(line.substring(start, i))
                    pop()
                    continue
                }

                // Operators & punctuation
                val c = line[i]
                val opColor = when (c) {
                    '=', '+', '-', '*', '/', '%', '<', '>', '!' -> Color(0xFF89DCEB) // Cyan
                    '(', ')', '[', ']', '{', '}' -> Color(0xFFBAC2DE) // Lavender
                    ':', ',', '.' -> Color(0xFF9399B2)
                    else -> Color(0xFFCDD6F4)
                }
                pushStyle(SpanStyle(color = opColor))
                append(c.toString())
                pop()
                i++
            }

            if (lineIdx < lines.size - 1) {
                append("\n")
            }
        }
    }
}
