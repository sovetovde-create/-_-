package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Block
import com.example.model.BlockField
import com.example.model.BlockType

@Composable
fun BlockEditDialog(
    block: Block,
    availableVariables: List<String> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (Block) -> Unit
) {
    val fieldDefs = remember(block.type) { Block.getFieldDefinitions(block.type) }
    val editedFields = remember { mutableStateMapOf<String, String>().apply { putAll(block.fields) } }
    val editedNested = remember { mutableStateMapOf<String, Block>().apply { putAll(block.nestedBlocks) } }
    var activeFieldKey by remember { mutableStateOf(fieldDefs.firstOrNull()?.key ?: "") }

    // Slot picker dialog state
    var slotPickerTargetKey by remember { mutableStateOf<String?>(null) }
    // Sub-dialog to edit nested block inside slot
    var editingSubBlockKey by remember { mutableStateOf<String?>(null) }

    val category = block.type.category
    val headerColor = Color(category.hexColor)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with Scratch badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Настройка блока",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = block.type.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = headerColor
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Закрыть")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Editable Fields & Block Slots
                if (fieldDefs.isEmpty()) {
                    Text(
                        text = "У этого блока нет параметров (выполняется как самостоятельная команда).",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    fieldDefs.forEach { fieldDef ->
                        val currentValue = editedFields[fieldDef.key] ?: fieldDef.defaultValue
                        val slottedBlock = editedNested[fieldDef.key]

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = fieldDef.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (fieldDef.acceptsBlock && slottedBlock == null) {
                                TextButton(
                                    onClick = { slotPickerTargetKey = fieldDef.key },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Вставить блок в слот", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        if (slottedBlock != null) {
                            // Render slotted block badge
                            val slotCat = slottedBlock.type.category
                            val slotColor = Color(slotCat.hexColor)
                            val slotBorder = Color(slotCat.hexBorderColor)

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(2.dp, slotBorder, RoundedCornerShape(10.dp)),
                                color = slotColor,
                                contentColor = Color.White
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                Icons.Default.Extension,
                                                null,
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = slottedBlock.type.displayName,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            // Edit nested block
                                            IconButton(
                                                onClick = { editingSubBlockKey = fieldDef.key },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Edit,
                                                    contentDescription = "Настроить вложенный блок",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            // Remove nested block
                                            IconButton(
                                                onClick = { editedNested.remove(fieldDef.key) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Close,
                                                    contentDescription = "Убрать блок",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Display parameters of nested block
                                    val nestedParams = slottedBlock.fields.entries.joinToString(", ") { "${it.key}: ${it.value}" }
                                    if (nestedParams.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = nestedParams,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color.White.copy(alpha = 0.9f)
                                        )
                                    }
                                }
                            }
                        } else {
                            // Standard field with optional slot insertion hint
                            OutlinedTextField(
                                value = currentValue,
                                onValueChange = {
                                    editedFields[fieldDef.key] = it
                                    activeFieldKey = fieldDef.key
                                },
                                placeholder = { Text(fieldDef.hint, fontSize = 13.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp
                                ),
                                singleLine = block.type != BlockType.RAW_PY,
                                maxLines = if (block.type == BlockType.RAW_PY) 4 else 1,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                // Quick Helper Tokens (shortcuts to insert variables, strings, operators, or Arduino Pins)
                val isArduinoBlock = block.type.category.isArduino

                if (isArduinoBlock) {
                    Text(
                        text = "Пины Arduino Uno (выбери для активного поля):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC62828)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val unoPins = listOf(
                        "13", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2",
                        "A0", "A1", "A2", "A3", "A4", "A5"
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(unoPins) { pin ->
                            val isPwm = pin in listOf("3", "5", "6", "9", "10", "11")
                            val isAnalog = pin.startsWith("A")
                            val label = when {
                                pin == "13" -> "13 (LED)"
                                isPwm -> "$pin (~ШИМ)"
                                isAnalog -> "$pin (Анал)"
                                else -> "Пин $pin"
                            }

                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(1.dp, if (isPwm) Color(0xFFFB8C00) else Color(0xFFBDBDBD), RoundedCornerShape(6.dp))
                                    .clickable {
                                        if (activeFieldKey.isNotEmpty()) {
                                            editedFields[activeFieldKey] = pin
                                        }
                                    },
                                color = if (isPwm) Color(0xFFFFF3E0) else Color(0xFFF5F5F5)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isPwm) Color(0xFFE65100) else Color(0xFF212121),
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Параметры и значения Arduino:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E88E5)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val arduinoShortcuts = listOf(
                        "HIGH", "LOW", "OUTPUT", "INPUT", "INPUT_PULLUP",
                        "0x27", "0x3C", "0x3F", "\"Hello!\"", "ВКЛ", "ВЫКЛ",
                        "255", "128", "0", "Вперед", "Назад", "Стоп",
                        "90", "180", "440", "1000", "500", "16", "2", "64"
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(arduinoShortcuts) { shortcut ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(6.dp))
                                    .clickable {
                                        if (activeFieldKey.isNotEmpty()) {
                                            editedFields[activeFieldKey] = shortcut
                                        }
                                    },
                                color = Color(0xFFE3F2FD)
                            ) {
                                Text(
                                    text = shortcut,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF0D47A1),
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Быстрые вставки значений:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val quickTokens = remember(availableVariables) {
                        val list = mutableListOf(
                            "\"текст\"", "0", "1", "x", "result", "True", "False",
                            "+", "-", "*", "/", "==", "!=", "<", ">",
                            "len()", "range()", "randint(1, 10)", "int()"
                        )
                        availableVariables.forEach { v ->
                            if (!list.contains(v)) list.add(0, v)
                        }
                        list
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(quickTokens) { token ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
                                    .clickable {
                                        if (activeFieldKey.isNotEmpty()) {
                                            val cur = editedFields[activeFieldKey] ?: ""
                                            editedFields[activeFieldKey] = if (cur.isEmpty()) token else "$cur $token"
                                        }
                                    },
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            ) {
                                Text(
                                    text = token,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Отмена")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val updated = block.copy(
                                fields = editedFields.toMap(),
                                nestedBlocks = editedNested.toMap()
                            )
                            onSave(updated)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = headerColor)
                    ) {
                        Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Сохранить")
                    }
                }
            }
        }
    }

    // Modal to pick a nested block into a field slot
    slotPickerTargetKey?.let { targetKey ->
        NestedBlockPickerDialog(
            title = "Вставить команду/выражение",
            onSelectBlock = { selectedBlock ->
                editedNested[targetKey] = selectedBlock
                slotPickerTargetKey = null
            },
            onDismiss = { slotPickerTargetKey = null }
        )
    }

    // Modal to edit the chosen nested block
    editingSubBlockKey?.let { targetKey ->
        val subBlock = editedNested[targetKey]
        if (subBlock != null) {
            BlockEditDialog(
                block = subBlock,
                availableVariables = availableVariables,
                onDismiss = { editingSubBlockKey = null },
                onSave = { updatedSubBlock ->
                    editedNested[targetKey] = updatedSubBlock
                    editingSubBlockKey = null
                }
            )
        }
    }
}

