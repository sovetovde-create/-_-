package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppLanguage
import com.example.model.Localization
import com.example.model.Project
import com.example.model.ProjectType
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    projects: List<Project>,
    onOpenProject: (Project) -> Unit,
    onCreateProject: (ProjectType, String) -> Unit,
    onRenameProject: (String, String) -> Unit,
    onDeleteProject: (String) -> Unit,
    modifier: Modifier = Modifier,
    language: AppLanguage = AppLanguage.DEFAULT,
    onOpenSettings: () -> Unit = {},
    onOpenWebVersion: () -> Unit = {}
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var projectToRename by remember { mutableStateOf<Project?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var projectToDelete by remember { mutableStateOf<Project?>(null) }

    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    // Palette Colors: White & Red
    val primaryRed = Color(0xFFE53935)
    val darkRed = Color(0xFFC62828)
    val accentRed = Color(0xFFFF1744)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ==========================================
            // TOP SECTION: RED BANNER WITH WHITE CIRCLE & RED PLUS
            // "сверху красная [линия/плашка] в посередине там белый кружок и в этом белом кружке красный плюсик"
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                // Red background header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(darkRed, primaryRed)
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    // Web Version & Settings Buttons in top right
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onOpenWebVersion,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("home_web_version_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = Localization.get(language, "web_version"),
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("home_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = Localization.get(language, "settings"),
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text(
                                    text = " PyBlocks ",
                                    color = darkRed,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "& Arduino",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = Localization.get(language, "python_arduino_desc"),
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                }

                // Centered White Circle with Red Plus Sign (+)
                // "в посередине там белый кружок и в этом белом кружке красный плюсик"
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(3.dp, Color(0xFFFFCDD2)),
                    modifier = Modifier
                        .size(66.dp)
                        .align(Alignment.BottomCenter)
                        .testTag("create_project_fab")
                        .clickable { showCreateDialog = true }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = Localization.get(language, "create_project"),
                            tint = primaryRed,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Projects Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = Localization.get(language, "my_projects"),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121)
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF0F0F0)
                ) {
                    Text(
                        text = "Всего: ${projects.size}",
                        fontSize = 12.sp,
                        color = Color(0xFF616161),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // ==========================================
            // BOTTOM SECTION: ROUNDED RECTANGLE CARDS
            // "снизу изображается такие прямоугольнички скруглёнными краями где название проекта и карандаши продолжать"
            // ==========================================
            if (projects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = Color(0xFFBDBDBD),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Пока нет проектов",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF757575)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Нажмите на красный плюсик в кружке вверху,\nчтобы создать свой первый проект!",
                            fontSize = 13.sp,
                            color = Color(0xFF9E9E9E),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp)
                ) {
                    items(projects, key = { it.id }) { project ->
                        ProjectRoundedCard(
                            project = project,
                            dateFormat = dateFormat,
                            onOpen = { onOpenProject(project) },
                            onRename = {
                                projectToRename = project
                                renameInputText = project.name
                            },
                            onDelete = { projectToDelete = project }
                        )
                    }
                }
            }
        }
    }

    // ==========================================
    // CREATE PROJECT DIALOG (Python or Arduino)
    // "когда ты нажимаешь на плюс создать проект вот тут-то и начинается самое главное ты нажимаешь либо python либо arduino"
    // ==========================================
    if (showCreateDialog) {
        CreateProjectDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { type, name ->
                showCreateDialog = false
                onCreateProject(type, name)
            }
        )
    }

    // Rename Dialog (Карандашик)
    // "и на карандашик ты можешь изменить название проекта"
    projectToRename?.let { proj ->
        AlertDialog(
            onDismissRequest = { projectToRename = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = primaryRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Изменить название проекта", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text("Введите новое название для проекта:", fontSize = 13.sp, color = Color(0xFF616161))
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = renameInputText,
                        onValueChange = { renameInputText = it },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rename_project_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryRed,
                            unfocusedBorderColor = Color(0xFFDCDCDC)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = renameInputText.trim()
                        if (trimmed.isNotEmpty()) {
                            onRenameProject(proj.id, trimmed)
                        }
                        projectToRename = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = primaryRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Сохранить", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToRename = null }) {
                    Text("Отмена", color = Color(0xFF757575))
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // Delete Confirmation Dialog
    projectToDelete?.let { proj ->
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = { Text("Удалить проект?") },
            text = { Text("Вы уверены, что хотите удалить «${proj.name}»? Это действие нельзя отменить.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProject(proj.id)
                        projectToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = darkRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text("Отмена")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }
}

// ==========================================
// INDIVIDUAL ROUNDED PROJECT CARD
// "снизу изображается такие прямоугольнички скруглёнными краями где название проекта и карандаши продолжать"
// ==========================================
@Composable
private fun ProjectRoundedCard(
    project: Project,
    dateFormat: SimpleDateFormat,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val primaryRed = Color(0xFFE53935)
    val isArduino = project.type == ProjectType.ARDUINO

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(16.dp))
            .clickable { onOpen() }
            .testTag("project_card_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Top Row: Type Badge + Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Type Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isArduino) Color(0xFFFFEBEE) else Color(0xFFFFF3E0),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isArduino) Color(0xFFFFCDD2) else Color(0xFFFFE0B2)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isArduino) Icons.Default.Memory else Icons.Default.Code,
                            contentDescription = null,
                            tint = if (isArduino) primaryRed else Color(0xFFE65100),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isArduino) "ARDUINO" else "PYTHON",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isArduino) primaryRed else Color(0xFFE65100)
                        )
                    }
                }

                Text(
                    text = "${project.blocks.size} блоков • ${dateFormat.format(Date(project.updatedAt))}",
                    fontSize = 11.sp,
                    color = Color(0xFF757575)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Project Name & Pencil Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = project.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121),
                    modifier = Modifier.weight(1f)
                )

                // Pencil button ("и на карандашик ты можешь изменить название проекта")
                IconButton(
                    onClick = onRename,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("rename_button_${project.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Изменить название",
                        tint = primaryRed,
                        modifier = Modifier.size(19.dp)
                    )
                }

                // Delete button
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Удалить проект",
                        tint = Color(0xFF9E9E9E),
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            if (project.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = project.description,
                    fontSize = 12.sp,
                    color = Color(0xFF616161),
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // "Продолжить" Button ("и карандаши продолжать")
            Button(
                onClick = onOpen,
                colors = ButtonDefaults.buttonColors(containerColor = primaryRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("continue_button_${project.id}")
            ) {
                Text(
                    text = "Продолжить",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// ==========================================
// CREATE NEW PROJECT MODAL DIALOG
// Choice between Python and Arduino
// ==========================================
@Composable
private fun CreateProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (ProjectType, String) -> Unit
) {
    val primaryRed = Color(0xFFE53935)
    var projectName by remember { mutableStateOf("Мой проект") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Создать проект",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF212121)
                    )

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = Color(0xFF757575))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Name field
                Text(
                    text = "Название проекта:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF424242)
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryRed,
                        unfocusedBorderColor = Color(0xFFDCDCDC)
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Выберите тип проекта:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF424242)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Option 1: Arduino Project
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFEBEE),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, primaryRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            val name = if (projectName.isNotBlank()) projectName.trim() else "Проект Arduino"
                            onCreate(ProjectType.ARDUINO, name)
                        }
                        .testTag("select_arduino_project_type")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = primaryRed,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Memory,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "⚡ Arduino",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryRed
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Блоки для платы: лампочки, сервоприводы, моторы, датчики + конвертация в скетч (.ino)",
                                fontSize = 11.sp,
                                color = Color(0xFF555555),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Option 2: Python Project
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF5F5F5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDCDCDC)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            val name = if (projectName.isNotBlank()) projectName.trim() else "Проект Python"
                            onCreate(ProjectType.PYTHON, name)
                        }
                        .testTag("select_python_project_type")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEF6C00),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🐍 Python",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Блочное программирование скриптов, диалоги, списки, циклы и живая консоль",
                                fontSize = 11.sp,
                                color = Color(0xFF555555),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
