package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ConsoleOutput
import com.example.engine.LogType
import com.example.engine.PythonSimulator
import com.example.model.*
import com.example.repository.ProjectRepository
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class ScreenMode {
    HOME,
    EDITOR
}

data class AddContext(
    val parentId: String? = null,
    val isSecondary: Boolean = false
)

class PyBlocksViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProjectRepository(application.applicationContext)

    private val _currentScreen = MutableStateFlow(ScreenMode.HOME)
    val currentScreen: StateFlow<ScreenMode> = _currentScreen.asStateFlow()

    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _currentProject = MutableStateFlow(SampleProjects.all.first())
    val currentProject: StateFlow<Project> = _currentProject.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Blocks, 1: Python Code, 2: Console
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _isPickerOpen = MutableStateFlow(false)
    val isPickerOpen: StateFlow<Boolean> = _isPickerOpen.asStateFlow()

    private val _addContext = MutableStateFlow(AddContext())
    val addContext: StateFlow<AddContext> = _addContext.asStateFlow()

    private val _editingBlock = MutableStateFlow<Block?>(null)
    val editingBlock: StateFlow<Block?> = _editingBlock.asStateFlow()

    private val _showProjectsDialog = MutableStateFlow(false)
    val showProjectsDialog: StateFlow<Boolean> = _showProjectsDialog.asStateFlow()

    private val _showLibrariesDialog = MutableStateFlow(false)
    val showLibrariesDialog: StateFlow<Boolean> = _showLibrariesDialog.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _showWebPreviewDialog = MutableStateFlow(false)
    val showWebPreviewDialog: StateFlow<Boolean> = _showWebPreviewDialog.asStateFlow()

    private val _appLanguage = MutableStateFlow(repository.getLanguage())
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    // Simulator State
    private val _consoleOutputs = MutableStateFlow<List<ConsoleOutput>>(emptyList())
    val consoleOutputs: StateFlow<List<ConsoleOutput>> = _consoleOutputs.asStateFlow()

    private val _isSimulatorRunning = MutableStateFlow(false)
    val isSimulatorRunning: StateFlow<Boolean> = _isSimulatorRunning.asStateFlow()

    private val _pendingPrompt = MutableStateFlow<String?>(null)
    val pendingPrompt: StateFlow<String?> = _pendingPrompt.asStateFlow()

    private var inputDeferred: CompletableDeferred<String>? = null
    private var simulatorJob: Job? = null
    private var currentSimulator: PythonSimulator? = null

    init {
        loadProjects()
    }

    private fun loadProjects() {
        val loaded = repository.getProjects()
        _projects.value = loaded
        if (loaded.isNotEmpty()) {
            _currentProject.value = loaded.first()
        }
    }

    fun setSelectedTab(tab: Int) {
        _selectedTab.value = tab
    }

    fun openPicker(parentId: String? = null, isSecondary: Boolean = false) {
        _addContext.value = AddContext(parentId, isSecondary)
        _isPickerOpen.value = true
    }

    fun closePicker() {
        _isPickerOpen.value = false
    }

    fun openEditBlock(block: Block) {
        _editingBlock.value = block
    }

    fun closeEditBlock() {
        _editingBlock.value = null
    }

    fun setShowProjectsDialog(show: Boolean) {
        _showProjectsDialog.value = show
    }

    fun setShowLibrariesDialog(show: Boolean) {
        _showLibrariesDialog.value = show
    }

    fun openSettings() {
        _showSettingsDialog.value = true
    }

    fun closeSettings() {
        _showSettingsDialog.value = false
    }

    fun openWebPreview() {
        _showWebPreviewDialog.value = true
    }

    fun closeWebPreview() {
        _showWebPreviewDialog.value = false
    }

    fun setLanguage(language: AppLanguage) {
        _appLanguage.value = language
        repository.saveLanguage(language)
    }

    fun getInstalledLibraryIds(): Set<String> {
        return _currentProject.value.blocks
            .filter { it.type == BlockType.IMPORT_LIBRARY }
            .map { it.getField("lib", "") }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    fun installLibrary(library: PythonLibrary) {
        val currentBlocks = _currentProject.value.blocks.toMutableList()
        val already = currentBlocks.any { it.type == BlockType.IMPORT_LIBRARY && it.getField("lib") == library.id }
        if (!already) {
            val importBlock = Block(
                type = BlockType.IMPORT_LIBRARY,
                fields = mapOf(
                    "lib" to library.id,
                    "name" to library.name
                )
            )
            currentBlocks.add(0, importBlock)
            saveCurrentProject(_currentProject.value.copy(blocks = currentBlocks))
        }
    }

    fun uninstallLibrary(library: PythonLibrary) {
        val currentBlocks = _currentProject.value.blocks
        val pruned = removeLibraryAndItsBlocksRecursively(currentBlocks, library)
        saveCurrentProject(_currentProject.value.copy(blocks = pruned))
    }

    private fun removeLibraryAndItsBlocksRecursively(blocks: List<Block>, library: PythonLibrary): List<Block> {
        return blocks
            .filterNot {
                (it.type == BlockType.IMPORT_LIBRARY && it.getField("lib") == library.id) ||
                        it.type.category == library.category
            }
            .map { block ->
                block.copy(
                    children = removeLibraryAndItsBlocksRecursively(block.children, library),
                    secondaryChildren = removeLibraryAndItsBlocksRecursively(block.secondaryChildren, library)
                )
            }
    }

    fun selectProject(project: Project) {
        _currentProject.value = project
    }

    fun navigateToHome() {
        _currentScreen.value = ScreenMode.HOME
    }

    fun navigateToEditor(project: Project) {
        _currentProject.value = project
        _selectedTab.value = 0
        _currentScreen.value = ScreenMode.EDITOR
    }

    fun createProject(type: ProjectType, name: String) {
        val newProj = SampleProjects.createEmptyProject(type, name)
        val updatedList = repository.saveProject(newProj)
        _projects.value = updatedList
        _currentProject.value = newProj
        _selectedTab.value = 0
        _currentScreen.value = ScreenMode.EDITOR
    }

    fun createNewProject() {
        createProject(ProjectType.PYTHON, "Новый проект")
    }

    fun renameProject(projectId: String, newName: String) {
        val currentList = _projects.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == projectId }
        if (index >= 0) {
            val updated = currentList[index].copy(name = newName, updatedAt = System.currentTimeMillis())
            saveCurrentProject(updated)
        }
    }

    fun deleteProject(projectId: String) {
        val updatedList = repository.deleteProject(projectId)
        _projects.value = updatedList
        if (_currentProject.value.id == projectId) {
            _currentProject.value = updatedList.firstOrNull() ?: SampleProjects.all.first()
        }
    }

    fun updateProjectName(newName: String) {
        val current = _currentProject.value
        val updated = current.copy(name = newName)
        saveCurrentProject(updated)
    }

    private fun saveCurrentProject(project: Project) {
        _currentProject.value = project
        val updatedList = repository.saveProject(project)
        _projects.value = updatedList
    }

    // --- Block Manipulation ---

    fun onBlockTypeChosen(type: BlockType) {
        val newBlock = Block.createDefault(type)
        val context = _addContext.value

        if (context.parentId == null) {
            // Add to root
            val updatedBlocks = _currentProject.value.blocks.toMutableList().apply {
                add(newBlock)
            }
            saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
        } else {
            // Add inside container
            val updatedBlocks = insertChildIntoBlocks(
                blocks = _currentProject.value.blocks,
                parentId = context.parentId,
                isSecondary = context.isSecondary,
                child = newBlock
            )
            saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
        }
    }

    fun updateBlock(updatedBlock: Block) {
        val updatedBlocks = updateBlockRecursively(_currentProject.value.blocks, updatedBlock)
        saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
    }

    fun moveBlock(index: Int, up: Boolean) {
        val currentList = _currentProject.value.blocks.toMutableList()
        val targetIndex = if (up) index - 1 else index + 1
        if (targetIndex in 0 until currentList.size) {
            val item = currentList.removeAt(index)
            currentList.add(targetIndex, item)
            saveCurrentProject(_currentProject.value.copy(blocks = currentList))
        }
    }

    fun reorderBlocks(fromIndex: Int, toIndex: Int) {
        if (fromIndex == toIndex) return
        val currentList = _currentProject.value.blocks.toMutableList()
        if (fromIndex in 0 until currentList.size && toIndex in 0 until currentList.size) {
            val item = currentList.removeAt(fromIndex)
            currentList.add(toIndex, item)
            saveCurrentProject(_currentProject.value.copy(blocks = currentList))
        }
    }

    fun duplicateBlock(index: Int) {
        val currentList = _currentProject.value.blocks.toMutableList()
        if (index in 0 until currentList.size) {
            val original = currentList[index]
            val duplicate = deepCopyBlock(original)
            currentList.add(index + 1, duplicate)
            saveCurrentProject(_currentProject.value.copy(blocks = currentList))
        }
    }

    fun deleteBlock(index: Int) {
        val currentList = _currentProject.value.blocks.toMutableList()
        if (index in 0 until currentList.size) {
            val deleted = currentList.removeAt(index)
            if (deleted.type == BlockType.IMPORT_LIBRARY) {
                val libId = deleted.getField("lib")
                val lib = PythonLibrary.findById(libId)
                if (lib != null) {
                    val pruned = removeLibraryAndItsBlocksRecursively(currentList, lib)
                    saveCurrentProject(_currentProject.value.copy(blocks = pruned))
                    return
                }
            }
            saveCurrentProject(_currentProject.value.copy(blocks = currentList))
        }
    }

    fun reorderChildBlocks(parentId: String, fromIndex: Int, toIndex: Int, isSecondary: Boolean) {
        if (fromIndex == toIndex) return
        val updatedBlocks = modifyChildListRecursively(_currentProject.value.blocks, parentId, isSecondary) { list ->
            if (fromIndex in 0 until list.size && toIndex in 0 until list.size) {
                val item = list.removeAt(fromIndex)
                list.add(toIndex, item)
            }
        }
        saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
    }

    fun moveChildBlock(parentId: String, childIndex: Int, up: Boolean, isSecondary: Boolean) {
        val updatedBlocks = modifyChildListRecursively(_currentProject.value.blocks, parentId, isSecondary) { list ->
            val targetIndex = if (up) childIndex - 1 else childIndex + 1
            if (targetIndex in 0 until list.size) {
                val item = list.removeAt(childIndex)
                list.add(targetIndex, item)
            }
        }
        saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
    }

    fun duplicateChildBlock(parentId: String, childIndex: Int, isSecondary: Boolean) {
        val updatedBlocks = modifyChildListRecursively(_currentProject.value.blocks, parentId, isSecondary) { list ->
            if (childIndex in 0 until list.size) {
                val duplicate = deepCopyBlock(list[childIndex])
                list.add(childIndex + 1, duplicate)
            }
        }
        saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
    }

    fun deleteChildBlock(parentId: String, childIndex: Int, isSecondary: Boolean) {
        var deletedBlock: Block? = null
        val updatedBlocks = modifyChildListRecursively(_currentProject.value.blocks, parentId, isSecondary) { list ->
            if (childIndex in 0 until list.size) {
                deletedBlock = list.removeAt(childIndex)
            }
        }
        if (deletedBlock?.type == BlockType.IMPORT_LIBRARY) {
            val libId = deletedBlock!!.getField("lib")
            val lib = PythonLibrary.findById(libId)
            if (lib != null) {
                val pruned = removeLibraryAndItsBlocksRecursively(updatedBlocks, lib)
                saveCurrentProject(_currentProject.value.copy(blocks = pruned))
                return
            }
        }
        saveCurrentProject(_currentProject.value.copy(blocks = updatedBlocks))
    }

    private fun insertChildIntoBlocks(
        blocks: List<Block>,
        parentId: String,
        isSecondary: Boolean,
        child: Block
    ): List<Block> {
        return blocks.map { block ->
            if (block.id == parentId) {
                if (isSecondary) {
                    block.copy(secondaryChildren = block.secondaryChildren + child)
                } else {
                    block.copy(children = block.children + child)
                }
            } else {
                block.copy(
                    children = insertChildIntoBlocks(block.children, parentId, isSecondary, child),
                    secondaryChildren = insertChildIntoBlocks(block.secondaryChildren, parentId, isSecondary, child)
                )
            }
        }
    }

    private fun updateBlockRecursively(blocks: List<Block>, updated: Block): List<Block> {
        return blocks.map { block ->
            if (block.id == updated.id) {
                updated
            } else {
                block.copy(
                    children = updateBlockRecursively(block.children, updated),
                    secondaryChildren = updateBlockRecursively(block.secondaryChildren, updated)
                )
            }
        }
    }

    private fun modifyChildListRecursively(
        blocks: List<Block>,
        parentId: String,
        isSecondary: Boolean,
        action: (MutableList<Block>) -> Unit
    ): List<Block> {
        return blocks.map { block ->
            if (block.id == parentId) {
                if (isSecondary) {
                    val list = block.secondaryChildren.toMutableList()
                    action(list)
                    block.copy(secondaryChildren = list)
                } else {
                    val list = block.children.toMutableList()
                    action(list)
                    block.copy(children = list)
                }
            } else {
                block.copy(
                    children = modifyChildListRecursively(block.children, parentId, isSecondary, action),
                    secondaryChildren = modifyChildListRecursively(block.secondaryChildren, parentId, isSecondary, action)
                )
            }
        }
    }

    private fun deepCopyBlock(block: Block): Block {
        return block.copy(
            id = UUID.randomUUID().toString(),
            children = block.children.map { deepCopyBlock(it) },
            secondaryChildren = block.secondaryChildren.map { deepCopyBlock(it) }
        )
    }

    fun getAvailableVariables(): List<String> {
        val detected = mutableSetOf<String>()
        collectVariables(_currentProject.value.blocks, detected)
        return detected.toList()
    }

    private fun collectVariables(blocks: List<Block>, acc: MutableSet<String>) {
        for (b in blocks) {
            val v = b.getField("var", "")
            if (v.isNotEmpty()) acc.add(v)
            val v2 = b.getField("list", "")
            if (v2.isNotEmpty()) acc.add(v2)
            val v3 = b.getField("dict", "")
            if (v3.isNotEmpty()) acc.add(v3)
            collectVariables(b.children, acc)
            collectVariables(b.secondaryChildren, acc)
        }
    }

    // --- Python Simulator Execution ---

    fun runSimulator() {
        stopSimulator()
        _selectedTab.value = 2 // Switch to Console
        _isSimulatorRunning.value = true

        val simulator = PythonSimulator(
            onOutput = { log ->
                _consoleOutputs.value = _consoleOutputs.value + log
            },
            onPromptInput = { prompt ->
                _pendingPrompt.value = prompt
                val def = CompletableDeferred<String>()
                inputDeferred = def
                val answer = def.await()
                _pendingPrompt.value = null
                _consoleOutputs.value = _consoleOutputs.value + ConsoleOutput("> $answer", LogType.STDOUT)
                answer
            }
        )
        currentSimulator = simulator

        simulatorJob = viewModelScope.launch {
            simulator.execute(_currentProject.value.blocks)
            _isSimulatorRunning.value = false
        }
    }

    fun stopSimulator() {
        currentSimulator?.terminate()
        simulatorJob?.cancel()
        inputDeferred?.cancel()
        _isSimulatorRunning.value = false
        _pendingPrompt.value = null
    }

    fun clearConsole() {
        _consoleOutputs.value = emptyList()
    }

    fun sendInput(input: String) {
        inputDeferred?.complete(input)
    }

    fun getGeneratedPython(): String {
        return CodeGenerator.generateFullScript(_currentProject.value.blocks, _currentProject.value.name)
    }
}
