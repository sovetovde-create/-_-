package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Block
import com.example.model.BlockCategory
import com.example.model.BlockType

@Composable
fun ScratchBlockItem(
    block: Block,
    index: Int,
    totalCount: Int,
    onEditBlock: (Block) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onAddInside: ((isSecondary: Boolean) -> Unit)? = null,
    onEditChildBlock: ((child: Block) -> Unit)? = null,
    onMoveChildUp: ((childIndex: Int, isSecondary: Boolean) -> Unit)? = null,
    onMoveChildDown: ((childIndex: Int, isSecondary: Boolean) -> Unit)? = null,
    onDuplicateChild: ((childIndex: Int, isSecondary: Boolean) -> Unit)? = null,
    onDeleteChild: ((childIndex: Int, isSecondary: Boolean) -> Unit)? = null,
    onAddChildInsideNested: ((parentChild: Block, isSecondary: Boolean) -> Unit)? = null,
    isBeingDragged: Boolean = false,
    dragModifier: Modifier = Modifier,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    val category = block.type.category
    val blockColor = Color(category.hexColor)
    val borderColor = if (isBeingDragged) Color(0xFFFFD54F) else Color(category.hexBorderColor)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = if (isBeingDragged) 8.dp else 4.dp)
    ) {
        // Main block card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(if (isBeingDragged) 10.dp else 2.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .border(if (isBeingDragged) 3.dp else 2.dp, borderColor, RoundedCornerShape(12.dp))
                .clickable { onEditBlock(block) },
            color = blockColor,
            contentColor = Color.White
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Header row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = getCategoryIcon(category),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = category.title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f),
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Drag handle & Action toggle
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = dragModifier
                                .padding(4.dp)
                                .size(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DragHandle,
                                contentDescription = "Перетащить",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { isExpanded = !isExpanded },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Меню действий",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Block content & interactive fields
                BlockContentRow(block = block, onEdit = { onEditBlock(block) })

                // Expandable Action buttons (Move up, down, duplicate, delete)
                AnimatedVisibility(visible = isExpanded) {
                    Column {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = Color.White.copy(alpha = 0.25f)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilledTonalIconButton(
                                    onClick = onMoveUp,
                                    enabled = index > 0,
                                    modifier = Modifier.size(34.dp),
                                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.2f),
                                        contentColor = Color.White,
                                        disabledContainerColor = Color.White.copy(alpha = 0.05f),
                                        disabledContentColor = Color.White.copy(alpha = 0.3f)
                                    )
                                ) {
                                    Icon(Icons.Default.ArrowUpward, "Вверх", modifier = Modifier.size(16.dp))
                                }

                                FilledTonalIconButton(
                                    onClick = onMoveDown,
                                    enabled = index < totalCount - 1,
                                    modifier = Modifier.size(34.dp),
                                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.2f),
                                        contentColor = Color.White,
                                        disabledContainerColor = Color.White.copy(alpha = 0.05f),
                                        disabledContentColor = Color.White.copy(alpha = 0.3f)
                                    )
                                ) {
                                    Icon(Icons.Default.ArrowDownward, "Вниз", modifier = Modifier.size(16.dp))
                                }

                                FilledTonalIconButton(
                                    onClick = onDuplicate,
                                    modifier = Modifier.size(34.dp),
                                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.2f),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.ContentCopy, "Дублировать", modifier = Modifier.size(16.dp))
                                }

                                FilledTonalIconButton(
                                    onClick = { onEditBlock(block) },
                                    modifier = Modifier.size(34.dp),
                                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.2f),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.Edit, "Изменить", modifier = Modifier.size(16.dp))
                                }
                            }

                            FilledTonalIconButton(
                                onClick = onDelete,
                                modifier = Modifier.size(34.dp),
                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                    containerColor = Color(0xFFD32F2F).copy(alpha = 0.85f),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Delete, "Удалить", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // If container block (e.g. IF, REPEAT, WHILE, DEF, TRY)
        if (block.type.isContainer) {
            ContainerSlotView(
                title = "Выполнить внутри:",
                accentColor = blockColor,
                borderColor = borderColor,
                children = block.children,
                onAddInside = { onAddInside?.invoke(false) },
                onEditChild = { child -> onEditChildBlock?.invoke(child) },
                onMoveUp = { childIdx -> onMoveChildUp?.invoke(childIdx, false) },
                onMoveDown = { childIdx -> onMoveChildDown?.invoke(childIdx, false) },
                onDuplicate = { childIdx -> onDuplicateChild?.invoke(childIdx, false) },
                onDelete = { childIdx -> onDeleteChild?.invoke(childIdx, false) }
            )

            // Secondary container (e.g. ELSE for IF_ELSE_SIMPLE or EXCEPT for TRY_DO)
            if (block.type.hasSecondaryContainer) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.5.dp, borderColor, RoundedCornerShape(8.dp)),
                    color = blockColor.copy(alpha = 0.9f),
                    contentColor = Color.White
                ) {
                    Text(
                        text = if (block.type == BlockType.IF_ELSE_SIMPLE) "Иначе:" else "Если возникла ошибка:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                ContainerSlotView(
                    title = "Выполнить в этой ветке:",
                    accentColor = blockColor,
                    borderColor = borderColor,
                    children = block.secondaryChildren,
                    onAddInside = { onAddInside?.invoke(true) },
                    onEditChild = { child -> onEditChildBlock?.invoke(child) },
                    onMoveUp = { childIdx -> onMoveChildUp?.invoke(childIdx, true) },
                    onMoveDown = { childIdx -> onMoveChildDown?.invoke(childIdx, true) },
                    onDuplicate = { childIdx -> onDuplicateChild?.invoke(childIdx, true) },
                    onDelete = { childIdx -> onDeleteChild?.invoke(childIdx, true) }
                )
            }
        }
    }
}

@Composable
fun ContainerSlotView(
    title: String,
    accentColor: Color,
    borderColor: Color,
    children: List<Block>,
    onAddInside: () -> Unit,
    onEditChild: (Block) -> Unit,
    onMoveUp: (Int) -> Unit,
    onMoveDown: (Int) -> Unit,
    onDuplicate: (Int) -> Unit,
    onDelete: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 14.dp, top = 2.dp, bottom = 2.dp)
    ) {
        // Indentation line
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight()
                .padding(vertical = 4.dp)
                .background(accentColor.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
        )

        Spacer(modifier = Modifier.width(8.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, borderColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
            color = Color.White.copy(alpha = 0.95f)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                if (children.isEmpty()) {
                    Text(
                        text = "Перетащи или добавь сюда блоки действия",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                } else {
                    children.forEachIndexed { childIdx, child ->
                        ScratchBlockItem(
                            block = child,
                            index = childIdx,
                            totalCount = children.size,
                            onEditBlock = onEditChild,
                            onMoveUp = { onMoveUp(childIdx) },
                            onMoveDown = { onMoveDown(childIdx) },
                            onDuplicate = { onDuplicate(childIdx) },
                            onDelete = { onDelete(childIdx) }
                        )
                    }
                }

                OutlinedButton(
                    onClick = onAddInside,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = accentColor),
                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Добавить блок внутрь", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun BlockContentRow(
    block: Block,
    onEdit: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (block.type) {
            // 1. Диалог
            BlockType.ASK_INPUT -> {
                Icon(Icons.Default.Chat, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Спросить")
                SlottedField(block, "question", "\"Как тебя зовут? \"", onEdit)
                BlockLabel("и сохранить в")
                PillField(block.getField("var", "имя"), onEdit)
            }
            BlockType.ASK_NUMBER -> {
                Icon(Icons.Default.Tag, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Спросить число")
                SlottedField(block, "question", "\"Сколько тебе лет? \"", onEdit)
                BlockLabel("и сохранить в")
                PillField(block.getField("var", "возраст"), onEdit)
            }
            BlockType.SAY -> {
                Icon(Icons.Default.VolumeUp, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Сказать")
                SlottedField(block, "text", "\"Привет!\"", onEdit)
            }
            BlockType.SAY_PHRASE -> {
                Icon(Icons.Default.RecordVoiceOver, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Сказать фразу:")
                PillField(block.getField("template", "Привет!"), onEdit)
            }
            BlockType.CLEAR_SCREEN -> {
                Icon(Icons.Default.CleaningServices, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Очистить экран")
            }

            // 2. Память
            BlockType.SET_VARIABLE -> {
                BlockLabel("Запомнить:")
                PillField(block.getField("var", "счет"), onEdit)
                BlockLabel("=")
                SlottedField(block, "value", "10", onEdit)
            }
            BlockType.CHANGE_BY -> {
                BlockLabel("Увеличить")
                PillField(block.getField("var", "счет"), onEdit)
                BlockLabel("на")
                SlottedField(block, "value", "1", onEdit)
            }
            BlockType.CALCULATE_INTO -> {
                PillField(block.getField("var", "итог"), onEdit)
                BlockLabel("=")
                SlottedField(block, "left", "5", onEdit)
                BlockLabel(block.getField("op", "+"))
                SlottedField(block, "right", "10", onEdit)
            }

            // 3. Управление
            BlockType.IF_SIMPLE -> {
                BlockLabel("Если")
                SlottedField(block, "condition", "счет > 0", onEdit)
                BlockLabel("то:")
            }
            BlockType.IF_ELSE_SIMPLE -> {
                BlockLabel("Если")
                SlottedField(block, "condition", "счет > 0", onEdit)
                BlockLabel("то:")
            }
            BlockType.REPEAT_TIMES -> {
                BlockLabel("Повторить")
                SlottedField(block, "times", "5", onEdit)
                BlockLabel("раз (счетчик:")
                PillField(block.getField("var", "i"), onEdit)
                BlockLabel("):")
            }
            BlockType.WHILE_LOOP -> {
                BlockLabel("Повторять, пока")
                SlottedField(block, "condition", "счет > 0", onEdit)
                BlockLabel(":")
            }
            BlockType.FOR_EACH_ITEM -> {
                BlockLabel("Для каждого")
                PillField(block.getField("item", "элемент"), onEdit)
                BlockLabel("из")
                SlottedField(block, "list", "список", onEdit)
                BlockLabel(":")
            }
            BlockType.WAIT_SECONDS -> {
                Icon(Icons.Default.HourglassEmpty, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Подождать")
                PillField(block.getField("seconds", "1"), onEdit)
                BlockLabel("сек")
            }
            BlockType.STOP_LOOP -> BlockLabel("Остановить цикл (выйти)")
            BlockType.NEXT_ROUND -> BlockLabel("Следующий круг цикла")
            BlockType.STOP_ALL -> BlockLabel("Завершить программу")

            // 4. Математика
            BlockType.EXPR_RANDOM_NUM -> {
                Icon(Icons.Default.Casino, null, tint = Color.White, modifier = Modifier.size(14.dp))
                BlockLabel("Случайное от")
                SlottedField(block, "from", "1", onEdit)
                BlockLabel("до")
                SlottedField(block, "to", "10", onEdit)
            }
            BlockType.EXPR_ROUND -> {
                BlockLabel("Округлить(")
                SlottedField(block, "number", "3.14", onEdit)
                BlockLabel(")")
            }
            BlockType.EXPR_ABS -> {
                BlockLabel("Модуль(")
                SlottedField(block, "number", "-5", onEdit)
                BlockLabel(")")
            }
            BlockType.EXPR_MATH_OP -> {
                BlockLabel("(")
                SlottedField(block, "left", "5", onEdit)
                BlockLabel(block.getField("op", "+"))
                SlottedField(block, "right", "10", onEdit)
                BlockLabel(")")
            }
            BlockType.EXPR_COMPARE_VALS -> {
                SlottedField(block, "left", "ответ", onEdit)
                BlockLabel(block.getField("op", "=="))
                SlottedField(block, "right", "\"да\"", onEdit)
            }

            // 5. Текст
            BlockType.TEXT_TO_UPPER -> {
                PillField(block.getField("save_to", "громкий"), onEdit)
                BlockLabel("= ЗАГЛАВНЫМИ(")
                PillField(block.getField("var", "текст"), onEdit)
                BlockLabel(")")
            }
            BlockType.TEXT_TO_LOWER -> {
                PillField(block.getField("save_to", "тихий"), onEdit)
                BlockLabel("= строчными(")
                PillField(block.getField("var", "текст"), onEdit)
                BlockLabel(")")
            }
            BlockType.TEXT_REPLACE -> {
                PillField(block.getField("save_to", "новый"), onEdit)
                BlockLabel("= в")
                PillField(block.getField("target", "текст"), onEdit)
                BlockLabel("заменить")
                PillField(block.getField("old", "\"кот\""), onEdit)
                BlockLabel("на")
                PillField(block.getField("new", "\"пёс\""), onEdit)
            }
            BlockType.EXPR_TEXT_CONTAINS -> {
                SlottedField(block, "word", "\"привет\"", onEdit)
                BlockLabel("есть в тексте")
                SlottedField(block, "text", "текст", onEdit)
                BlockLabel("?")
            }
            BlockType.EXPR_TEXT_LENGTH -> {
                BlockLabel("Длина текста(")
                SlottedField(block, "text", "текст", onEdit)
                BlockLabel(")")
            }

            // 6. Списки
            BlockType.CREATE_LIST -> {
                BlockLabel("Список")
                PillField(block.getField("var", "числа"), onEdit)
                BlockLabel("= [")
                PillField(block.getField("items", "1, 2, 3"), onEdit)
                BlockLabel("]")
            }
            BlockType.ADD_TO_LIST -> {
                BlockLabel("В список")
                PillField(block.getField("list", "числа"), onEdit)
                BlockLabel("добавить")
                SlottedField(block, "item", "6", onEdit)
            }
            BlockType.GET_FROM_LIST -> {
                PillField(block.getField("save_to", "элемент"), onEdit)
                BlockLabel("= из списка")
                PillField(block.getField("list", "числа"), onEdit)
                BlockLabel("№")
                SlottedField(block, "index", "0", onEdit)
            }
            BlockType.REMOVE_FROM_LIST -> {
                BlockLabel("Удалить из списка")
                PillField(block.getField("list", "числа"), onEdit)
                BlockLabel("элемент")
                SlottedField(block, "item", "6", onEdit)
            }
            BlockType.REVERSE_LIST -> {
                BlockLabel("Перевернуть список")
                PillField(block.getField("list", "числа"), onEdit)
            }
            BlockType.EXPR_RANDOM_CHOICE -> {
                BlockLabel("Случайный выбор из")
                PillField(block.getField("list", "числа"), onEdit)
            }
            BlockType.EXPR_LIST_SIZE -> {
                BlockLabel("Кол-во элементов в")
                PillField(block.getField("list", "числа"), onEdit)
            }

            // 7. Функции
            BlockType.CUSTOM_COMMAND_DEF -> {
                BlockLabel("Создать команду:")
                PillField(block.getField("name", "поздороваться"), onEdit)
                BlockLabel("параметры:")
                PillField(block.getField("params", "имя"), onEdit)
            }
            BlockType.CUSTOM_COMMAND_RUN -> {
                BlockLabel("Выполнить:")
                PillField(block.getField("call", "поздороваться(\"Алекс\")"), onEdit)
            }
            BlockType.GIVE_RESULT -> {
                BlockLabel("Вернуть ответ:")
                SlottedField(block, "value", "\"готово\"", onEdit)
            }

            // 8. Разное
            BlockType.ADD_NOTE -> {
                Icon(Icons.Default.EditNote, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Заметка:")
                PillField(block.getField("text", "пояснение"), onEdit)
            }
            BlockType.TRY_DO -> {
                BlockLabel("Попробовать сделать:")
            }
            BlockType.WRITE_FILE -> {
                BlockLabel("Записать в файл")
                PillField(block.getField("file", "\"заметка.txt\""), onEdit)
                BlockLabel("текст:")
                SlottedField(block, "text", "\"Привет!\"", onEdit)
            }
            BlockType.RAW_PY -> {
                BlockLabel("Код Python:")
                PillField(block.getField("code", "print()"), onEdit)
            }
            BlockType.CALCULATE_FORMULA_STRING -> {
                Icon(Icons.Default.Calculate, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Вычислить формулу")
                SlottedField(block, "formula", "\"2 + 2\"", onEdit)
                BlockLabel("в переменную")
                PillField(block.getField("var", "ответ"), onEdit)
            }
            BlockType.EVAL_EXPRESSION -> {
                Icon(Icons.Default.Calculate, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Вычислить (eval)")
                SlottedField(block, "expression", "\"10 * 5\"", onEdit)
            }

            // Arduino Blocks
            BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> {
                Icon(Icons.Default.Lightbulb, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Включить лампочку на пине")
                PillField(block.getField("pin", "13"), onEdit)
                BlockLabel("(HIGH)")
            }
            BlockType.ARDUINO_DIGITAL_WRITE_LOW -> {
                Icon(Icons.Default.Lightbulb, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Выключить лампочку на пине")
                PillField(block.getField("pin", "13"), onEdit)
                BlockLabel("(LOW)")
            }
            BlockType.ARDUINO_BLINK_LED -> {
                Icon(Icons.Default.Lightbulb, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Мигать лампочкой на пине")
                PillField(block.getField("pin", "13"), onEdit)
                BlockLabel("пауза")
                PillField(block.getField("delay_ms", "1000") + " мс", onEdit)
            }
            BlockType.ARDUINO_PWM_BRIGHTNESS -> {
                Icon(Icons.Default.BrightnessMedium, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Яркость лампочки (ШИМ) на пине")
                PillField(block.getField("pin", "9"), onEdit)
                BlockLabel(":")
                PillField(block.getField("brightness", "128"), onEdit)
            }
            BlockType.ARDUINO_PIN_MODE -> {
                Icon(Icons.Default.Settings, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Настроить пин")
                PillField(block.getField("pin", "13"), onEdit)
                BlockLabel("как")
                PillField(block.getField("mode", "OUTPUT"), onEdit)
            }
            BlockType.ARDUINO_TOGGLE_PIN -> {
                Icon(Icons.Default.ToggleOn, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Переключить состояние пина")
                PillField(block.getField("pin", "13"), onEdit)
            }
            BlockType.ARDUINO_SERVO_ATTACH -> {
                Icon(Icons.Default.RotateRight, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Подключить серво")
                PillField(block.getField("servo", "servo1"), onEdit)
                BlockLabel("к пину")
                PillField(block.getField("pin", "9"), onEdit)
            }
            BlockType.ARDUINO_SERVO_WRITE -> {
                Icon(Icons.Default.RotateRight, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Повернуть серво")
                PillField(block.getField("servo", "servo1"), onEdit)
                BlockLabel("на угол")
                PillField(block.getField("angle", "90") + "°", onEdit)
            }
            BlockType.ARDUINO_SERVO_SWEEP -> {
                Icon(Icons.Default.RotateRight, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Плавно повернуть")
                PillField(block.getField("servo", "servo1"), onEdit)
                BlockLabel("от")
                PillField(block.getField("from", "0") + "°", onEdit)
                BlockLabel("до")
                PillField(block.getField("to", "180") + "°", onEdit)
            }
            BlockType.ARDUINO_MOTOR_FORWARD -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Мотор")
                PillField(block.getField("motor", "M1"), onEdit)
                BlockLabel("вперед со скоростью")
                PillField(block.getField("speed", "255"), onEdit)
            }
            BlockType.ARDUINO_MOTOR_BACKWARD -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Мотор")
                PillField(block.getField("motor", "M1"), onEdit)
                BlockLabel("назад со скоростью")
                PillField(block.getField("speed", "255"), onEdit)
            }
            BlockType.ARDUINO_MOTOR_STOP -> {
                Icon(Icons.Default.StopCircle, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Остановить мотор")
                PillField(block.getField("motor", "M1"), onEdit)
            }
            BlockType.ARDUINO_L298N_DRIVER -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Драйвер L298N IN1")
                PillField(block.getField("in1", "5"), onEdit)
                BlockLabel("IN2")
                PillField(block.getField("in2", "6"), onEdit)
                BlockLabel("скорость")
                PillField(block.getField("speed", "255"), onEdit)
            }
            BlockType.ARDUINO_DIGITAL_READ -> {
                Icon(Icons.Default.Sensors, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Считать пин")
                PillField(block.getField("pin", "2"), onEdit)
                BlockLabel("в")
                PillField(block.getField("var", "кнопка"), onEdit)
            }
            BlockType.ARDUINO_ANALOG_READ -> {
                Icon(Icons.Default.Sensors, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Считать датчик")
                PillField(block.getField("pin", "A0"), onEdit)
                BlockLabel("в")
                PillField(block.getField("var", "датчик"), onEdit)
            }
            BlockType.ARDUINO_ULTRASONIC -> {
                Icon(Icons.Default.Sensors, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Дальномер HC-SR04 Trig")
                PillField(block.getField("trig", "7"), onEdit)
                BlockLabel("Echo")
                PillField(block.getField("echo", "6"), onEdit)
                BlockLabel("-> см в")
                PillField(block.getField("var", "дистанция"), onEdit)
            }
            BlockType.ARDUINO_IF_BUTTON -> {
                Icon(Icons.Default.TouchApp, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Если кнопка на пине")
                PillField(block.getField("pin", "2"), onEdit)
                BlockLabel("НАЖАТА, то:")
            }
            BlockType.ARDUINO_BUZZER_TONE -> {
                Icon(Icons.Default.VolumeUp, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Звук на пине")
                PillField(block.getField("pin", "8"), onEdit)
                BlockLabel("частота")
                PillField(block.getField("freq", "440") + " Гц", onEdit)
            }
            BlockType.ARDUINO_BUZZER_NOTONE -> {
                Icon(Icons.Default.VolumeMute, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Выключить звук на пине")
                PillField(block.getField("pin", "8"), onEdit)
            }
            BlockType.ARDUINO_BUZZER_BEEP -> {
                Icon(Icons.Default.NotificationsActive, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Короткий звуковой сигнал на пине")
                PillField(block.getField("pin", "8"), onEdit)
            }
            BlockType.ARDUINO_DELAY_MS -> {
                Icon(Icons.Default.Timer, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Подождать")
                PillField(block.getField("ms", "1000") + " мс", onEdit)
            }
            BlockType.ARDUINO_DELAY_SEC -> {
                Icon(Icons.Default.Timer, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Подождать")
                PillField(block.getField("sec", "1") + " сек", onEdit)
            }
            BlockType.ARDUINO_IF_ELSE -> {
                Icon(Icons.Default.AltRoute, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Если")
                PillField(block.getField("condition", "датчик > 500"), onEdit)
                BlockLabel("то: ... иначе:")
            }
            BlockType.ARDUINO_REPEAT_TIMES -> {
                Icon(Icons.Default.Repeat, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Повторить")
                PillField(block.getField("times", "10") + " раз:", onEdit)
            }
            BlockType.ARDUINO_LOOP_FOREVER -> {
                Icon(Icons.Default.AllInclusive, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Повторять всегда (цикл loop):")
            }
            BlockType.ARDUINO_VARIABLE_SET -> {
                Icon(Icons.Default.Memory, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Запомнить:")
                PillField(block.getField("var", "x"), onEdit)
                BlockLabel("=")
                PillField(block.getField("value", "0"), onEdit)
            }
            BlockType.ARDUINO_MAP_RANGE -> {
                Icon(Icons.Default.Transform, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Преобразовать в")
                PillField(block.getField("var", "результат"), onEdit)
                BlockLabel("значение")
                PillField(block.getField("input", "датчик"), onEdit)
            }
            BlockType.ARDUINO_SERIAL_BEGIN -> {
                Icon(Icons.Default.Usb, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Включить Serial на скорости")
                PillField(block.getField("baud", "9600") + " бод", onEdit)
            }
            BlockType.ARDUINO_SERIAL_PRINTLN -> {
                Icon(Icons.Default.Terminal, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Отправить в монитор порта строку")
                PillField(block.getField("text", "\"Привет!\""), onEdit)
            }
            BlockType.ARDUINO_SERIAL_PRINT_VAR -> {
                Icon(Icons.Default.Terminal, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Отправить в монитор значение")
                PillField(block.getField("var", "датчик"), onEdit)
            }
            // Motor driver blocks
            BlockType.ARDUINO_L298N_MOTOR_A -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("L298N Мотор A (IN1")
                PillField(block.getField("in1", "5"), onEdit)
                BlockLabel("IN2")
                PillField(block.getField("in2", "6"), onEdit)
                BlockLabel("):")
                PillField(block.getField("dir", "Вперед"), onEdit)
                BlockLabel("скорость")
                PillField(block.getField("speed", "255"), onEdit)
            }
            BlockType.ARDUINO_L298N_MOTOR_B -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("L298N Мотор B (IN3")
                PillField(block.getField("in3", "7"), onEdit)
                BlockLabel("IN4")
                PillField(block.getField("in4", "8"), onEdit)
                BlockLabel("):")
                PillField(block.getField("dir", "Вперед"), onEdit)
                BlockLabel("скорость")
                PillField(block.getField("speed", "255"), onEdit)
            }
            BlockType.ARDUINO_L298N_STOP_ALL -> {
                Icon(Icons.Default.StopCircle, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("L298N: Остановить все моторы (A и B)")
            }
            BlockType.ARDUINO_L9110S_MOTOR -> {
                Icon(Icons.Default.Toys, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("L9110S (Пин1")
                PillField(block.getField("pin1", "5"), onEdit)
                BlockLabel("Пин2")
                PillField(block.getField("pin2", "6"), onEdit)
                BlockLabel("):")
                PillField(block.getField("dir", "Вперед"), onEdit)
                PillField(block.getField("speed", "200"), onEdit)
            }
            BlockType.ARDUINO_STEPPER_STEP -> {
                Icon(Icons.Default.RotateRight, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("Шаговый 28BYJ-48 шагов:")
                PillField(block.getField("steps", "500"), onEdit)
                BlockLabel("об/мин")
                PillField(block.getField("rpm", "15"), onEdit)
            }
            BlockType.IMPORT_LIBRARY -> {
                Icon(Icons.Default.Extension, null, tint = Color.White, modifier = Modifier.size(16.dp))
                BlockLabel("📦 Подключить библиотеку:")
                PillField(block.getField("name", block.getField("lib", "")), onEdit)
            }
            else -> {
                BlockLabel(block.type.displayName)
                if (block.fields.isNotEmpty()) {
                    block.fields.forEach { (k, v) ->
                        PillField("$k: $v", onEdit)
                    }
                }
            }
        }
    }
}

@Composable
fun SlottedField(
    parentBlock: Block,
    key: String,
    defaultValue: String,
    onEdit: () -> Unit
) {
    val nested = parentBlock.getNested(key)
    if (nested != null) {
        val nestedColor = Color(nested.type.category.hexColor)
        Surface(
            modifier = Modifier
                .padding(horizontal = 3.dp, vertical = 2.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable { onEdit() },
            color = nestedColor,
            border = BorderStroke(1.5.dp, Color(nested.type.category.hexBorderColor)),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = getCategoryIcon(nested.type.category),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = nested.type.displayName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    } else {
        PillField(parentBlock.getField(key, defaultValue), onEdit)
    }
}

@Composable
private fun BlockLabel(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}

@Composable
private fun PillField(
    value: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 3.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = Color.White,
        shadowElevation = 1.dp
    ) {
        Text(
            text = value.ifEmpty { "..." },
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF1E1E2E),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

fun getCategoryIcon(category: BlockCategory) = when (category) {
    BlockCategory.DIALOG -> Icons.Default.Chat
    BlockCategory.VARIABLES -> Icons.Default.Memory
    BlockCategory.CONTROL -> Icons.Default.Repeat
    BlockCategory.NUMBERS_MATH -> Icons.Default.Calculate
    BlockCategory.TEXT_OPS -> Icons.Default.TextFields
    BlockCategory.LISTS -> Icons.Default.FormatListBulleted
    BlockCategory.FUNCTIONS -> Icons.Default.Code
    BlockCategory.ADVANCED -> Icons.Default.MoreHoriz

    // Python Extensions
    BlockCategory.EXT_NEURAL_NET -> Icons.Default.Psychology
    BlockCategory.EXT_API -> Icons.Default.CloudDownload
    BlockCategory.EXT_RANDOM -> Icons.Default.Casino
    BlockCategory.EXT_OS -> Icons.Default.Terminal
    BlockCategory.EXT_TIME -> Icons.Default.Schedule
    BlockCategory.EXT_MATH -> Icons.Default.Functions
    BlockCategory.EXT_GRAPHICS -> Icons.Default.SportsEsports
    BlockCategory.EXT_DATABASE -> Icons.Default.Storage

    // Arduino
    BlockCategory.ARDUINO_LEDS -> Icons.Default.Lightbulb
    BlockCategory.ARDUINO_SERVO -> Icons.Default.RotateRight
    BlockCategory.ARDUINO_MOTORS -> Icons.Default.Toys
    BlockCategory.ARDUINO_SENSORS -> Icons.Default.Sensors
    BlockCategory.ARDUINO_BUZZER -> Icons.Default.VolumeUp
    BlockCategory.ARDUINO_DISPLAYS -> Icons.Default.Tv
    BlockCategory.ARDUINO_CONTROL -> Icons.Default.Timer
    BlockCategory.ARDUINO_SERIAL -> Icons.Default.Usb
}
