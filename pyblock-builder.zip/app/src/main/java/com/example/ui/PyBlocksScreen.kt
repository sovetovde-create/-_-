package com.example.ui

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppLanguage
import com.example.model.Block
import com.example.model.Localization
import com.example.model.ProjectType
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PyBlocksScreen(
    viewModel: PyBlocksViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val showSettingsDialog by viewModel.showSettingsDialog.collectAsStateWithLifecycle()
    val showWebPreviewDialog by viewModel.showWebPreviewDialog.collectAsStateWithLifecycle()
    val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()

    // If on Home Screen, render the user's requested welcome screen
    if (currentScreen == ScreenMode.HOME) {
        HomeScreen(
            projects = projects,
            onOpenProject = { viewModel.navigateToEditor(it) },
            onCreateProject = { type, name -> viewModel.createProject(type, name) },
            onRenameProject = { id, name -> viewModel.renameProject(id, name) },
            onDeleteProject = { id -> viewModel.deleteProject(id) },
            modifier = modifier,
            language = appLanguage,
            onOpenSettings = { viewModel.openSettings() },
            onOpenWebVersion = { viewModel.openWebPreview() }
        )

        if (showSettingsDialog) {
            SettingsDialog(
                currentLanguage = appLanguage,
                onLanguageSelected = { lang -> viewModel.setLanguage(lang) },
                onOpenWebVersion = {
                    viewModel.closeSettings()
                    viewModel.openWebPreview()
                },
                onDismiss = { viewModel.closeSettings() }
            )
        }

        if (showWebPreviewDialog) {
            WebPreviewDialog(
                currentLanguage = appLanguage,
                onDismiss = { viewModel.closeWebPreview() }
            )
        }
        return
    }

    // Inside Editor
    BackHandler {
        viewModel.navigateToHome()
    }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val isArduino = currentProject.type == ProjectType.ARDUINO

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val isPickerOpen by viewModel.isPickerOpen.collectAsStateWithLifecycle()
    val editingBlock by viewModel.editingBlock.collectAsStateWithLifecycle()
    val showProjectsDialog by viewModel.showProjectsDialog.collectAsStateWithLifecycle()

    val consoleOutputs by viewModel.consoleOutputs.collectAsStateWithLifecycle()
    val isSimulatorRunning by viewModel.isSimulatorRunning.collectAsStateWithLifecycle()
    val pendingPrompt by viewModel.pendingPrompt.collectAsStateWithLifecycle()
    val showLibrariesDialog by viewModel.showLibrariesDialog.collectAsStateWithLifecycle()

    var showRenameDialog by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var showFileMenu by remember { mutableStateOf(false) }

    // In portrait, the side menu is hidden by default. In landscape, it is visible by default.
    var isPaletteVisible by remember { mutableStateOf(isLandscape) }

    LaunchedEffect(isLandscape) {
        isPaletteVisible = isLandscape
    }

    // White & Red Theme Palette
    val primaryRed = Color(0xFFE53935)
    val darkRed = Color(0xFFC62828)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isLandscape) 52.dp else 56.dp),
                color = primaryRed,
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: Back button to Projects + Badge + Project Name
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        // Back to Home Button
                        IconButton(
                            onClick = { viewModel.navigateToHome() },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("back_to_home_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "К проектам",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Project Type Badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Text(
                                text = if (isArduino) "Arduino" else "Python",
                                color = darkRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // "Файл" Menu Button
                        Box {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White.copy(alpha = 0.2f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showFileMenu = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Файл",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showFileMenu,
                                onDismissRequest = { showFileMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Все проекты") },
                                    leadingIcon = { Icon(Icons.Default.Home, null, tint = primaryRed) },
                                    onClick = {
                                        showFileMenu = false
                                        viewModel.navigateToHome()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Переименовать") },
                                    leadingIcon = { Icon(Icons.Default.Edit, null, tint = primaryRed) },
                                    onClick = {
                                        showFileMenu = false
                                        renameText = currentProject.name
                                        showRenameDialog = true
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Editable Project Name Box
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    renameText = currentProject.name
                                    showRenameDialog = true
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentProject.name,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = if (isLandscape) 130.dp else 75.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Переименовать",
                                    tint = Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(10.dp)
                                )
                            }
                        }
                    }

                    // Center: Tabs
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    ) {
                        TabHeaderItem(
                            title = Localization.get(appLanguage, "blocks"),
                            icon = Icons.Default.DashboardCustomize,
                            isSelected = selectedTab == 0,
                            isCompact = !isLandscape,
                            activeColor = primaryRed,
                            onClick = { viewModel.setSelectedTab(0) }
                        )

                        Spacer(modifier = Modifier.width(3.dp))

                        if (isArduino) {
                            TabHeaderItem(
                                title = Localization.get(appLanguage, "convert"),
                                icon = Icons.Default.Bolt,
                                isSelected = selectedTab == 1,
                                isCompact = !isLandscape,
                                activeColor = primaryRed,
                                onClick = { viewModel.setSelectedTab(1) }
                            )

                            Spacer(modifier = Modifier.width(3.dp))

                            TabHeaderItem(
                                title = Localization.get(appLanguage, "board_test"),
                                icon = Icons.Default.Memory,
                                isSelected = selectedTab == 2,
                                isCompact = !isLandscape,
                                activeColor = primaryRed,
                                onClick = { viewModel.setSelectedTab(2) }
                            )
                        } else {
                            TabHeaderItem(
                                title = Localization.get(appLanguage, "python"),
                                icon = Icons.Default.Code,
                                isSelected = selectedTab == 1,
                                isCompact = !isLandscape,
                                activeColor = primaryRed,
                                onClick = { viewModel.setSelectedTab(1) }
                            )

                            Spacer(modifier = Modifier.width(3.dp))

                            TabHeaderItem(
                                title = Localization.get(appLanguage, "console"),
                                icon = Icons.Default.Terminal,
                                isSelected = selectedTab == 2,
                                badge = isSimulatorRunning,
                                isCompact = !isLandscape,
                                activeColor = primaryRed,
                                onClick = { viewModel.setSelectedTab(2) }
                            )
                        }
                    }

                    // Right: Actions (Settings / Palette / Convert / Start)
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Web Version Button in top bar
                        IconButton(
                            onClick = { viewModel.openWebPreview() },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("toolbar_web_button")
                        ) {
                            Icon(
                                Icons.Default.Public,
                                contentDescription = Localization.get(appLanguage, "web_version"),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(3.dp))

                        // Settings Button in top bar
                        IconButton(
                            onClick = { viewModel.openSettings() },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("toolbar_settings_button")
                        ) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = Localization.get(appLanguage, "settings"),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(3.dp))

                        // Toggle Palette Button
                        IconButton(
                            onClick = { isPaletteVisible = !isPaletteVisible },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("toggle_palette_button")
                        ) {
                            Icon(
                                Icons.Default.ViewSidebar,
                                contentDescription = "Меню команд",
                                tint = if (isPaletteVisible) Color.White else Color.White.copy(alpha = 0.65f),
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(3.dp))

                        if (isArduino) {
                            // Arduino Convert Button in top bar
                            Surface(
                                onClick = { viewModel.setSelectedTab(1) },
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                shadowElevation = 2.dp,
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("toolbar_convert_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = "Конвертировать",
                                        tint = primaryRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = Localization.get(appLanguage, "code"),
                                        color = primaryRed,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        } else {
                            // Python START BUTTON
                            Surface(
                                onClick = {
                                    viewModel.setSelectedTab(2)
                                    viewModel.runSimulator()
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                shadowElevation = 2.dp,
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("run_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Старт",
                                        tint = primaryRed,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = Localization.get(appLanguage, "start"),
                                        color = primaryRed,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(3.dp))

                            // STOP Button
                            Surface(
                                onClick = { viewModel.stopSimulator() },
                                shape = CircleShape,
                                color = if (isSimulatorRunning) Color.White else Color.White.copy(alpha = 0.25f),
                                shadowElevation = if (isSimulatorRunning) 2.dp else 0.dp,
                                modifier = Modifier
                                    .size(30.dp)
                                    .testTag("stop_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Stop,
                                        contentDescription = "Остановить",
                                        tint = if (isSimulatorRunning) darkRed else Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isArduino) {
                        // User requested: red circle with white plus icon for Python libraries!
                        FloatingActionButton(
                            onClick = { viewModel.setShowLibrariesDialog(true) },
                            containerColor = primaryRed,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(50.dp)
                                .testTag("python_libraries_fab")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Дополнения (Библиотеки)", modifier = Modifier.size(24.dp))
                        }
                    }

                    if (!isLandscape && !isPaletteVisible) {
                        FloatingActionButton(
                            onClick = { isPaletteVisible = true },
                            containerColor = Color(0xFF212121),
                            contentColor = Color.White,
                            modifier = Modifier.testTag("open_palette_fab")
                        ) {
                            Icon(Icons.Default.Widgets, contentDescription = "Открыть меню команд")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    // BLOCKS CANVAS TAB
                    if (isLandscape) {
                        // Landscape Mode: Side-by-side
                        Row(modifier = Modifier.fillMaxSize()) {
                            if (isPaletteVisible) {
                                BlockPalettePane(
                                    onAddBlock = { type -> viewModel.onBlockTypeChosen(type) },
                                    isArduino = isArduino,
                                    installedLibraryIds = viewModel.getInstalledLibraryIds(),
                                    onOpenLibraries = { viewModel.setShowLibrariesDialog(true) },
                                    language = appLanguage,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(280.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {
                                ZoomableBlocksCanvas(
                                    blocks = currentProject.blocks,
                                    onAddBlock = { viewModel.openPicker() },
                                    onEditBlock = { viewModel.openEditBlock(it) },
                                    onMoveUp = { viewModel.moveBlock(it, up = true) },
                                    onMoveDown = { viewModel.moveBlock(it, up = false) },
                                    onReorder = { from, to -> viewModel.reorderBlocks(from, to) },
                                    onDuplicate = { viewModel.duplicateBlock(it) },
                                    onDelete = { viewModel.deleteBlock(it) },
                                    onAddInside = { parentId, isSecondary -> viewModel.openPicker(parentId, isSecondary) },
                                    onMoveChildUp = { parentId, childIdx, isSecondary -> viewModel.moveChildBlock(parentId, childIdx, up = true, isSecondary) },
                                    onMoveChildDown = { parentId, childIdx, isSecondary -> viewModel.moveChildBlock(parentId, childIdx, up = false, isSecondary) },
                                    onDuplicateChild = { parentId, childIdx, isSecondary -> viewModel.duplicateChildBlock(parentId, childIdx, isSecondary) },
                                    onDeleteChild = { parentId, childIdx, isSecondary -> viewModel.deleteChildBlock(parentId, childIdx, isSecondary) }
                                )
                            }
                        }
                    } else {
                        // Portrait Mode
                        Box(modifier = Modifier.fillMaxSize()) {
                            ZoomableBlocksCanvas(
                                blocks = currentProject.blocks,
                                onAddBlock = { isPaletteVisible = true },
                                onEditBlock = { viewModel.openEditBlock(it) },
                                onMoveUp = { viewModel.moveBlock(it, up = true) },
                                onMoveDown = { viewModel.moveBlock(it, up = false) },
                                onReorder = { from, to -> viewModel.reorderBlocks(from, to) },
                                onDuplicate = { viewModel.duplicateBlock(it) },
                                onDelete = { viewModel.deleteBlock(it) },
                                onAddInside = { parentId, isSecondary -> viewModel.openPicker(parentId, isSecondary) },
                                onMoveChildUp = { parentId, childIdx, isSecondary -> viewModel.moveChildBlock(parentId, childIdx, up = true, isSecondary) },
                                onMoveChildDown = { parentId, childIdx, isSecondary -> viewModel.moveChildBlock(parentId, childIdx, up = false, isSecondary) },
                                onDuplicateChild = { parentId, childIdx, isSecondary -> viewModel.duplicateChildBlock(parentId, childIdx, isSecondary) },
                                onDeleteChild = { parentId, childIdx, isSecondary -> viewModel.deleteChildBlock(parentId, childIdx, isSecondary) }
                            )

                            // Animated Drawer Overlay for Portrait Mode
                            AnimatedVisibility(
                                visible = isPaletteVisible,
                                enter = fadeIn(),
                                exit = fadeOut(),
                                modifier = Modifier
                                    .fillMaxSize()
                                    .zIndex(10f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.45f))
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null
                                        ) { isPaletteVisible = false }
                                )
                            }

                            AnimatedVisibility(
                                visible = isPaletteVisible,
                                enter = slideInHorizontally(initialOffsetX = { -it }),
                                exit = slideOutHorizontally(targetOffsetX = { -it }),
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .widthIn(max = 320.dp)
                                    .zIndex(11f)
                            ) {
                                BlockPalettePane(
                                    onAddBlock = { type ->
                                        viewModel.onBlockTypeChosen(type)
                                    },
                                    isArduino = isArduino,
                                    installedLibraryIds = viewModel.getInstalledLibraryIds(),
                                    onOpenLibraries = { viewModel.setShowLibrariesDialog(true) },
                                    language = appLanguage,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(300.dp)
                                        .shadow(8.dp)
                                )
                            }
                        }
                    }
                }

                1 -> {
                    if (isArduino) {
                        // ARDUINO CONVERT & CODE VIEW
                        ArduinoConvertView(
                            blocks = currentProject.blocks,
                            onOpenSimulator = { viewModel.setSelectedTab(2) }
                        )
                    } else {
                        // PYTHON CODE VIEW
                        PythonCodeView(
                            pythonCode = viewModel.getGeneratedPython(),
                            onRunSimulator = {
                                viewModel.setSelectedTab(2)
                                viewModel.runSimulator()
                            }
                        )
                    }
                }

                2 -> {
                    if (isArduino) {
                        // ARDUINO BOARD SIMULATOR
                        ArduinoSimulatorView(
                            blocks = currentProject.blocks,
                            language = appLanguage
                        )
                    } else {
                        // PYTHON CONSOLE
                        ConsoleView(
                            outputs = consoleOutputs,
                            isRunning = isSimulatorRunning,
                            pendingPrompt = pendingPrompt,
                            onSendInput = { viewModel.sendInput(it) },
                            onRun = { viewModel.runSimulator() },
                            onStop = { viewModel.stopSimulator() },
                            onClear = { viewModel.clearConsole() }
                        )
                    }
                }
            }
        }
    }

    // Modal Block Picker Sheet
    if (isPickerOpen) {
        BlockPickerSheet(
            onSelectBlockType = { type -> viewModel.onBlockTypeChosen(type) },
            isArduino = isArduino,
            installedLibraryIds = viewModel.getInstalledLibraryIds(),
            onOpenLibraries = { viewModel.setShowLibrariesDialog(true) },
            onDismiss = { viewModel.closePicker() },
            language = appLanguage
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            currentLanguage = appLanguage,
            onLanguageSelected = { lang -> viewModel.setLanguage(lang) },
            onOpenWebVersion = {
                viewModel.closeSettings()
                viewModel.openWebPreview()
            },
            onDismiss = { viewModel.closeSettings() }
        )
    }

    // Web Preview Dialog
    if (showWebPreviewDialog) {
        WebPreviewDialog(
            currentLanguage = appLanguage,
            onDismiss = { viewModel.closeWebPreview() }
        )
    }

    // Python Libraries / Extensions Dialog
    if (showLibrariesDialog) {
        PythonLibrariesDialog(
            installedLibIds = viewModel.getInstalledLibraryIds(),
            onInstallLibrary = { lib ->
                viewModel.installLibrary(lib)
                viewModel.setShowLibrariesDialog(false)
            },
            onUninstallLibrary = { lib ->
                viewModel.uninstallLibrary(lib)
            },
            onDismiss = { viewModel.setShowLibrariesDialog(false) }
        )
    }

    // Modal Edit Block Dialog
    editingBlock?.let { blockToEdit ->
        BlockEditDialog(
            block = blockToEdit,
            availableVariables = viewModel.getAvailableVariables(),
            onDismiss = { viewModel.closeEditBlock() },
            onSave = { updated -> viewModel.updateBlock(updated) }
        )
    }

    // Rename Project Dialog
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Название проекта") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Имя проекта") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryRed
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameText.isNotBlank()) {
                            viewModel.updateProjectName(renameText.trim())
                        }
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = primaryRed)
                ) {
                    Text("Готово")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
private fun TabHeaderItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    isCompact: Boolean = false,
    badge: Boolean = false,
    activeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.2f),
        modifier = Modifier.height(32.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = if (isCompact) 8.dp else 11.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) activeColor else Color.White,
                modifier = Modifier.size(15.dp)
            )
            if (!isCompact || isSelected) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isSelected) activeColor else Color.White
                )
            }
            if (badge) {
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD54F))
                )
            }
        }
    }
}
