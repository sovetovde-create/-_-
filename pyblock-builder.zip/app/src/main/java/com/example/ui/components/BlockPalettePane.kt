package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.BlockCategory
import com.example.model.BlockType
import com.example.model.Localization

@Composable
fun BlockPalettePane(
    onAddBlock: (BlockType) -> Unit,
    isArduino: Boolean = false,
    installedLibraryIds: Set<String> = emptySet(),
    onOpenLibraries: () -> Unit = {},
    modifier: Modifier = Modifier,
    language: AppLanguage = AppLanguage.DEFAULT
) {
    val initialCategory = if (isArduino) BlockCategory.ARDUINO_LEDS else BlockCategory.DIALOG
    var selectedCategory by remember(isArduino) { mutableStateOf<BlockCategory?>(initialCategory) }
    var searchQuery by remember { mutableStateOf("") }

    // Filter categories:
    // If Arduino: only Arduino categories
    // If Python: standard categories + extension categories whose libraryId is in installedLibraryIds
    val categories = remember(isArduino, installedLibraryIds) {
        if (isArduino) {
            BlockCategory.values().filter { it.isArduino }
        } else {
            BlockCategory.values().filter { cat ->
                !cat.isArduino && (!cat.isExtension || (cat.libraryId != null && installedLibraryIds.contains(cat.libraryId)))
            }
        }
    }

    val allTypes = remember(isArduino, categories) {
        BlockType.values().filter { type ->
            categories.contains(type.category)
        }
    }

    val filteredTypes = remember(selectedCategory, searchQuery, allTypes) {
        allTypes.filter { type ->
            val matchesCategory = searchQuery.isNotBlank() || selectedCategory == null || type.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    type.displayName.contains(searchQuery, ignoreCase = true) ||
                    type.category.title.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .border(width = 1.dp, color = Color(0xFFE5E5E5)),
        color = Color(0xFFFFFFFF)
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Leftmost Category Rail
            Surface(
                modifier = Modifier
                    .width(76.dp)
                    .fillMaxHeight(),
                color = Color(0xFFF7F7F7)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories) { category ->
                            val isSelected = selectedCategory == category && searchQuery.isBlank()
                            val catColor = Color(category.hexColor)

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color.White else Color.Transparent)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.dp,
                                        color = if (isSelected) Color(0xFFE53935) else Color.Transparent,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        selectedCategory = category
                                        searchQuery = ""
                                    }
                                    .padding(vertical = 6.dp, horizontal = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(catColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = getCategoryIcon(category),
                                        contentDescription = category.title,
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = Localization.getCategoryTitle(category, language),
                                    fontSize = 9.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color(0xFFE53935) else Color(0xFF555555),
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 11.sp
                                )
                            }
                        }
                    }

                    // Bottom Red circle button with white plus for Python extensions/libraries!
                    if (!isArduino) {
                        HorizontalDivider(color = Color(0xFFE0E0E0))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 4.dp)
                                .clickable { onOpenLibraries() },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFE53935),
                                shadowElevation = 3.dp,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("open_python_libraries_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Дополнения",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = "Библиотека",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE53935),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            VerticalDivider(color = Color(0xFFEAEAEA), thickness = 1.dp)

            // Right column: Search + Blocks list of selected category
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Quick Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    placeholder = { Text("Поиск команд...", fontSize = 11.sp, color = Color(0xFF999999)) },
                    leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(15.dp), tint = Color(0xFF888888)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(12.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color(0xFFE53935),
                        unfocusedBorderColor = Color(0xFFDCDCDC)
                    ),
                    textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Category Title Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val activeColor = selectedCategory?.let { Color(it.hexColor) } ?: Color(0xFFE53935)
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(activeColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "Поиск" else (selectedCategory?.title ?: "Все команды"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF222222)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "${filteredTypes.size}",
                        fontSize = 11.sp,
                        color = Color(0xFF888888)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Blocks list
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(bottom = 16.dp, top = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(filteredTypes, key = { it.name }) { type ->
                        PaletteBlockCard(
                            type = type,
                            language = language,
                            onClick = { onAddBlock(type) }
                        )
                    }

                    if (filteredTypes.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = Localization.get(language, "commands_not_found"),
                                    fontSize = 12.sp,
                                    color = Color(0xFF888888)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaletteBlockCard(
    type: BlockType,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val category = type.category
    val color = Color(category.hexColor)
    val borderColor = Color(category.hexBorderColor)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = color,
        contentColor = Color.White
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(category),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = Localization.getBlockTitle(type, language),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.size(20.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Добавить",
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}
