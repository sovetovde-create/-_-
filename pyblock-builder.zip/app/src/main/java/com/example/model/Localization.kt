package com.example.model

enum class AppLanguage(
    val code: String,
    val title: String,
    val nativeTitle: String,
    val flag: String
) {
    EN("en", "English", "English", "🇬🇧"),
    RU("ru", "Russian", "Русский", "🇷🇺"),
    UK("uk", "Ukrainian", "Українська", "🇺🇦");

    companion object {
        val DEFAULT = EN

        fun fromCode(code: String): AppLanguage {
            return values().find { it.code.equals(code, ignoreCase = true) } ?: DEFAULT
        }
    }
}

object Localization {

    fun getCategoryTitle(category: BlockCategory, lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.EN -> when (category) {
                BlockCategory.DIALOG -> "Dialogue"
                BlockCategory.VARIABLES -> "Variables"
                BlockCategory.CONTROL -> "Control"
                BlockCategory.NUMBERS_MATH -> "Math"
                BlockCategory.TEXT_OPS -> "Text"
                BlockCategory.LISTS -> "Lists"
                BlockCategory.FUNCTIONS -> "Functions"
                BlockCategory.ADVANCED -> "Advanced"
                BlockCategory.EXT_NEURAL_NET -> "Neural Nets"
                BlockCategory.EXT_API -> "API & Web"
                BlockCategory.EXT_RANDOM -> "Random"
                BlockCategory.EXT_OS -> "OS System"
                BlockCategory.EXT_TIME -> "Time & Date"
                BlockCategory.EXT_MATH -> "Math & Stats"
                BlockCategory.EXT_GRAPHICS -> "Graphics"
                BlockCategory.EXT_DATABASE -> "SQLite DB"
                BlockCategory.ARDUINO_LEDS -> "LEDs & Pins"
                BlockCategory.ARDUINO_SERVO -> "Servo"
                BlockCategory.ARDUINO_MOTORS -> "Motors & Drivers"
                BlockCategory.ARDUINO_SENSORS -> "Sensors"
                BlockCategory.ARDUINO_BUZZER -> "Buzzer"
                BlockCategory.ARDUINO_DISPLAYS -> "Displays"
                BlockCategory.ARDUINO_CONTROL -> "Control"
                BlockCategory.ARDUINO_SERIAL -> "Serial PC"
            }
            AppLanguage.UK -> when (category) {
                BlockCategory.DIALOG -> "Спілкування"
                BlockCategory.VARIABLES -> "Пам'ять"
                BlockCategory.CONTROL -> "Керування"
                BlockCategory.NUMBERS_MATH -> "Математика"
                BlockCategory.TEXT_OPS -> "Текст"
                BlockCategory.LISTS -> "Списки"
                BlockCategory.FUNCTIONS -> "Команди"
                BlockCategory.ADVANCED -> "Різне"
                BlockCategory.EXT_NEURAL_NET -> "Нейромережі"
                BlockCategory.EXT_API -> "API & Мережа"
                BlockCategory.EXT_RANDOM -> "Випадковість"
                BlockCategory.EXT_OS -> "Система OS"
                BlockCategory.EXT_TIME -> "Час & Дата"
                BlockCategory.EXT_MATH -> "Мат & Статистика"
                BlockCategory.EXT_GRAPHICS -> "Графіка"
                BlockCategory.EXT_DATABASE -> "База SQLite"
                BlockCategory.ARDUINO_LEDS -> "Лампочки"
                BlockCategory.ARDUINO_SERVO -> "Сервопривід"
                BlockCategory.ARDUINO_MOTORS -> "Мотори і Драйвери"
                BlockCategory.ARDUINO_SENSORS -> "Датчики"
                BlockCategory.ARDUINO_BUZZER -> "Зумер"
                BlockCategory.ARDUINO_DISPLAYS -> "Екрани"
                BlockCategory.ARDUINO_CONTROL -> "Керування"
                BlockCategory.ARDUINO_SERIAL -> "Зв'язок ПК"
            }
            AppLanguage.RU -> when (category) {
                BlockCategory.DIALOG -> "Общение"
                BlockCategory.VARIABLES -> "Память"
                BlockCategory.CONTROL -> "Управление"
                BlockCategory.NUMBERS_MATH -> "Математика"
                BlockCategory.TEXT_OPS -> "Текст"
                BlockCategory.LISTS -> "Списки"
                BlockCategory.FUNCTIONS -> "Команды"
                BlockCategory.ADVANCED -> "Разное"
                BlockCategory.EXT_NEURAL_NET -> "Нейросети"
                BlockCategory.EXT_API -> "API & Сеть"
                BlockCategory.EXT_RANDOM -> "Случайность"
                BlockCategory.EXT_OS -> "Система OS"
                BlockCategory.EXT_TIME -> "Время & Дата"
                BlockCategory.EXT_MATH -> "Мат & Статистика"
                BlockCategory.EXT_GRAPHICS -> "Графика & Игры"
                BlockCategory.EXT_DATABASE -> "База SQLite"
                BlockCategory.ARDUINO_LEDS -> "Лампочки"
                BlockCategory.ARDUINO_SERVO -> "Сервопривод"
                BlockCategory.ARDUINO_MOTORS -> "Моторы и Драйверы"
                BlockCategory.ARDUINO_SENSORS -> "Датчики"
                BlockCategory.ARDUINO_BUZZER -> "Зуммер"
                BlockCategory.ARDUINO_DISPLAYS -> "Экраны"
                BlockCategory.ARDUINO_CONTROL -> "Управление"
                BlockCategory.ARDUINO_SERIAL -> "Связь ПК"
            }
        }
    }

    fun getBlockTypeName(type: BlockType, lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.EN -> when (type) {
                // Dialog
                BlockType.ASK_INPUT -> "Ask question and save answer"
                BlockType.ASK_NUMBER -> "Ask for number and save"
                BlockType.SAY -> "Say (print text)"
                BlockType.SAY_PHRASE -> "Say formatted string with variables"
                BlockType.CLEAR_SCREEN -> "Clear screen"

                // Variables
                BlockType.SET_VARIABLE -> "Set: variable = value"
                BlockType.CHANGE_BY -> "Change variable by"
                BlockType.CALCULATE_INTO -> "Calculate and save"
                BlockType.CALCULATE_FORMULA_STRING -> "Calculate formula from string"

                // Control
                BlockType.IF_SIMPLE -> "If <condition>, then:"
                BlockType.IF_ELSE_SIMPLE -> "If <condition>, then: ... Else:"
                BlockType.REPEAT_TIMES -> "Repeat <count> times:"
                BlockType.WHILE_LOOP -> "While <condition> is true:"
                BlockType.FOR_EACH_ITEM -> "For each <item> in list:"
                BlockType.WAIT_SECONDS -> "Wait <seconds>"
                BlockType.STOP_LOOP -> "Break loop"
                BlockType.NEXT_ROUND -> "Continue to next loop cycle"
                BlockType.STOP_ALL -> "Stop program"

                // Math Expressions
                BlockType.EXPR_RANDOM_NUM -> "Random number from .. to"
                BlockType.EXPR_ROUND -> "Round number"
                BlockType.EXPR_ABS -> "Absolute value (abs)"
                BlockType.EXPR_MATH_OP -> "Calculate: (a + b)"
                BlockType.EXPR_COMPARE_VALS -> "Compare: (a == b)"
                BlockType.EVAL_EXPRESSION -> "Evaluate formula string (eval)"

                // Text
                BlockType.TEXT_TO_UPPER -> "Convert text to uppercase"
                BlockType.TEXT_TO_LOWER -> "Convert text to lowercase"
                BlockType.TEXT_REPLACE -> "Replace in text part with"
                BlockType.EXPR_TEXT_CONTAINS -> "Does text contain word?"
                BlockType.EXPR_TEXT_LENGTH -> "Length of text (char count)"

                // Lists
                BlockType.CREATE_LIST -> "Create list of items"
                BlockType.ADD_TO_LIST -> "Append item to list"
                BlockType.GET_FROM_LIST -> "Get item by index"
                BlockType.REMOVE_FROM_LIST -> "Remove item from list"
                BlockType.REVERSE_LIST -> "Reverse list"
                BlockType.EXPR_RANDOM_CHOICE -> "Random choice from list"
                BlockType.EXPR_LIST_SIZE -> "Length of list"

                // Functions
                BlockType.CUSTOM_COMMAND_DEF -> "Define function <name>:"
                BlockType.CUSTOM_COMMAND_RUN -> "Call function <name>"
                BlockType.GIVE_RESULT -> "Return result"

                // Advanced
                BlockType.IMPORT_LIBRARY -> "📦 Library: import <name>"
                BlockType.ADD_NOTE -> "Comment note"
                BlockType.TRY_DO -> "Try to do: ... If error:"
                BlockType.WRITE_FILE -> "Write text to file"
                BlockType.RAW_PY -> "Raw Python code line"

                // Neural Net
                BlockType.NN_CREATE_MODEL -> "Create Neural Network (in, hidden, out)"
                BlockType.NN_TRAIN_EPOCHS -> "Train model N epochs (lr learning rate)"
                BlockType.NN_PREDICT -> "Predict with neural network"
                BlockType.NN_ACTIVATION -> "Activation function (ReLU, Sigmoid)"
                BlockType.NN_CALC_LOSS -> "Calculate loss (MSE Loss)"

                // API & Web
                BlockType.API_GET_REQUEST -> "Send HTTP GET request to URL"
                BlockType.API_POST_JSON -> "Send HTTP POST request with JSON"
                BlockType.API_GET_MY_IP -> "Get my public IP via API"
                BlockType.API_PARSE_FIELD -> "Extract field from JSON response"
                BlockType.API_STATUS_CODE -> "Check response status (200 OK)"

                // Random
                BlockType.RANDOM_INT_RANGE -> "Random integer from .. to"
                BlockType.RANDOM_CHOICE_ITEM -> "Random item from list"
                BlockType.RANDOM_SHUFFLE_LIST -> "Shuffle list randomly"
                BlockType.RANDOM_FLOAT_01 -> "Random float 0.0 to 1.0"

                // OS
                BlockType.OS_LIST_FILES -> "List files in directory to list"
                BlockType.OS_FILE_EXISTS -> "Check: file exists?"
                BlockType.OS_CREATE_FOLDER -> "Create new directory"
                BlockType.OS_GET_SYSTEM -> "Operating system name to variable"
                BlockType.OS_EXIT_APP -> "Exit program immediately"

                // Time
                BlockType.TIME_SLEEP_MS -> "Precise pause in milliseconds (ms)"
                BlockType.TIME_CURRENT_TIMESTAMP -> "Current timestamp in seconds"
                BlockType.TIME_FORMATTED_DATE -> "Current date & time with format"
                BlockType.TIME_BENCHMARK -> "Benchmark block execution time:"

                // Math & Stats
                BlockType.MATH_SQRT -> "Square root (sqrt)"
                BlockType.MATH_POW -> "Power (number ^ power)"
                BlockType.MATH_TRIG_SIN_COS -> "Trigonometry: sin / cos / tan"
                BlockType.MATH_CONSTANTS -> "Constant: Pi or E"
                BlockType.STAT_MEAN_MEDIAN -> "Average mean of number list"

                // Graphics
                BlockType.TURTLE_FORWARD -> "Turtle: step forward N pixels"
                BlockType.TURTLE_TURN -> "Turtle: turn N degrees"
                BlockType.TURTLE_PEN_UP_DOWN -> "Turtle: pen up / down"
                BlockType.TURTLE_SET_COLOR -> "Turtle: set pen color"

                // SQLite
                BlockType.SQLITE_CONNECT -> "Connect to SQLite database"
                BlockType.SQLITE_EXECUTE -> "Execute SQL query (INSERT/CREATE)"
                BlockType.SQLITE_FETCH_ALL -> "Fetch all rows (SELECT)"

                // Arduino LEDs
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> "Turn ON pin LED (HIGH)"
                BlockType.ARDUINO_DIGITAL_WRITE_LOW -> "Turn OFF pin LED (LOW)"
                BlockType.ARDUINO_BLINK_LED -> "Blink pin LED with delay"
                BlockType.ARDUINO_PWM_BRIGHTNESS -> "Set LED brightness (PWM 0-255)"
                BlockType.ARDUINO_PIN_MODE -> "Set pin mode (OUTPUT / INPUT)"
                BlockType.ARDUINO_TOGGLE_PIN -> "Toggle pin state"

                // Arduino Servo
                BlockType.ARDUINO_SERVO_ATTACH -> "Attach servo to pin"
                BlockType.ARDUINO_SERVO_WRITE -> "Rotate servo to angle"
                BlockType.ARDUINO_SERVO_SWEEP -> "Sweep servo between angles"

                // Arduino Motors
                BlockType.ARDUINO_MOTOR_FORWARD -> "Motor: rotate forward"
                BlockType.ARDUINO_MOTOR_BACKWARD -> "Motor: rotate backward"
                BlockType.ARDUINO_MOTOR_STOP -> "Stop motor"
                BlockType.ARDUINO_L298N_DRIVER -> "L298N Motor Driver (IN1, IN2, Speed)"
                BlockType.ARDUINO_L298N_MOTOR_A -> "L298N Motor A (IN1, IN2, ENA [PWM])"
                BlockType.ARDUINO_L298N_MOTOR_B -> "L298N Motor B (IN3, IN4, ENB [PWM])"
                BlockType.ARDUINO_L298N_STOP_ALL -> "L298N: Stop all motors"
                BlockType.ARDUINO_L9110S_MOTOR -> "L9110S Driver (Pin1, Pin2, Speed)"
                BlockType.ARDUINO_STEPPER_STEP -> "Stepper 28BYJ-48 (ULN2003)"

                // Arduino Sensors
                BlockType.ARDUINO_DIGITAL_READ -> "Read button / digital pin"
                BlockType.ARDUINO_ANALOG_READ -> "Read analog sensor (A0-A5)"
                BlockType.ARDUINO_ULTRASONIC -> "Ultrasonic sensor HC-SR04 (cm)"
                BlockType.ARDUINO_IF_BUTTON -> "If button pressed, then:"

                // Arduino Buzzer
                BlockType.ARDUINO_BUZZER_TONE -> "Play tone (frequency Hz & duration)"
                BlockType.ARDUINO_BUZZER_NOTONE -> "Stop tone on pin"
                BlockType.ARDUINO_BUZZER_BEEP -> "Short beep"

                // Arduino Displays
                BlockType.ARDUINO_LCD_INIT -> "LCD 1602: Initialize screen (I2C 0x27)"
                BlockType.ARDUINO_LCD_PRINT -> "LCD 1602: Print text at (col, row)"
                BlockType.ARDUINO_LCD_PRINT_VAR -> "LCD 1602: Print variable value"
                BlockType.ARDUINO_LCD_CLEAR -> "LCD 1602: Clear screen"
                BlockType.ARDUINO_LCD_BACKLIGHT -> "LCD 1602: Backlight (ON / OFF)"
                BlockType.ARDUINO_OLED_INIT -> "OLED 0.96\": Init SSD1306 display"
                BlockType.ARDUINO_OLED_PRINT -> "OLED 0.96\": Print text (size, X, Y)"
                BlockType.ARDUINO_OLED_PRINT_VAR -> "OLED 0.96\": Print variable value"
                BlockType.ARDUINO_OLED_CLEAR -> "OLED 0.96\": Clear display"
                BlockType.ARDUINO_TM1637_INIT -> "7-Segment TM1637: Connect (CLK, DIO)"
                BlockType.ARDUINO_TM1637_NUMBER -> "7-Segment TM1637: Display number"
                BlockType.ARDUINO_TM1637_CLEAR -> "7-Segment TM1637: Clear display"

                // Arduino Control
                BlockType.ARDUINO_DELAY_MS -> "Wait milliseconds (ms)"
                BlockType.ARDUINO_DELAY_SEC -> "Wait seconds"
                BlockType.ARDUINO_IF_ELSE -> "If <condition>, then: ... Else:"
                BlockType.ARDUINO_REPEAT_TIMES -> "Repeat <count> times:"
                BlockType.ARDUINO_LOOP_FOREVER -> "Forever loop (repeat always):"
                BlockType.ARDUINO_VARIABLE_SET -> "Set: variable = value"
                BlockType.ARDUINO_MAP_RANGE -> "Map range (input low..high -> low..high)"

                // Arduino Serial
                BlockType.ARDUINO_SERIAL_BEGIN -> "Begin Serial port (baud)"
                BlockType.ARDUINO_SERIAL_PRINTLN -> "Print line to Serial monitor"
                BlockType.ARDUINO_SERIAL_PRINT_VAR -> "Print variable to Serial monitor"
            }

            AppLanguage.UK -> when (type) {
                // Dialog
                BlockType.ASK_INPUT -> "Запитати та зберегти відповідь"
                BlockType.ASK_NUMBER -> "Запитати число та зберегти"
                BlockType.SAY -> "Сказати (надрукувати текст)"
                BlockType.SAY_PHRASE -> "Сказати фразу зі змінними"
                BlockType.CLEAR_SCREEN -> "Очистити екран"

                // Variables
                BlockType.SET_VARIABLE -> "Запам'ятати: змінна = значення"
                BlockType.CHANGE_BY -> "Збільшити змінну на"
                BlockType.CALCULATE_INTO -> "Обчислити та зберегти"
                BlockType.CALCULATE_FORMULA_STRING -> "Обчислити формулу з рядка"

                // Control
                BlockType.IF_SIMPLE -> "Якщо <умова>, то:"
                BlockType.IF_ELSE_SIMPLE -> "Якщо <умова>, то: ... Інакше:"
                BlockType.REPEAT_TIMES -> "Повторити <кількість> разів:"
                BlockType.WHILE_LOOP -> "Повторювати, поки вірно <умова>:"
                BlockType.FOR_EACH_ITEM -> "Для кожного <елемента> зі списку:"
                BlockType.WAIT_SECONDS -> "Зачекати <секунд>"
                BlockType.STOP_LOOP -> "Зупинити цикл (вийти)"
                BlockType.NEXT_ROUND -> "Перейти до наступного кола"
                BlockType.STOP_ALL -> "Завершити програму"

                // Math Expressions
                BlockType.EXPR_RANDOM_NUM -> "Випадкове число від і до"
                BlockType.EXPR_ROUND -> "Округлити число"
                BlockType.EXPR_ABS -> "Модуль числа (без мінуса)"
                BlockType.EXPR_MATH_OP -> "Обчислити: (a + b)"
                BlockType.EXPR_COMPARE_VALS -> "Порівняти: (a == b)"
                BlockType.EVAL_EXPRESSION -> "Обчислити вираз з рядка (eval)"

                // Text
                BlockType.TEXT_TO_UPPER -> "Зробити великими літерами"
                BlockType.TEXT_TO_LOWER -> "Зробити малими літерами"
                BlockType.TEXT_REPLACE -> "Замінити в тексті частину на"
                BlockType.EXPR_TEXT_CONTAINS -> "Текст містить слово?"
                BlockType.EXPR_TEXT_LENGTH -> "Довжина тексту (кількість літер)"

                // Lists
                BlockType.CREATE_LIST -> "Створити список елементів"
                BlockType.ADD_TO_LIST -> "Додати в список елемент"
                BlockType.GET_FROM_LIST -> "Взяти елемент за номером"
                BlockType.REMOVE_FROM_LIST -> "Видалити зі списку елемент"
                BlockType.REVERSE_LIST -> "Перевернути список"
                BlockType.EXPR_RANDOM_CHOICE -> "Випадковий вибір зі списку"
                BlockType.EXPR_LIST_SIZE -> "Кількість елементів у списку"

                // Functions
                BlockType.CUSTOM_COMMAND_DEF -> "Створити команду <ім'я>:"
                BlockType.CUSTOM_COMMAND_RUN -> "Виконати команду <ім'я>"
                BlockType.GIVE_RESULT -> "Повернути результат (відповідь)"

                // Advanced
                BlockType.IMPORT_LIBRARY -> "📦 Бібліотека: import <ім'я>"
                BlockType.ADD_NOTE -> "Нотатка (коментар)"
                BlockType.TRY_DO -> "Спробувати зробити: ... Якщо помилка:"
                BlockType.WRITE_FILE -> "Записати в файл текст"
                BlockType.RAW_PY -> "Рядок чистого коду Python"

                // Neural Net
                BlockType.NN_CREATE_MODEL -> "Створити нейромережу (входи, приховані, виходи)"
                BlockType.NN_TRAIN_EPOCHS -> "Навчити нейромережу N епох (lr швидкість)"
                BlockType.NN_PREDICT -> "Зробити передбачення нейромережею"
                BlockType.NN_ACTIVATION -> "Функція активації (ReLU, Sigmoid)"
                BlockType.NN_CALC_LOSS -> "Розрахувати помилку навчання (Loss MSE)"

                // API & Web
                BlockType.API_GET_REQUEST -> "Надіслати GET запит на URL"
                BlockType.API_POST_JSON -> "Надіслати POST запит з JSON"
                BlockType.API_GET_MY_IP -> "Дізнатися свою IP адресу через API"
                BlockType.API_PARSE_FIELD -> "Витягти поле з JSON відповіді"
                BlockType.API_STATUS_CODE -> "Перевірити статус відповіді (200 OK)"

                // Random
                BlockType.RANDOM_INT_RANGE -> "Випадкове ціле число від і до"
                BlockType.RANDOM_CHOICE_ITEM -> "Випадковий вибір зі списку"
                BlockType.RANDOM_SHUFFLE_LIST -> "Перемішати список випадково"
                BlockType.RANDOM_FLOAT_01 -> "Випадковий дріб від 0.0 до 1.0"

                // OS
                BlockType.OS_LIST_FILES -> "Список файлів у папці зберегти в список"
                BlockType.OS_FILE_EXISTS -> "Перевірити: файл існує?"
                BlockType.OS_CREATE_FOLDER -> "Створити нову папку"
                BlockType.OS_GET_SYSTEM -> "Ім'я операційної системи"
                BlockType.OS_EXIT_APP -> "Екстрено завершити виконання"

                // Time
                BlockType.TIME_SLEEP_MS -> "Точна пауза в мілісекундах (мс)"
                BlockType.TIME_CURRENT_TIMESTAMP -> "Поточний час (timestamp) в секундах"
                BlockType.TIME_FORMATTED_DATE -> "Поточна дата і час з форматом"
                BlockType.TIME_BENCHMARK -> "Заміряти час виконання:"

                // Math & Stats
                BlockType.MATH_SQRT -> "Квадратний корінь числа (sqrt)"
                BlockType.MATH_POW -> "Піднести число до степеня"
                BlockType.MATH_TRIG_SIN_COS -> "Тригонометрія: sin / cos / tan"
                BlockType.MATH_CONSTANTS -> "Константа числа Пі (pi) або експонента"
                BlockType.STAT_MEAN_MEDIAN -> "Середнє значення списку (mean)"

                // Graphics
                BlockType.TURTLE_FORWARD -> "Черепашка: крок вперед на N пікселів"
                BlockType.TURTLE_TURN -> "Черепашка: повернути на N градусів"
                BlockType.TURTLE_PEN_UP_DOWN -> "Черепашка: перо (підняти / опустити)"
                BlockType.TURTLE_SET_COLOR -> "Встановити колір пера черепашки"

                // SQLite
                BlockType.SQLITE_CONNECT -> "Підключитися до бази даних SQLite"
                BlockType.SQLITE_EXECUTE -> "Виконати SQL команду (INSERT/CREATE)"
                BlockType.SQLITE_FETCH_ALL -> "Отримати всі рядки запиту (SELECT)"

                // Arduino LEDs
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> "Увімкнути лампочку на піні (HIGH)"
                BlockType.ARDUINO_DIGITAL_WRITE_LOW -> "Вимкнути лампочку на піні (LOW)"
                BlockType.ARDUINO_BLINK_LED -> "Блимати лампочкою на піні"
                BlockType.ARDUINO_PWM_BRIGHTNESS -> "Яскравість лампочки (ШІМ 0-255)"
                BlockType.ARDUINO_PIN_MODE -> "Налаштувати пін плати (ВИХІД / ВХІД)"
                BlockType.ARDUINO_TOGGLE_PIN -> "Перемкнути стан піна"

                // Arduino Servo
                BlockType.ARDUINO_SERVO_ATTACH -> "Підключити сервопривід до піна"
                BlockType.ARDUINO_SERVO_WRITE -> "Повернути сервопривід на кут"
                BlockType.ARDUINO_SERVO_SWEEP -> "Плавно повернути від кута до кута"

                // Arduino Motors
                BlockType.ARDUINO_MOTOR_FORWARD -> "Увімкнути мотор: обертати вперед"
                BlockType.ARDUINO_MOTOR_BACKWARD -> "Увімкнути мотор: обертати назад"
                BlockType.ARDUINO_MOTOR_STOP -> "Зупинити мотор"
                BlockType.ARDUINO_L298N_DRIVER -> "Драйвер мотора L298N (IN1, IN2, Швидкість)"
                BlockType.ARDUINO_L298N_MOTOR_A -> "L298N Мотор A (IN1, IN2, ENA [ШІМ])"
                BlockType.ARDUINO_L298N_MOTOR_B -> "L298N Мотор B (IN3, IN4, ENB [ШІМ])"
                BlockType.ARDUINO_L298N_STOP_ALL -> "L298N: Зупинити всі мотори"
                BlockType.ARDUINO_L9110S_MOTOR -> "Драйвер L9110S (Пін 1, Пін 2, Швидкість)"
                BlockType.ARDUINO_STEPPER_STEP -> "Кроковий мотор 28BYJ-48 (ULN2003)"

                // Arduino Sensors
                BlockType.ARDUINO_DIGITAL_READ -> "Зчитати кнопку/пін плати"
                BlockType.ARDUINO_ANALOG_READ -> "Зчитати аналоговий датчик (A0-A5)"
                BlockType.ARDUINO_ULTRASONIC -> "Ультразвуковий далекомір HC-SR04 (см)"
                BlockType.ARDUINO_IF_BUTTON -> "Якщо кнопка натиснута, то:"

                // Arduino Buzzer
                BlockType.ARDUINO_BUZZER_TONE -> "Видати звук (частота Гц і час)"
                BlockType.ARDUINO_BUZZER_NOTONE -> "Вимкнути звук на піні"
                BlockType.ARDUINO_BUZZER_BEEP -> "Короткий звуковий сигнал (біп)"

                // Arduino Displays
                BlockType.ARDUINO_LCD_INIT -> "LCD 1602: Увімкнути екран (I2C 0x27)"
                BlockType.ARDUINO_LCD_PRINT -> "LCD 1602: Написати текст (колонка, рядок)"
                BlockType.ARDUINO_LCD_PRINT_VAR -> "LCD 1602: Вивести значення змінної"
                BlockType.ARDUINO_LCD_CLEAR -> "LCD 1602: Очистити екран"
                BlockType.ARDUINO_LCD_BACKLIGHT -> "LCD 1602: Підсвічування (Увімк / Вимк)"
                BlockType.ARDUINO_OLED_INIT -> "OLED 0.96\": Увімкнути дисплей SSD1306"
                BlockType.ARDUINO_OLED_PRINT -> "OLED 0.96\": Написати текст (розмір, X, Y)"
                BlockType.ARDUINO_OLED_PRINT_VAR -> "OLED 0.96\": Вивести значення змінної"
                BlockType.ARDUINO_OLED_CLEAR -> "OLED 0.96\": Очистити дисплей"
                BlockType.ARDUINO_TM1637_INIT -> "7-Сегмент TM1637: Підключити (CLK, DIO)"
                BlockType.ARDUINO_TM1637_NUMBER -> "7-Сегмент TM1637: Показати число"
                BlockType.ARDUINO_TM1637_CLEAR -> "7-Сегмент TM1637: Очистити дисплей"

                // Arduino Control
                BlockType.ARDUINO_DELAY_MS -> "Зачекати мілісекунд (мс)"
                BlockType.ARDUINO_DELAY_SEC -> "Зачекати секунд"
                BlockType.ARDUINO_IF_ELSE -> "Якщо <умова>, то: ... Інакше:"
                BlockType.ARDUINO_REPEAT_TIMES -> "Повторити <кількість> разів:"
                BlockType.ARDUINO_LOOP_FOREVER -> "Нескінченний цикл (повторювати завжди):"
                BlockType.ARDUINO_VARIABLE_SET -> "Запам'ятати: змінна = значення"
                BlockType.ARDUINO_MAP_RANGE -> "Перетворити діапазон (map)"

                // Arduino Serial
                BlockType.ARDUINO_SERIAL_BEGIN -> "Увімкнути монітор порту (Serial)"
                BlockType.ARDUINO_SERIAL_PRINTLN -> "Надіслати текст у монітор порту"
                BlockType.ARDUINO_SERIAL_PRINT_VAR -> "Надіслати значення змінної в монітор"
            }

            AppLanguage.RU -> type.displayName
        }
    }

    fun getBlockTitle(type: BlockType, lang: AppLanguage): String = getBlockTypeName(type, lang)

    fun get(lang: AppLanguage, key: String): String = get(key, lang)

    fun get(key: String, lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.EN -> when (key) {
                "settings" -> "Settings"
                "language" -> "Language"
                "select_language" -> "Select App Language"
                "default_language" -> "Default language is English"
                "close" -> "Close"
                "apply" -> "Apply"
                "blocks" -> "Blocks"
                "python" -> "Python"
                "console" -> "Console"
                "convert" -> "Convert"
                "board_test" -> "Board Test"
                "code" -> "CODE"
                "start" -> "START"
                "pause" -> "Pause"
                "run" -> "Run"
                "reset" -> "Reset"
                "file" -> "File"
                "rename" -> "Rename"
                "delete" -> "Delete"
                "cancel" -> "Cancel"
                "duplicate" -> "Duplicate"
                "projects" -> "Projects"
                "new_project" -> "New Project"
                "my_projects" -> "My Projects"
                "visual_prog" -> "Visual Block Programming"
                "python_arduino_desc" -> "Python 3 & Arduino Uno with Hardware Simulator"
                "search_commands" -> "Search commands..."
                "search_actions" -> "Search actions..."
                "libraries" -> "Libraries"
                "libraries_and_extensions" -> "Libraries & Extensions"
                "add_new_capabilities" -> "Expand Python capabilities with packages"
                "installed" -> "Installed"
                "uninstall" -> "Uninstall"
                "add" -> "Add"
                "all" -> "All"
                "commands_not_found" -> "Commands not found"
                "arduino_running" -> "Arduino Uno Board is Running"
                "board_off" -> "Board is Powered Off"
                "displays_and_screens" -> "Displays & Screens"
                "lcd_display" -> "LCD 1602 Display (I2C)"
                "oled_display" -> "OLED 0.96\" SSD1306 (128x64)"
                "tm1637_display" -> "7-Segment 4-Digit TM1637"
                "backlight" -> "Backlight"
                "motor_driver_l298n" -> "Dual Motor Driver L298N"
                "servo_pin_9" -> "Servo Motor (Pin 9)"
                "buzzer_pin_8" -> "Buzzer (Pin 8)"
                "interactive_sensors" -> "Interactive Sensors"
                "button_pin_2" -> "Push Button (Pin 2)"
                "ultrasonic_sensor" -> "HC-SR04 Ultrasonic (Trig=7, Echo=6)"
                "analog_sensor_a0" -> "Analog Sensor (A0)"
                "serial_monitor" -> "Serial Monitor (9600 baud)"
                "serial_logs_placeholder" -> "Serial.println() logs will appear here during run..."
                "create_project" -> "Create Project"
                "project_name" -> "Project Name"
                "enter_name" -> "Enter project name..."
                "delete_confirm" -> "Are you sure you want to delete this project?"
                "open" -> "Open"
                "quick_inserts" -> "Quick Value Inserts:"
                "arduino_pins" -> "Arduino Uno Pins (select for active field):"
                "arduino_values" -> "Arduino Parameters & Values:"
                "save" -> "Save"
                "edit_block" -> "Edit Block"
                "web_version" -> "Web Edition (HTML5/JS)"
                "web_version_desc" -> "Run online or deploy to any website"
                "how_to_host" -> "How to host on a website"
                else -> key
            }

            AppLanguage.UK -> when (key) {
                "settings" -> "Налаштування"
                "language" -> "Мова"
                "select_language" -> "Оберіть мову додатку"
                "default_language" -> "За замовчуванням встановлена англійська мова"
                "close" -> "Закрити"
                "apply" -> "Застосувати"
                "blocks" -> "Блоки"
                "python" -> "Python"
                "console" -> "Консоль"
                "convert" -> "Конвертувати"
                "board_test" -> "Тест плати"
                "code" -> "КОД"
                "start" -> "СТАРТ"
                "pause" -> "Пауза"
                "run" -> "Запустити"
                "reset" -> "Скидання"
                "file" -> "Файл"
                "rename" -> "Перейменувати"
                "delete" -> "Видалити"
                "cancel" -> "Скасувати"
                "duplicate" -> "Дублювати"
                "projects" -> "Проєкти"
                "new_project" -> "Новий проєкт"
                "my_projects" -> "Мої проєкти"
                "visual_prog" -> "Візуальне програмування"
                "python_arduino_desc" -> "Python 3 та Arduino Uno з емулятором плати"
                "search_commands" -> "Пошук команд..."
                "search_actions" -> "Пошук дій..."
                "libraries" -> "Бібліотеки"
                "libraries_and_extensions" -> "Бібліотеки та Доповнення"
                "add_new_capabilities" -> "Розширюй можливості Python"
                "installed" -> "Встановлено"
                "uninstall" -> "Видалити"
                "add" -> "Додати"
                "all" -> "Всі"
                "commands_not_found" -> "Команди не знайдені"
                "arduino_running" -> "Плата Arduino Uno працює"
                "board_off" -> "Плата вимкнена"
                "displays_and_screens" -> "Екрани та Дисплеї"
                "lcd_display" -> "Дисплей LCD 1602 (I2C)"
                "oled_display" -> "OLED 0.96\" SSD1306 (128x64)"
                "tm1637_display" -> "7-Сегментний 4-розрядний TM1637"
                "backlight" -> "Підсвічування"
                "motor_driver_l298n" -> "Драйвер моторів L298N"
                "servo_pin_9" -> "Сервопривід (Пін 9)"
                "buzzer_pin_8" -> "Зумер (Пін 8)"
                "interactive_sensors" -> "Інтерактивні датчики"
                "button_pin_2" -> "Кнопка (Пін 2)"
                "ultrasonic_sensor" -> "Далекомір HC-SR04 (Trig=7, Echo=6)"
                "analog_sensor_a0" -> "Аналоговий датчик (A0)"
                "serial_monitor" -> "Монітор порту (Serial: 9600 бод)"
                "serial_logs_placeholder" -> "Вивід Serial.println() з'явиться тут під час запуску..."
                "create_project" -> "Створити проєкт"
                "project_name" -> "Назва проєкту"
                "enter_name" -> "Введіть назву проєкту..."
                "delete_confirm" -> "Ви дійсно бажаєте видалити цей проєкт?"
                "open" -> "Відкрити"
                "quick_inserts" -> "Швидкі вставки значень:"
                "arduino_pins" -> "Піни Arduino Uno (обери для активного поля):"
                "arduino_values" -> "Параметри та значення Arduino:"
                "save" -> "Зберегти"
                "edit_block" -> "Редагувати блок"
                "web_version" -> "Веб-версія (HTML5/JS)"
                "web_version_desc" -> "Запуск онлайн або на будь-якому сайті"
                "how_to_host" -> "Як опублікувати на сайті"
                else -> key
            }

            AppLanguage.RU -> when (key) {
                "settings" -> "Настройки"
                "language" -> "Язык"
                "select_language" -> "Выберите язык приложения"
                "default_language" -> "По умолчанию установлен английский язык"
                "close" -> "Закрыть"
                "apply" -> "Применить"
                "blocks" -> "Блоки"
                "python" -> "Python"
                "console" -> "Консоль"
                "convert" -> "Конвертировать"
                "board_test" -> "Тест платы"
                "code" -> "КОД"
                "start" -> "СТАРТ"
                "pause" -> "Пауза"
                "run" -> "Запустить"
                "reset" -> "Сброс"
                "file" -> "Файл"
                "rename" -> "Переименовать"
                "delete" -> "Удалить"
                "cancel" -> "Отмена"
                "duplicate" -> "Дублировать"
                "projects" -> "Проекты"
                "new_project" -> "Новый проект"
                "my_projects" -> "Мои проекты"
                "visual_prog" -> "Визуальное программирование"
                "python_arduino_desc" -> "Python 3 и Arduino Uno с эмулятором платы"
                "search_commands" -> "Поиск команд..."
                "search_actions" -> "Поиск действий..."
                "libraries" -> "Библиотеки"
                "libraries_and_extensions" -> "Библиотеки и Дополнения"
                "add_new_capabilities" -> "Добавь новые возможности в Python"
                "installed" -> "Установлено"
                "uninstall" -> "Удалить"
                "add" -> "Добавить"
                "all" -> "Все"
                "commands_not_found" -> "Команды не найдены"
                "arduino_running" -> "Плата Arduino Uno работает"
                "board_off" -> "Плата выключена"
                "displays_and_screens" -> "Экраны и Дисплеи"
                "lcd_display" -> "Дисплей LCD 1602 (I2C)"
                "oled_display" -> "OLED 0.96\" SSD1306 (128x64)"
                "tm1637_display" -> "7-Сегментный 4-разрядный TM1637"
                "backlight" -> "Подсветка"
                "motor_driver_l298n" -> "Драйвер моторов L298N"
                "servo_pin_9" -> "Сервопривод (Пин 9)"
                "buzzer_pin_8" -> "Зуммер (Пин 8)"
                "interactive_sensors" -> "Интерактивные датчики"
                "button_pin_2" -> "Кнопка (Пин 2)"
                "ultrasonic_sensor" -> "Дальномер HC-SR04 (Trig=7, Echo=6)"
                "analog_sensor_a0" -> "Аналоговый датчик (A0)"
                "serial_monitor" -> "Монитор порта (Serial: 9600 бод)"
                "serial_logs_placeholder" -> "Вывод Serial.println() появится здесь при запуске..."
                "create_project" -> "Создать проект"
                "project_name" -> "Название проекта"
                "enter_name" -> "Введите название проекта..."
                "delete_confirm" -> "Вы уверены, что хотите удалить этот проект?"
                "open" -> "Открыть"
                "quick_inserts" -> "Быстрые вставки значений:"
                "arduino_pins" -> "Пины Arduino Uno (выбери для активного поля):"
                "arduino_values" -> "Параметры и значения Arduino:"
                "save" -> "Сохранить"
                "edit_block" -> "Редактировать блок"
                "web_version" -> "Веб-версия (HTML5/JS)"
                "web_version_desc" -> "Запуск онлайн или на любом сайте"
                "how_to_host" -> "Как выложить на сайт"
                else -> key
            }
        }
    }
}
