package com.example.model

object CodeGenerator {

    /**
     * Resolves the code string for a field slot:
     * if a nested expression block is plugged into that slot, generates its expression code.
     * otherwise, falls back to the text field value.
     */
    fun resolveFieldValue(block: Block, key: String, default: String = ""): String {
        val nested = block.getNested(key)
        if (nested != null) {
            return generateExpression(nested)
        }
        return block.getField(key, default).trim()
    }

    /**
     * Generates a Python expression string from an expression block (or nested expression tree)
     */
    fun generateExpression(block: Block): String {
        return when (block.type) {
            BlockType.EXPR_RANDOM_NUM -> {
                val from = resolveFieldValue(block, "from", "1")
                val to = resolveFieldValue(block, "to", "10")
                "random.randint($from, $to)"
            }
            BlockType.EXPR_ROUND -> {
                val num = resolveFieldValue(block, "number", "0")
                "round($num)"
            }
            BlockType.EXPR_ABS -> {
                val num = resolveFieldValue(block, "number", "0")
                "abs($num)"
            }
            BlockType.EXPR_MATH_OP -> {
                val left = resolveFieldValue(block, "left", "0")
                val op = block.getField("op", "+").trim()
                val right = resolveFieldValue(block, "right", "0")
                "($left $op $right)"
            }
            BlockType.EXPR_COMPARE_VALS -> {
                val left = resolveFieldValue(block, "left", "0")
                val op = block.getField("op", "==").trim()
                val right = resolveFieldValue(block, "right", "0")
                "($left $op $right)"
            }
            BlockType.EXPR_TEXT_CONTAINS -> {
                val word = resolveFieldValue(block, "word", "\"\"")
                val text = resolveFieldValue(block, "text", "\"\"")
                "($word in str($text))"
            }
            BlockType.EXPR_TEXT_LENGTH -> {
                val text = resolveFieldValue(block, "text", "\"\"")
                "len(str($text))"
            }
            BlockType.EXPR_RANDOM_CHOICE -> {
                val list = block.getField("list", "числа").trim()
                "random.choice($list)"
            }
            BlockType.EXPR_LIST_SIZE -> {
                val list = block.getField("list", "числа").trim()
                "len($list)"
            }
            BlockType.EVAL_EXPRESSION -> {
                val expr = resolveFieldValue(block, "expression", "\"0\"")
                "eval(str($expr))"
            }
            BlockType.NN_ACTIVATION -> {
                val func = block.getField("func", "ReLU").trim()
                val inp = block.getField("input", "x").trim()
                "torch.nn.functional.${func.lowercase()}($inp)"
            }
            BlockType.API_STATUS_CODE -> {
                val resp = block.getField("response", "ответ_сервера").trim()
                "(getattr($resp, 'status_code', 200) == 200)"
            }
            BlockType.OS_FILE_EXISTS -> {
                val p = resolveFieldValue(block, "path", "\"\"")
                "os.path.exists($p)"
            }
            else -> {
                block.fields.values.firstOrNull()?.trim() ?: "0"
            }
        }
    }

    fun generatePython(blocks: List<Block>, indentLevel: Int = 0): String {
        if (blocks.isEmpty()) {
            return if (indentLevel > 0) "    ".repeat(indentLevel) + "pass\n" else ""
        }

        val sb = StringBuilder()
        val indent = "    ".repeat(indentLevel)

        for (block in blocks) {
            when (block.type) {
                // Dialog
                BlockType.ASK_INPUT -> {
                    val v = block.getField("var", "ответ").trim()
                    val q = resolveFieldValue(block, "question", "\"Введите ответ: \"")
                    sb.append("${indent}$v = input($q)\n")
                }
                BlockType.ASK_NUMBER -> {
                    val v = block.getField("var", "число").trim()
                    val q = resolveFieldValue(block, "question", "\"Введите число: \"")
                    sb.append("${indent}$v = int(input($q))\n")
                }
                BlockType.SAY -> {
                    val text = resolveFieldValue(block, "text", "\"Привет!\"")
                    sb.append("${indent}print($text)\n")
                }
                BlockType.SAY_PHRASE -> {
                    val tmpl = block.getField("template", "").trim()
                    sb.append("${indent}print(f\"$tmpl\")\n")
                }
                BlockType.CLEAR_SCREEN -> {
                    sb.append("${indent}print(\"\\n\" * 20)  # Очистить экран\n")
                }

                // Variables
                BlockType.SET_VARIABLE -> {
                    val v = block.getField("var", "x").trim()
                    val valStr = resolveFieldValue(block, "value", "0")
                    sb.append("${indent}$v = $valStr\n")
                }
                BlockType.CHANGE_BY -> {
                    val v = block.getField("var", "x").trim()
                    val delta = resolveFieldValue(block, "value", "1")
                    sb.append("${indent}$v += $delta\n")
                }
                BlockType.CALCULATE_INTO -> {
                    val v = block.getField("var", "итог").trim()
                    val left = resolveFieldValue(block, "left", "0")
                    val op = block.getField("op", "+").trim()
                    val right = resolveFieldValue(block, "right", "0")
                    sb.append("${indent}$v = $left $op $right\n")
                }
                BlockType.CALCULATE_FORMULA_STRING -> {
                    val v = block.getField("var", "ответ").trim()
                    val f = resolveFieldValue(block, "formula", "\"2 + 2\"")
                    sb.append("${indent}$v = eval(str($f))\n")
                }

                // Control
                BlockType.IF_SIMPLE -> {
                    val cond = resolveFieldValue(block, "condition", "True")
                    sb.append("${indent}if $cond:\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                }
                BlockType.IF_ELSE_SIMPLE -> {
                    val cond = resolveFieldValue(block, "condition", "True")
                    sb.append("${indent}if $cond:\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                    sb.append("${indent}else:\n")
                    sb.append(generatePython(block.secondaryChildren, indentLevel + 1))
                }
                BlockType.REPEAT_TIMES -> {
                    val times = resolveFieldValue(block, "times", "5")
                    val v = block.getField("var", "i").trim()
                    sb.append("${indent}for $v in range($times):\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                }
                BlockType.WHILE_LOOP -> {
                    val cond = resolveFieldValue(block, "condition", "True")
                    sb.append("${indent}while $cond:\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                }
                BlockType.FOR_EACH_ITEM -> {
                    val item = block.getField("item", "элемент").trim()
                    val list = resolveFieldValue(block, "list", "[]")
                    sb.append("${indent}for $item in $list:\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                }
                BlockType.WAIT_SECONDS -> {
                    val sec = block.getField("seconds", "1").trim()
                    sb.append("${indent}time.sleep($sec)\n")
                }
                BlockType.STOP_LOOP -> {
                    sb.append("${indent}break\n")
                }
                BlockType.NEXT_ROUND -> {
                    sb.append("${indent}continue\n")
                }
                BlockType.STOP_ALL -> {
                    sb.append("${indent}exit()\n")
                }

                // Expressions Standalone
                BlockType.EXPR_RANDOM_NUM, BlockType.EXPR_ROUND, BlockType.EXPR_ABS,
                BlockType.EXPR_MATH_OP, BlockType.EXPR_COMPARE_VALS, BlockType.EXPR_TEXT_CONTAINS,
                BlockType.EXPR_TEXT_LENGTH, BlockType.EXPR_RANDOM_CHOICE, BlockType.EXPR_LIST_SIZE -> {
                    val expr = generateExpression(block)
                    sb.append("${indent}$expr\n")
                }

                // Text
                BlockType.TEXT_TO_UPPER -> {
                    val v = block.getField("var", "текст").trim()
                    val target = block.getField("save_to", "громкий").trim()
                    sb.append("${indent}$target = str($v).upper()\n")
                }
                BlockType.TEXT_TO_LOWER -> {
                    val v = block.getField("var", "текст").trim()
                    val target = block.getField("save_to", "тихий").trim()
                    sb.append("${indent}$target = str($v).lower()\n")
                }
                BlockType.TEXT_REPLACE -> {
                    val target = block.getField("target", "текст").trim()
                    val oldVal = block.getField("old", "\"\"").trim()
                    val newVal = block.getField("new", "\"\"").trim()
                    val saveTo = block.getField("save_to", "новый_текст").trim()
                    sb.append("${indent}$saveTo = str($target).replace($oldVal, $newVal)\n")
                }

                // Lists
                BlockType.CREATE_LIST -> {
                    val v = block.getField("var", "числа").trim()
                    val items = block.getField("items", "").trim()
                    sb.append("${indent}$v = [$items]\n")
                }
                BlockType.ADD_TO_LIST -> {
                    val list = block.getField("list", "числа").trim()
                    val item = resolveFieldValue(block, "item", "0")
                    sb.append("${indent}$list.append($item)\n")
                }
                BlockType.GET_FROM_LIST -> {
                    val list = block.getField("list", "числа").trim()
                    val idx = resolveFieldValue(block, "index", "0")
                    val saveTo = block.getField("save_to", "элемент").trim()
                    sb.append("${indent}$saveTo = $list[$idx]\n")
                }
                BlockType.REMOVE_FROM_LIST -> {
                    val list = block.getField("list", "числа").trim()
                    val item = resolveFieldValue(block, "item", "0")
                    sb.append("${indent}if $item in $list:\n${indent}    $list.remove($item)\n")
                }
                BlockType.REVERSE_LIST -> {
                    val list = block.getField("list", "числа").trim()
                    sb.append("${indent}$list.reverse()\n")
                }

                // Functions
                BlockType.CUSTOM_COMMAND_DEF -> {
                    val name = block.getField("name", "моя_команда").trim()
                    val params = block.getField("params", "").trim()
                    sb.append("\ndef $name($params):\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                    sb.append("\n")
                }
                BlockType.CUSTOM_COMMAND_RUN -> {
                    val call = block.getField("call", "pass").trim()
                    sb.append("${indent}$call\n")
                }
                BlockType.GIVE_RESULT -> {
                    val value = resolveFieldValue(block, "value", "")
                    if (value.isEmpty()) {
                        sb.append("${indent}return\n")
                    } else {
                        sb.append("${indent}return $value\n")
                    }
                }

                // Advanced & Imports
                BlockType.IMPORT_LIBRARY -> {
                    val libId = block.getField("lib", "neural_net")
                    val lib = PythonLibrary.findById(libId)
                    val importLines = lib?.importCode ?: "import $libId"
                    importLines.lines().forEach { line ->
                        sb.append("${indent}$line\n")
                    }
                }
                BlockType.ADD_NOTE -> {
                    val text = block.getField("text", "").trim()
                    sb.append("${indent}# $text\n")
                }
                BlockType.TRY_DO -> {
                    sb.append("${indent}try:\n")
                    sb.append(generatePython(block.children, indentLevel + 1))
                    sb.append("${indent}except Exception as e:\n")
                    sb.append(generatePython(block.secondaryChildren, indentLevel + 1))
                }
                BlockType.WRITE_FILE -> {
                    val file = block.getField("file", "\"заметка.txt\"").trim()
                    val text = resolveFieldValue(block, "text", "\"\"")
                    sb.append("${indent}with open($file, \"w\", encoding=\"utf-8\") as _f:\n")
                    sb.append("${indent}    _f.write(str($text))\n")
                }
                BlockType.RAW_PY -> {
                    val code = block.getField("code", "# код").trim()
                    code.lines().forEach { line ->
                        sb.append("${indent}$line\n")
                    }
                }

                // Extensions: Neural Networks
                BlockType.NN_CREATE_MODEL -> {
                    val inputs = block.getField("inputs", "4")
                    val hidden = block.getField("hidden", "16")
                    val outputs = block.getField("outputs", "2")
                    val v = block.getField("var", "нейросеть").trim()
                    sb.append("${indent}# Создание полносвязной архитектуры нейросети:\n")
                    sb.append("${indent}$v = torch.nn.Sequential(\n")
                    sb.append("${indent}    torch.nn.Linear($inputs, $hidden),\n")
                    sb.append("${indent}    torch.nn.ReLU(),\n")
                    sb.append("${indent}    torch.nn.Linear($hidden, $outputs)\n")
                    sb.append("${indent})\n")
                }
                BlockType.NN_TRAIN_EPOCHS -> {
                    val m = block.getField("model", "нейросеть").trim()
                    val epochs = block.getField("epochs", "10")
                    val lr = block.getField("lr", "0.01")
                    sb.append("${indent}# Обучение модели $m ($epochs эпох, lr=$lr):\n")
                    sb.append("${indent}_optimizer = torch.optim.Adam($m.parameters(), lr=$lr)\n")
                    sb.append("${indent}for _epoch in range($epochs):\n")
                    sb.append("${indent}    _optimizer.zero_grad()\n")
                    sb.append("${indent}    # Шаг градиентного спуска\n")
                }
                BlockType.NN_PREDICT -> {
                    val m = block.getField("model", "нейросеть").trim()
                    val inp = block.getField("input", "[0.5, 0.2, 0.9, 0.1]")
                    val saveTo = block.getField("save_to", "ответ").trim()
                    sb.append("${indent}$saveTo = $m(torch.tensor($inp, dtype=torch.float32)).tolist()\n")
                }
                BlockType.NN_ACTIVATION -> {
                    val func = block.getField("func", "ReLU").trim()
                    val inp = block.getField("input", "x").trim()
                    sb.append("${indent}torch.nn.functional.${func.lowercase()}($inp)\n")
                }
                BlockType.NN_CALC_LOSS -> {
                    val p = block.getField("pred", "ответ").trim()
                    val t = block.getField("target", "1").trim()
                    val saveTo = block.getField("save_to", "ошибка").trim()
                    sb.append("${indent}$saveTo = torch.nn.functional.mse_loss(torch.tensor($p), torch.tensor($t))\n")
                }

                // Extensions: API & Net
                BlockType.API_GET_REQUEST -> {
                    val url = resolveFieldValue(block, "url", "\"https://api.ipify.org?format=json\"")
                    val v = block.getField("var", "ответ_сервера").trim()
                    sb.append("${indent}$v = requests.get($url).json()\n")
                }
                BlockType.API_POST_JSON -> {
                    val url = resolveFieldValue(block, "url", "\"https://httpbin.org/post\"")
                    val data = block.getField("data", "{}").trim()
                    val v = block.getField("var", "ответ").trim()
                    sb.append("${indent}$v = requests.post($url, json=$data).json()\n")
                }
                BlockType.API_GET_MY_IP -> {
                    val v = block.getField("var", "мой_ip").trim()
                    sb.append("${indent}$v = requests.get(\"https://api.ipify.org?format=json\").json().get(\"ip\", \"127.0.0.1\")\n")
                }
                BlockType.API_PARSE_FIELD -> {
                    val jv = block.getField("json_var", "ответ_сервера").trim()
                    val f = resolveFieldValue(block, "field", "\"ip\"")
                    val saveTo = block.getField("save_to", "ip_адрес").trim()
                    sb.append("${indent}$saveTo = $jv.get($f, None)\n")
                }
                BlockType.API_STATUS_CODE -> {
                    val resp = block.getField("response", "ответ_сервера").trim()
                    sb.append("${indent}print(f\"Статус ответа: {getattr($resp, 'status_code', 200)}\")\n")
                }

                // Extensions: Random
                BlockType.RANDOM_INT_RANGE -> {
                    val from = resolveFieldValue(block, "from", "1")
                    val to = resolveFieldValue(block, "to", "100")
                    val v = block.getField("var", "случайное").trim()
                    sb.append("${indent}$v = random.randint($from, $to)\n")
                }
                BlockType.RANDOM_CHOICE_ITEM -> {
                    val list = block.getField("list", "числа").trim()
                    val v = block.getField("var", "выбор").trim()
                    sb.append("${indent}$v = random.choice($list)\n")
                }
                BlockType.RANDOM_SHUFFLE_LIST -> {
                    val list = block.getField("list", "числа").trim()
                    sb.append("${indent}random.shuffle($list)\n")
                }
                BlockType.RANDOM_FLOAT_01 -> {
                    val v = block.getField("var", "дробь").trim()
                    sb.append("${indent}$v = random.random()\n")
                }

                // Extensions: OS & Sys
                BlockType.OS_LIST_FILES -> {
                    val p = resolveFieldValue(block, "path", "\".\"")
                    val v = block.getField("var", "файлы").trim()
                    sb.append("${indent}$v = os.listdir($p)\n")
                }
                BlockType.OS_FILE_EXISTS -> {
                    val p = resolveFieldValue(block, "path", "\"\"")
                    sb.append("${indent}os.path.exists($p)\n")
                }
                BlockType.OS_CREATE_FOLDER -> {
                    val p = resolveFieldValue(block, "path", "\"новая_папка\"")
                    sb.append("${indent}os.makedirs($p, exist_ok=True)\n")
                }
                BlockType.OS_GET_SYSTEM -> {
                    val v = block.getField("var", "система").trim()
                    sb.append("${indent}$v = os.name\n")
                }
                BlockType.OS_EXIT_APP -> {
                    sb.append("${indent}sys.exit(0)\n")
                }

                // Extensions: Time & Date
                BlockType.TIME_SLEEP_MS -> {
                    val ms = block.getField("ms", "500").trim()
                    sb.append("${indent}time.sleep(($ms) / 1000.0)\n")
                }
                BlockType.TIME_CURRENT_TIMESTAMP -> {
                    val v = block.getField("var", "время_сек").trim()
                    sb.append("${indent}$v = time.time()\n")
                }
                BlockType.TIME_FORMATTED_DATE -> {
                    val fmt = resolveFieldValue(block, "format", "\"%Y-%m-%d %H:%M\"")
                    val v = block.getField("var", "дата").trim()
                    sb.append("${indent}$v = datetime.now().strftime($fmt)\n")
                }
                BlockType.TIME_BENCHMARK -> {
                    sb.append("${indent}_t0 = time.time()\n")
                    sb.append(generatePython(block.children, indentLevel))
                    sb.append("${indent}_dt = time.time() - _t0\n")
                    sb.append("${indent}print(f\"Время выполнения: {_dt:.4f} сек\")\n")
                }

                // Extensions: Math & Stats
                BlockType.MATH_SQRT -> {
                    val num = resolveFieldValue(block, "num", "16")
                    val v = block.getField("var", "корень").trim()
                    sb.append("${indent}$v = math.sqrt($num)\n")
                }
                BlockType.MATH_POW -> {
                    val num = resolveFieldValue(block, "num", "2")
                    val p = resolveFieldValue(block, "power", "8")
                    val v = block.getField("var", "результат").trim()
                    sb.append("${indent}$v = math.pow($num, $p)\n")
                }
                BlockType.MATH_TRIG_SIN_COS -> {
                    val fn = block.getField("func", "sin").trim()
                    val a = resolveFieldValue(block, "angle", "0")
                    val v = block.getField("var", "синус").trim()
                    sb.append("${indent}$v = math.$fn($a)\n")
                }
                BlockType.MATH_CONSTANTS -> {
                    val c = block.getField("const", "pi").trim()
                    val v = block.getField("var", "число_пи").trim()
                    sb.append("${indent}$v = math.$c\n")
                }
                BlockType.STAT_MEAN_MEDIAN -> {
                    val stat = block.getField("stat", "mean").trim()
                    val list = block.getField("list", "числа").trim()
                    val v = block.getField("var", "среднее").trim()
                    sb.append("${indent}$v = statistics.$stat($list)\n")
                }

                // Extensions: Turtle Graphics
                BlockType.TURTLE_FORWARD -> {
                    val steps = block.getField("steps", "100").trim()
                    sb.append("${indent}turtle.forward($steps)\n")
                }
                BlockType.TURTLE_TURN -> {
                    val dir = block.getField("dir", "направо").trim()
                    val deg = block.getField("degrees", "90").trim()
                    val fn = if (dir.contains("лев")) "left" else "right"
                    sb.append("${indent}turtle.$fn($deg)\n")
                }
                BlockType.TURTLE_PEN_UP_DOWN -> {
                    val s = block.getField("state", "опустить").trim()
                    val fn = if (s.contains("подн")) "penup" else "pendown"
                    sb.append("${indent}turtle.$fn()\n")
                }
                BlockType.TURTLE_SET_COLOR -> {
                    val col = resolveFieldValue(block, "color", "\"red\"")
                    sb.append("${indent}turtle.color($col)\n")
                }

                // Extensions: SQLite
                BlockType.SQLITE_CONNECT -> {
                    val db = resolveFieldValue(block, "db", "\"app.db\"")
                    val v = block.getField("var", "база").trim()
                    sb.append("${indent}$v = sqlite3.connect($db)\n")
                }
                BlockType.SQLITE_EXECUTE -> {
                    val db = block.getField("db", "база").trim()
                    val sql = resolveFieldValue(block, "sql", "\"\"")
                    sb.append("${indent}$db.cursor().execute($sql)\n")
                    sb.append("${indent}$db.commit()\n")
                }
                BlockType.SQLITE_FETCH_ALL -> {
                    val db = block.getField("db", "база").trim()
                    val q = resolveFieldValue(block, "query", "\"\"")
                    val v = block.getField("var", "строки").trim()
                    sb.append("${indent}$v = $db.cursor().execute($q).fetchall()\n")
                }

                else -> {}
            }
        }

        return sb.toString()
    }

    fun generateFullScript(blocks: List<Block>, appTitle: String = "PyBlocks Script"): String {
        val codeBody = generatePython(blocks, indentLevel = 0)
        return """
# =======================================================
# PyBlocks: $appTitle
# Чистый код Python 3
# =======================================================
$codeBody
""".trimIndent()
    }
}
