package com.example.model

data class PythonLibrary(
    val id: String,
    val name: String,
    val shortDesc: String,
    val detailedDesc: String,
    val importCode: String,
    val category: BlockCategory,
    val iconName: String,
    val primaryColorHex: Long,
    val accentColorHex: Long,
    val sampleBlockNames: List<String>
) {
    companion object {
        val ALL_LIBRARIES = listOf(
            PythonLibrary(
                id = "neural_net",
                name = "🧠 Нейросети и AI",
                shortDesc = "Создание, слои и обучение нейросетей",
                detailedDesc = "Полноценный набор для машинного обучения: создание полносвязных слоев (Dense), функции активации (ReLU, Sigmoid, Softmax), обучение по эпохам, оптимизатор и предсказание результатов.",
                importCode = "import torch\nimport torch.nn as nn",
                category = BlockCategory.EXT_NEURAL_NET,
                iconName = "psychology",
                primaryColorHex = 0xFF6200EA,
                accentColorHex = 0xFF4A148C,
                sampleBlockNames = listOf("Создать нейросеть", "Обучить N эпох", "Сделать предсказание", "Функция активации")
            ),
            PythonLibrary(
                id = "requests",
                name = "🌐 API, Сеть и IP",
                shortDesc = "HTTP GET/POST запросы, IP адрес, парсинг JSON",
                detailedDesc = "Работа с внешними интернет-серверами, отправка HTTP запросов, определение своего IP адреса и города, чтение ответов API в формате JSON.",
                importCode = "import requests\nimport json",
                category = BlockCategory.EXT_API,
                iconName = "cloud_download",
                primaryColorHex = 0xFF0288D1,
                accentColorHex = 0xFF01579B,
                sampleBlockNames = listOf("Отправить GET запрос", "Отправить POST с JSON", "Узнать свой IP адрес", "Прочитать JSON поле")
            ),
            PythonLibrary(
                id = "random",
                name = "🎲 Случайность (random)",
                shortDesc = "Генератор чисел, выбор и перемешивание",
                detailedDesc = "Случайный выбор элементов из списка, перемешивание колоды, генерация дробных и целых случайных чисел, бросок кубиков и монеток.",
                importCode = "import random",
                category = BlockCategory.EXT_RANDOM,
                iconName = "casino",
                primaryColorHex = 0xFFE91E63,
                accentColorHex = 0xFFC2185B,
                sampleBlockNames = listOf("Случайное число от..до", "Случайный выбор из списка", "Перемешать список", "Случайное от 0.0 до 1.0")
            ),
            PythonLibrary(
                id = "os_sys",
                name = "💻 Операционная система (os & sys)",
                shortDesc = "Работа с файловой системой, папками и ОС",
                detailedDesc = "Просмотр содержимого папок, проверка существования файлов, создание каталогов, определение версии операционной системы и корректный выход из программы.",
                importCode = "import os\nimport sys",
                category = BlockCategory.EXT_OS,
                iconName = "terminal",
                primaryColorHex = 0xFF455A64,
                accentColorHex = 0xFF263238,
                sampleBlockNames = listOf("Список файлов в папке", "Файл существует?", "Создать папку", "Имя операционной системы")
            ),
            PythonLibrary(
                id = "time_date",
                name = "⏰ Время и Дата (time & datetime)",
                shortDesc = "Таймеры, замеры времени и форматирование даты",
                detailedDesc = "Точные паузы, измерение скорости выполнения алгоритмов, получение текущего времени, форматирование дат (день, месяц, год, часы).",
                importCode = "import time\nfrom datetime import datetime",
                category = BlockCategory.EXT_TIME,
                iconName = "schedule",
                primaryColorHex = 0xFF009688,
                accentColorHex = 0xFF004D40,
                sampleBlockNames = listOf("Пауза в миллисекундах", "Текущий timestamp", "Текущая дата и время", "Замер времени работы")
            ),
            PythonLibrary(
                id = "math_stat",
                name = "📊 Математика и Статистика (math)",
                shortDesc = "Тригонометрия, корни, константы и среднее",
                detailedDesc = "Квадратные корни, возведение в степень, синус, косинус, тангенс, число Пи, экспонента, расчет среднего арифметического и медианы списка.",
                importCode = "import math\nimport statistics",
                category = BlockCategory.EXT_MATH,
                iconName = "functions",
                primaryColorHex = 0xFF2E7D32,
                accentColorHex = 0xFF1B5E20,
                sampleBlockNames = listOf("Квадратный корень", "Степень числа", "Тригонометрия sin/cos", "Среднее значение (mean)")
            ),
            PythonLibrary(
                id = "graphics",
                name = "🎮 Графика и Игры (turtle)",
                shortDesc = "Рисование фигур, черепашья графика и холст",
                detailedDesc = "Команды для рисования геометрических фигур, управление виртуальной черепашкой, поворот, перемещение, цвет линий и заливка холста.",
                importCode = "import turtle",
                category = BlockCategory.EXT_GRAPHICS,
                iconName = "sports_esports",
                primaryColorHex = 0xFFFF6F00,
                accentColorHex = 0xFFE65100,
                sampleBlockNames = listOf("Черепашка: шаг вперёд", "Черепашка: повернуть", "Перо поднять/опустить", "Цвет пера")
            ),
            PythonLibrary(
                id = "sqlite",
                name = "💾 База данных (sqlite3)",
                shortDesc = "Локальная база данных, таблицы и SQL запросы",
                detailedDesc = "Создание таблиц, добавление пользователей, сохранение рекордов и извлечение данных с помощью настоящих SQL запросов.",
                importCode = "import sqlite3",
                category = BlockCategory.EXT_DATABASE,
                iconName = "storage",
                primaryColorHex = 0xFF5D4037,
                accentColorHex = 0xFF3E2723,
                sampleBlockNames = listOf("Подключиться к базе данных", "Выполнить SQL запрос", "Получить все записи таблицы")
            )
        )

        fun findById(id: String): PythonLibrary? {
            return ALL_LIBRARIES.find { it.id.equals(id, ignoreCase = true) }
        }

        fun findByCategory(category: BlockCategory): PythonLibrary? {
            return ALL_LIBRARIES.find { it.category == category }
        }
    }
}
