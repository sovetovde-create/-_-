package com.example.model

import java.util.UUID

enum class BlockCategory(
    val title: String,
    val hexColor: Long,
    val hexBorderColor: Long,
    val iconName: String,
    val isArduino: Boolean = false,
    val isExtension: Boolean = false,
    val libraryId: String? = null
) {
    // Standard Python Categories
    DIALOG("Общение", 0xFFE53935, 0xFFC62828, "chat", false),
    VARIABLES("Память", 0xFFFB8C00, 0xFFEF6C00, "memory", false),
    CONTROL("Управление", 0xFFF59E0B, 0xFFD97706, "repeat", false),
    NUMBERS_MATH("Математика", 0xFF43A047, 0xFF2E7D32, "calculate", false),
    TEXT_OPS("Текст", 0xFF00ACC1, 0xFF00838F, "text_fields", false),
    LISTS("Списки", 0xFF8E24AA, 0xFF6A1B9A, "list", false),
    FUNCTIONS("Команды", 0xFF3949AB, 0xFF283593, "code", false),
    ADVANCED("Разное", 0xFF546E7A, 0xFF37474F, "more_horiz", false),

    // Python Extension / Library Categories (Scratch-like)
    EXT_NEURAL_NET("Нейросети", 0xFF6200EA, 0xFF4A148C, "psychology", false, true, "neural_net"),
    EXT_API("API & Сеть", 0xFF0288D1, 0xFF01579B, "cloud_download", false, true, "requests"),
    EXT_RANDOM("Случайность", 0xFFE91E63, 0xFFC2185B, "casino", false, true, "random"),
    EXT_OS("Система OS", 0xFF455A64, 0xFF263238, "terminal", false, true, "os_sys"),
    EXT_TIME("Время & Дата", 0xFF009688, 0xFF004D40, "schedule", false, true, "time_date"),
    EXT_MATH("Мат & Статистика", 0xFF2E7D32, 0xFF1B5E20, "functions", false, true, "math_stat"),
    EXT_GRAPHICS("Графика & Игры", 0xFFFF6F00, 0xFFE65100, "sports_esports", false, true, "graphics"),
    EXT_DATABASE("База SQLite", 0xFF5D4037, 0xFF3E2723, "storage", false, true, "sqlite"),

    // Arduino Categories
    ARDUINO_LEDS("Лампочки", 0xFFE53935, 0xFFC62828, "lightbulb", true),
    ARDUINO_SERVO("Сервопривод", 0xFFFB8C00, 0xFFEF6C00, "rotate_right", true),
    ARDUINO_MOTORS("Моторы и Драйверы", 0xFF43A047, 0xFF2E7D32, "toys", true),
    ARDUINO_SENSORS("Датчики", 0xFF00ACC1, 0xFF00838F, "sensors", true),
    ARDUINO_BUZZER("Зуммер", 0xFF8E24AA, 0xFF6A1B9A, "volume_up", true),
    ARDUINO_DISPLAYS("Экраны", 0xFF00897B, 0xFF00695C, "tv", true),
    ARDUINO_CONTROL("Управление", 0xFFF59E0B, 0xFFD97706, "timer", true),
    ARDUINO_SERIAL("Связь ПК", 0xFF3949AB, 0xFF283593, "usb", true)
}

enum class BlockType(
    val category: BlockCategory,
    val displayName: String,
    val isContainer: Boolean = false,
    val hasSecondaryContainer: Boolean = false,
    val isExpression: Boolean = false
) {
    // ==========================================
    // 1. PYTHON STANDARD BLOCKS
    // ==========================================

    // Dialog & Output
    ASK_INPUT(BlockCategory.DIALOG, "Спросить и сохранить ответ"),
    ASK_NUMBER(BlockCategory.DIALOG, "Спросить число и сохранить"),
    SAY(BlockCategory.DIALOG, "Сказать (написать)"),
    SAY_PHRASE(BlockCategory.DIALOG, "Сказать фразу с переменными"),
    CLEAR_SCREEN(BlockCategory.DIALOG, "Очистить экран"),

    // Variables
    SET_VARIABLE(BlockCategory.VARIABLES, "Запомнить: переменная = значение"),
    CHANGE_BY(BlockCategory.VARIABLES, "Увеличить переменную на"),
    CALCULATE_INTO(BlockCategory.VARIABLES, "Посчитать и сохранить"),
    CALCULATE_FORMULA_STRING(BlockCategory.VARIABLES, "Вычислить формулу из строки в переменную"),

    // Control
    IF_SIMPLE(BlockCategory.CONTROL, "Если <условие>, то:", isContainer = true),
    IF_ELSE_SIMPLE(BlockCategory.CONTROL, "Если <условие>, то: ... Иначе:", isContainer = true, hasSecondaryContainer = true),
    REPEAT_TIMES(BlockCategory.CONTROL, "Повторить <количество> раз:", isContainer = true),
    WHILE_LOOP(BlockCategory.CONTROL, "Повторять, пока верно <условие>:", isContainer = true),
    FOR_EACH_ITEM(BlockCategory.CONTROL, "Для каждого <элемента> из списка:", isContainer = true),
    WAIT_SECONDS(BlockCategory.CONTROL, "Подождать <секунд>"),
    STOP_LOOP(BlockCategory.CONTROL, "Остановить цикл (выйти)"),
    NEXT_ROUND(BlockCategory.CONTROL, "Перейти к следующему кругу"),
    STOP_ALL(BlockCategory.CONTROL, "Завершить программу"),

    // Numbers & Math
    EXPR_RANDOM_NUM(BlockCategory.NUMBERS_MATH, "Случайное число от и до", isExpression = true),
    EXPR_ROUND(BlockCategory.NUMBERS_MATH, "Округлить число", isExpression = true),
    EXPR_ABS(BlockCategory.NUMBERS_MATH, "Модуль числа (без минуса)", isExpression = true),
    EXPR_MATH_OP(BlockCategory.NUMBERS_MATH, "Вычислить: (a + b)", isExpression = true),
    EXPR_COMPARE_VALS(BlockCategory.NUMBERS_MATH, "Сравнить: (a == b)", isExpression = true),
    EVAL_EXPRESSION(BlockCategory.NUMBERS_MATH, "Вычислить выражение из строки (eval)", isExpression = true),

    // Text Ops
    TEXT_TO_UPPER(BlockCategory.TEXT_OPS, "Сделать заглавными буквами"),
    TEXT_TO_LOWER(BlockCategory.TEXT_OPS, "Сделать строчными буквами"),
    TEXT_REPLACE(BlockCategory.TEXT_OPS, "Заменить в тексте часть на"),
    EXPR_TEXT_CONTAINS(BlockCategory.TEXT_OPS, "Текст содержит слово?", isExpression = true),
    EXPR_TEXT_LENGTH(BlockCategory.TEXT_OPS, "Длина текста (число букв)", isExpression = true),

    // Lists
    CREATE_LIST(BlockCategory.LISTS, "Создать список элементов"),
    ADD_TO_LIST(BlockCategory.LISTS, "Добавить в список элемент"),
    GET_FROM_LIST(BlockCategory.LISTS, "Взять элемент по номеру"),
    REMOVE_FROM_LIST(BlockCategory.LISTS, "Удалить из списка элемент"),
    REVERSE_LIST(BlockCategory.LISTS, "Перевернуть список"),
    EXPR_RANDOM_CHOICE(BlockCategory.LISTS, "Случайный выбор из списка", isExpression = true),
    EXPR_LIST_SIZE(BlockCategory.LISTS, "Количество элементов в списке", isExpression = true),

    // Functions
    CUSTOM_COMMAND_DEF(BlockCategory.FUNCTIONS, "Создать команду <имя>:", isContainer = true),
    CUSTOM_COMMAND_RUN(BlockCategory.FUNCTIONS, "Выполнить команду <имя>"),
    GIVE_RESULT(BlockCategory.FUNCTIONS, "Вернуть результат (ответ)"),

    // Advanced & Library Import
    IMPORT_LIBRARY(BlockCategory.ADVANCED, "📦 Библиотека: import <имя>"),
    ADD_NOTE(BlockCategory.ADVANCED, "Заметка (комментарий)"),
    TRY_DO(BlockCategory.ADVANCED, "Попробовать сделать: ... Если ошибка:", isContainer = true, hasSecondaryContainer = true),
    WRITE_FILE(BlockCategory.ADVANCED, "Записать в файл текст"),
    RAW_PY(BlockCategory.ADVANCED, "Строка чистого кода Python"),

    // ==========================================
    // 2. PYTHON EXTENSIONS (LIBRARIES)
    // ==========================================

    // 🧠 Neural Networks
    NN_CREATE_MODEL(BlockCategory.EXT_NEURAL_NET, "Создать нейросеть (входы, скрытые, выходы)"),
    NN_TRAIN_EPOCHS(BlockCategory.EXT_NEURAL_NET, "Обучить нейросеть N эпох (lr скор. обучения)"),
    NN_PREDICT(BlockCategory.EXT_NEURAL_NET, "Сделать предсказание нейросетью"),
    NN_ACTIVATION(BlockCategory.EXT_NEURAL_NET, "Функция активации (ReLU, Sigmoid)", isExpression = true),
    NN_CALC_LOSS(BlockCategory.EXT_NEURAL_NET, "Рассчитать ошибку обучения (Loss MSE)"),

    // 🌐 API & Network
    API_GET_REQUEST(BlockCategory.EXT_API, "Отправить GET запрос на URL в переменную"),
    API_POST_JSON(BlockCategory.EXT_API, "Отправить POST запрос с JSON данными"),
    API_GET_MY_IP(BlockCategory.EXT_API, "Узнать свой IP адрес через API"),
    API_PARSE_FIELD(BlockCategory.EXT_API, "Извлечь поле из JSON ответа"),
    API_STATUS_CODE(BlockCategory.EXT_API, "Проверить статус ответа (200 OK)", isExpression = true),

    // 🎲 Random
    RANDOM_INT_RANGE(BlockCategory.EXT_RANDOM, "Случайное целое число от и до"),
    RANDOM_CHOICE_ITEM(BlockCategory.EXT_RANDOM, "Случайный выбор из списка"),
    RANDOM_SHUFFLE_LIST(BlockCategory.EXT_RANDOM, "Перемешать список случайно"),
    RANDOM_FLOAT_01(BlockCategory.EXT_RANDOM, "Случайная дробь от 0.0 до 1.0 в переменную"),

    // 💻 OS & Sys
    OS_LIST_FILES(BlockCategory.EXT_OS, "Список файлов в папке сохранить в список"),
    OS_FILE_EXISTS(BlockCategory.EXT_OS, "Проверить: файл существует?", isExpression = true),
    OS_CREATE_FOLDER(BlockCategory.EXT_OS, "Создать новую папку"),
    OS_GET_SYSTEM(BlockCategory.EXT_OS, "Имя операционной системы в переменную"),
    OS_EXIT_APP(BlockCategory.EXT_OS, "Экстренно завершить выполнение программы"),

    // ⏰ Time & Date
    TIME_SLEEP_MS(BlockCategory.EXT_TIME, "Точная пауза в миллисекундах (мс)"),
    TIME_CURRENT_TIMESTAMP(BlockCategory.EXT_TIME, "Текущее время (timestamp) в секундах"),
    TIME_FORMATTED_DATE(BlockCategory.EXT_TIME, "Текущая дата и время с форматом"),
    TIME_BENCHMARK(BlockCategory.EXT_TIME, "Замерить время выполнения:", isContainer = true),

    // 📊 Math & Statistics
    MATH_SQRT(BlockCategory.EXT_MATH, "Квадратный корень числа (sqrt)"),
    MATH_POW(BlockCategory.EXT_MATH, "Возвести число в степень"),
    MATH_TRIG_SIN_COS(BlockCategory.EXT_MATH, "Тригонометрия: sin / cos / tan"),
    MATH_CONSTANTS(BlockCategory.EXT_MATH, "Константа числа Пи (pi) или экспонента"),
    STAT_MEAN_MEDIAN(BlockCategory.EXT_MATH, "Среднее значение списка чисел (mean)"),

    // 🎮 Turtle Graphics
    TURTLE_FORWARD(BlockCategory.EXT_GRAPHICS, "Черепашка: шаг вперёд на N пикселей"),
    TURTLE_TURN(BlockCategory.EXT_GRAPHICS, "Черепашка: повернуть на N градусов"),
    TURTLE_PEN_UP_DOWN(BlockCategory.EXT_GRAPHICS, "Черепашка: перо (поднять / опустить)"),
    TURTLE_SET_COLOR(BlockCategory.EXT_GRAPHICS, "Установить цвет пера черепашки"),

    // 💾 SQLite Database
    SQLITE_CONNECT(BlockCategory.EXT_DATABASE, "Подключиться к базе данных SQLite"),
    SQLITE_EXECUTE(BlockCategory.EXT_DATABASE, "Выполнить SQL команду (INSERT/CREATE)"),
    SQLITE_FETCH_ALL(BlockCategory.EXT_DATABASE, "Получить все строки запроса (SELECT)"),

    // ==========================================
    // 3. ARDUINO BLOCKS
    // ==========================================

    // Лампочки и Светодиоды
    ARDUINO_DIGITAL_WRITE_HIGH(BlockCategory.ARDUINO_LEDS, "Включить лампочку на пине (HIGH)"),
    ARDUINO_DIGITAL_WRITE_LOW(BlockCategory.ARDUINO_LEDS, "Выключить лампочку на пине (LOW)"),
    ARDUINO_BLINK_LED(BlockCategory.ARDUINO_LEDS, "Мигать лампочкой на пине"),
    ARDUINO_PWM_BRIGHTNESS(BlockCategory.ARDUINO_LEDS, "Яркость лампочки (ШИМ 0-255)"),
    ARDUINO_PIN_MODE(BlockCategory.ARDUINO_LEDS, "Настроить пин платы (ВЫХОД / ВХОД)"),
    ARDUINO_TOGGLE_PIN(BlockCategory.ARDUINO_LEDS, "Переключить состояние пина"),

    // Сервоприводы
    ARDUINO_SERVO_ATTACH(BlockCategory.ARDUINO_SERVO, "Подключить сервопривод к пину"),
    ARDUINO_SERVO_WRITE(BlockCategory.ARDUINO_SERVO, "Повернуть сервопривод на угол"),
    ARDUINO_SERVO_SWEEP(BlockCategory.ARDUINO_SERVO, "Плавно повернуть от угла до угла"),

    // Моторчики и Драйверы
    ARDUINO_MOTOR_FORWARD(BlockCategory.ARDUINO_MOTORS, "Включить мотор: вращать вперед"),
    ARDUINO_MOTOR_BACKWARD(BlockCategory.ARDUINO_MOTORS, "Включить мотор: вращать назад"),
    ARDUINO_MOTOR_STOP(BlockCategory.ARDUINO_MOTORS, "Остановить мотор"),
    ARDUINO_L298N_DRIVER(BlockCategory.ARDUINO_MOTORS, "Драйвер мотора L298N (IN1, IN2, Скорость)"),
    ARDUINO_L298N_MOTOR_A(BlockCategory.ARDUINO_MOTORS, "L298N Мотор A (IN1, IN2, ENA [ШИМ])"),
    ARDUINO_L298N_MOTOR_B(BlockCategory.ARDUINO_MOTORS, "L298N Мотор B (IN3, IN4, ENB [ШИМ])"),
    ARDUINO_L298N_STOP_ALL(BlockCategory.ARDUINO_MOTORS, "L298N: Остановить все моторы"),
    ARDUINO_L9110S_MOTOR(BlockCategory.ARDUINO_MOTORS, "Драйвер L9110S (Пин 1, Пин 2, Скорость)"),
    ARDUINO_STEPPER_STEP(BlockCategory.ARDUINO_MOTORS, "Шаговый мотор 28BYJ-48 (ULN2003)"),

    // Датчики и Кнопки
    ARDUINO_DIGITAL_READ(BlockCategory.ARDUINO_SENSORS, "Считать кнопку/пин платы"),
    ARDUINO_ANALOG_READ(BlockCategory.ARDUINO_SENSORS, "Считать аналоговый датчик (A0-A5)"),
    ARDUINO_ULTRASONIC(BlockCategory.ARDUINO_SENSORS, "Ультразвуковой дальномер HC-SR04 (см)"),
    ARDUINO_IF_BUTTON(BlockCategory.ARDUINO_SENSORS, "Если кнопка нажата, то:", isContainer = true),

    // Зуммер / Звук
    ARDUINO_BUZZER_TONE(BlockCategory.ARDUINO_BUZZER, "Издать звук (частота Гц и время)"),
    ARDUINO_BUZZER_NOTONE(BlockCategory.ARDUINO_BUZZER, "Выключить звук на пине"),
    ARDUINO_BUZZER_BEEP(BlockCategory.ARDUINO_BUZZER, "Короткий звуковой сигнал (бип)"),

    // Дисплеи и Экраны (LCD, OLED, TM1637)
    ARDUINO_LCD_INIT(BlockCategory.ARDUINO_DISPLAYS, "Подключить LCD 1602 (I2C 0x27)"),
    ARDUINO_LCD_CLEAR(BlockCategory.ARDUINO_DISPLAYS, "LCD: Очистить экран"),
    ARDUINO_LCD_PRINT(BlockCategory.ARDUINO_DISPLAYS, "LCD: Напечатать текст на строке"),
    ARDUINO_LCD_PRINT_VAR(BlockCategory.ARDUINO_DISPLAYS, "LCD: Напечатать значение переменной"),
    ARDUINO_LCD_BACKLIGHT(BlockCategory.ARDUINO_DISPLAYS, "LCD: Подсветка (ВКЛ / ВЫКЛ)"),
    ARDUINO_OLED_INIT(BlockCategory.ARDUINO_DISPLAYS, "Подключить OLED 0.96\" (SSD1306 128x64)"),
    ARDUINO_OLED_CLEAR(BlockCategory.ARDUINO_DISPLAYS, "OLED: Очистить экран"),
    ARDUINO_OLED_PRINT(BlockCategory.ARDUINO_DISPLAYS, "OLED: Напечатать текст с координатами"),
    ARDUINO_OLED_PRINT_VAR(BlockCategory.ARDUINO_DISPLAYS, "OLED: Напечатать значение с координатами"),
    ARDUINO_TM1637_INIT(BlockCategory.ARDUINO_DISPLAYS, "Подключить 7-сегментный TM1637 (CLK, DIO)"),
    ARDUINO_TM1637_NUMBER(BlockCategory.ARDUINO_DISPLAYS, "TM1637: Показать число (0-9999)"),
    ARDUINO_TM1637_CLEAR(BlockCategory.ARDUINO_DISPLAYS, "TM1637: Очистить индикатор"),

    // Управление и Время
    ARDUINO_DELAY_MS(BlockCategory.ARDUINO_CONTROL, "Подождать миллисекунд (мс)"),
    ARDUINO_DELAY_SEC(BlockCategory.ARDUINO_CONTROL, "Подождать секунд"),
    ARDUINO_IF_ELSE(BlockCategory.ARDUINO_CONTROL, "Если <условие>, то: ... Иначе:", isContainer = true, hasSecondaryContainer = true),
    ARDUINO_REPEAT_TIMES(BlockCategory.ARDUINO_CONTROL, "Повторить <количество> раз:", isContainer = true),
    ARDUINO_LOOP_FOREVER(BlockCategory.ARDUINO_CONTROL, "Бесконечный цикл (повторять всегда):", isContainer = true),
    ARDUINO_VARIABLE_SET(BlockCategory.ARDUINO_CONTROL, "Запомнить: переменная = значение"),
    ARDUINO_MAP_RANGE(BlockCategory.ARDUINO_CONTROL, "Преобразовать диапазон (map)"),

    // Связь с ПК (Serial)
    ARDUINO_SERIAL_BEGIN(BlockCategory.ARDUINO_SERIAL, "Включить монитор порта (Serial)"),
    ARDUINO_SERIAL_PRINTLN(BlockCategory.ARDUINO_SERIAL, "Отправить текст в монитор порта"),
    ARDUINO_SERIAL_PRINT_VAR(BlockCategory.ARDUINO_SERIAL, "Отправить значение переменной в монитор")
}

data class BlockField(
    val key: String,
    val label: String,
    val defaultValue: String,
    val hint: String = "",
    val acceptsBlock: Boolean = false
)

data class Block(
    val id: String = UUID.randomUUID().toString(),
    val type: BlockType,
    val fields: Map<String, String> = emptyMap(),
    val nestedBlocks: Map<String, Block> = emptyMap(),
    val children: List<Block> = emptyList(),
    val secondaryChildren: List<Block> = emptyList()
) {
    fun getField(key: String, default: String = ""): String = fields[key] ?: default

    fun getNested(key: String): Block? = nestedBlocks[key]

    fun copyWithField(key: String, value: String): Block {
        val newFields = fields.toMutableMap()
        newFields[key] = value
        return this.copy(fields = newFields)
    }

    fun copyWithNested(key: String, block: Block?): Block {
        val newNested = nestedBlocks.toMutableMap()
        if (block != null) {
            newNested[key] = block
        } else {
            newNested.remove(key)
        }
        return this.copy(nestedBlocks = newNested)
    }

    companion object {
        fun createDefault(type: BlockType): Block {
            val defaultFields = when (type) {
                // Dialog
                BlockType.ASK_INPUT -> mapOf("question" to "\"Как тебя зовут? \"", "var" to "имя")
                BlockType.ASK_NUMBER -> mapOf("question" to "\"Сколько тебе лет? \"", "var" to "возраст")
                BlockType.SAY -> mapOf("text" to "\"Привет!\"")
                BlockType.SAY_PHRASE -> mapOf("template" to "Привет, {имя}! Тебе {возраст} лет.")
                BlockType.CLEAR_SCREEN -> emptyMap()

                // Variables
                BlockType.SET_VARIABLE -> mapOf("var" to "счет", "value" to "10")
                BlockType.CHANGE_BY -> mapOf("var" to "счет", "value" to "1")
                BlockType.CALCULATE_INTO -> mapOf("var" to "итог", "left" to "a", "op" to "+", "right" to "b")
                BlockType.CALCULATE_FORMULA_STRING -> mapOf("formula" to "\"2 + 2 * 2\"", "var" to "ответ")

                // Control
                BlockType.IF_SIMPLE -> mapOf("condition" to "счет > 0")
                BlockType.IF_ELSE_SIMPLE -> mapOf("condition" to "счет > 0")
                BlockType.REPEAT_TIMES -> mapOf("times" to "5", "var" to "i")
                BlockType.WHILE_LOOP -> mapOf("condition" to "счет > 0")
                BlockType.FOR_EACH_ITEM -> mapOf("item" to "элемент", "list" to "список_дел")
                BlockType.WAIT_SECONDS -> mapOf("seconds" to "1")
                BlockType.STOP_LOOP -> emptyMap()
                BlockType.NEXT_ROUND -> emptyMap()
                BlockType.STOP_ALL -> emptyMap()

                // Math Expressions
                BlockType.EXPR_RANDOM_NUM -> mapOf("from" to "1", "to" to "10")
                BlockType.EXPR_ROUND -> mapOf("number" to "3.14")
                BlockType.EXPR_ABS -> mapOf("number" to "-5")
                BlockType.EXPR_MATH_OP -> mapOf("left" to "5", "op" to "+", "right" to "10")
                BlockType.EXPR_COMPARE_VALS -> mapOf("left" to "ответ", "op" to "==", "right" to "\"да\"")
                BlockType.EVAL_EXPRESSION -> mapOf("expression" to "\"10 * 5 + 3\"")

                // Text
                BlockType.TEXT_TO_UPPER -> mapOf("var" to "текст", "save_to" to "громкий_текст")
                BlockType.TEXT_TO_LOWER -> mapOf("var" to "текст", "save_to" to "тихий_текст")
                BlockType.TEXT_REPLACE -> mapOf("target" to "текст", "old" to "\"кот\"", "new" to "\"пёс\"", "save_to" to "новый_текст")
                BlockType.EXPR_TEXT_CONTAINS -> mapOf("text" to "текст", "word" to "\"привет\"")
                BlockType.EXPR_TEXT_LENGTH -> mapOf("text" to "текст")

                // Lists
                BlockType.CREATE_LIST -> mapOf("var" to "числа", "items" to "1, 2, 3, 4, 5")
                BlockType.ADD_TO_LIST -> mapOf("list" to "числа", "item" to "6")
                BlockType.GET_FROM_LIST -> mapOf("list" to "числа", "index" to "0", "save_to" to "первый")
                BlockType.REMOVE_FROM_LIST -> mapOf("list" to "числа", "item" to "6")
                BlockType.REVERSE_LIST -> mapOf("list" to "числа")
                BlockType.EXPR_RANDOM_CHOICE -> mapOf("list" to "числа")
                BlockType.EXPR_LIST_SIZE -> mapOf("list" to "числа")

                // Functions
                BlockType.CUSTOM_COMMAND_DEF -> mapOf("name" to "поздороваться", "params" to "имя")
                BlockType.CUSTOM_COMMAND_RUN -> mapOf("call" to "поздороваться(\"Алекс\")")
                BlockType.GIVE_RESULT -> mapOf("value" to "\"готово\"")

                // Advanced
                BlockType.IMPORT_LIBRARY -> mapOf("lib" to "neural_net", "name" to "🧠 Нейросети (torch)")
                BlockType.ADD_NOTE -> mapOf("text" to "Здесь начинается главная логика")
                BlockType.TRY_DO -> emptyMap()
                BlockType.WRITE_FILE -> mapOf("file" to "\"заметка.txt\"", "text" to "\"Привет файл!\"")
                BlockType.RAW_PY -> mapOf("code" to "print(\"Запуск Python кода\")")

                // Python Extensions: Neural Net
                BlockType.NN_CREATE_MODEL -> mapOf("inputs" to "4", "hidden" to "16", "outputs" to "2", "var" to "нейросеть")
                BlockType.NN_TRAIN_EPOCHS -> mapOf("model" to "нейросеть", "epochs" to "10", "lr" to "0.01")
                BlockType.NN_PREDICT -> mapOf("model" to "нейросеть", "input" to "[0.5, 0.2, 0.9, 0.1]", "save_to" to "ответ")
                BlockType.NN_ACTIVATION -> mapOf("func" to "ReLU", "input" to "x")
                BlockType.NN_CALC_LOSS -> mapOf("pred" to "ответ", "target" to "1", "save_to" to "ошибка")

                // Python Extensions: API & Net
                BlockType.API_GET_REQUEST -> mapOf("url" to "\"https://api.ipify.org?format=json\"", "var" to "ответ_сервера")
                BlockType.API_POST_JSON -> mapOf("url" to "\"https://httpbin.org/post\"", "data" to "{\"user\": \"Alex\"}", "var" to "ответ")
                BlockType.API_GET_MY_IP -> mapOf("var" to "мой_ip")
                BlockType.API_PARSE_FIELD -> mapOf("json_var" to "ответ_сервера", "field" to "\"ip\"", "save_to" to "ip_адрес")
                BlockType.API_STATUS_CODE -> mapOf("response" to "ответ_сервера")

                // Python Extensions: Random
                BlockType.RANDOM_INT_RANGE -> mapOf("from" to "1", "to" to "100", "var" to "случайное")
                BlockType.RANDOM_CHOICE_ITEM -> mapOf("list" to "числа", "var" to "выбор")
                BlockType.RANDOM_SHUFFLE_LIST -> mapOf("list" to "числа")
                BlockType.RANDOM_FLOAT_01 -> mapOf("var" to "дробь")

                // Python Extensions: OS & Sys
                BlockType.OS_LIST_FILES -> mapOf("path" to "\".\"", "var" to "файлы")
                BlockType.OS_FILE_EXISTS -> mapOf("path" to "\"заметка.txt\"")
                BlockType.OS_CREATE_FOLDER -> mapOf("path" to "\"новая_папка\"")
                BlockType.OS_GET_SYSTEM -> mapOf("var" to "система")
                BlockType.OS_EXIT_APP -> emptyMap()

                // Python Extensions: Time & Date
                BlockType.TIME_SLEEP_MS -> mapOf("ms" to "500")
                BlockType.TIME_CURRENT_TIMESTAMP -> mapOf("var" to "время_сек")
                BlockType.TIME_FORMATTED_DATE -> mapOf("format" to "\"%Y-%m-%d %H:%M\"", "var" to "дата")
                BlockType.TIME_BENCHMARK -> emptyMap()

                // Python Extensions: Math & Stats
                BlockType.MATH_SQRT -> mapOf("num" to "16", "var" to "корень")
                BlockType.MATH_POW -> mapOf("num" to "2", "power" to "8", "var" to "результат")
                BlockType.MATH_TRIG_SIN_COS -> mapOf("func" to "sin", "angle" to "3.1415 / 2", "var" to "синус")
                BlockType.MATH_CONSTANTS -> mapOf("const" to "pi", "var" to "число_пи")
                BlockType.STAT_MEAN_MEDIAN -> mapOf("stat" to "mean", "list" to "числа", "var" to "среднее")

                // Python Extensions: Graphics
                BlockType.TURTLE_FORWARD -> mapOf("steps" to "100")
                BlockType.TURTLE_TURN -> mapOf("dir" to "направо", "degrees" to "90")
                BlockType.TURTLE_PEN_UP_DOWN -> mapOf("state" to "опустить")
                BlockType.TURTLE_SET_COLOR -> mapOf("color" to "\"red\"")

                // Python Extensions: SQLite
                BlockType.SQLITE_CONNECT -> mapOf("db" to "\"app.db\"", "var" to "база")
                BlockType.SQLITE_EXECUTE -> mapOf("db" to "база", "sql" to "\"CREATE TABLE IF NOT EXISTS users (id INT, name TEXT)\"")
                BlockType.SQLITE_FETCH_ALL -> mapOf("db" to "база", "query" to "\"SELECT * FROM users\"", "var" to "строки")

                // Arduino LED
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> mapOf("pin" to "13")
                BlockType.ARDUINO_DIGITAL_WRITE_LOW -> mapOf("pin" to "13")
                BlockType.ARDUINO_BLINK_LED -> mapOf("pin" to "13", "delay_ms" to "1000")
                BlockType.ARDUINO_PWM_BRIGHTNESS -> mapOf("pin" to "9", "brightness" to "128")
                BlockType.ARDUINO_PIN_MODE -> mapOf("pin" to "13", "mode" to "OUTPUT")
                BlockType.ARDUINO_TOGGLE_PIN -> mapOf("pin" to "13")

                // Arduino Servo
                BlockType.ARDUINO_SERVO_ATTACH -> mapOf("servo" to "servo1", "pin" to "9")
                BlockType.ARDUINO_SERVO_WRITE -> mapOf("servo" to "servo1", "angle" to "90")
                BlockType.ARDUINO_SERVO_SWEEP -> mapOf("servo" to "servo1", "from" to "0", "to" to "180", "speed_ms" to "15")

                // Arduino Motors
                BlockType.ARDUINO_MOTOR_FORWARD -> mapOf("motor" to "M1", "speed" to "255")
                BlockType.ARDUINO_MOTOR_BACKWARD -> mapOf("motor" to "M1", "speed" to "255")
                BlockType.ARDUINO_MOTOR_STOP -> mapOf("motor" to "M1")
                BlockType.ARDUINO_L298N_DRIVER -> mapOf("in1" to "5", "in2" to "6", "speed" to "255")
                BlockType.ARDUINO_L298N_MOTOR_A -> mapOf("in1" to "5", "in2" to "6", "speed" to "255", "dir" to "Вперед")
                BlockType.ARDUINO_L298N_MOTOR_B -> mapOf("in3" to "7", "in4" to "8", "speed" to "255", "dir" to "Вперед")
                BlockType.ARDUINO_L298N_STOP_ALL -> emptyMap()
                BlockType.ARDUINO_L9110S_MOTOR -> mapOf("pin1" to "5", "pin2" to "6", "speed" to "200", "dir" to "Вперед")
                BlockType.ARDUINO_STEPPER_STEP -> mapOf("in1" to "8", "in2" to "9", "in3" to "10", "in4" to "11", "steps" to "500", "rpm" to "15")

                // Arduino Sensors
                BlockType.ARDUINO_DIGITAL_READ -> mapOf("pin" to "2", "var" to "кнопка")
                BlockType.ARDUINO_ANALOG_READ -> mapOf("pin" to "A0", "var" to "датчик")
                BlockType.ARDUINO_ULTRASONIC -> mapOf("trig" to "7", "echo" to "6", "var" to "дистанция")
                BlockType.ARDUINO_IF_BUTTON -> mapOf("pin" to "2")

                // Arduino Buzzer
                BlockType.ARDUINO_BUZZER_TONE -> mapOf("pin" to "8", "freq" to "440", "duration" to "500")
                BlockType.ARDUINO_BUZZER_NOTONE -> mapOf("pin" to "8")
                BlockType.ARDUINO_BUZZER_BEEP -> mapOf("pin" to "8")

                // Arduino Control
                BlockType.ARDUINO_DELAY_MS -> mapOf("ms" to "1000")
                BlockType.ARDUINO_DELAY_SEC -> mapOf("sec" to "1")
                BlockType.ARDUINO_IF_ELSE -> mapOf("condition" to "датчик > 500")
                BlockType.ARDUINO_REPEAT_TIMES -> mapOf("times" to "10", "var" to "i")
                BlockType.ARDUINO_LOOP_FOREVER -> emptyMap()
                BlockType.ARDUINO_VARIABLE_SET -> mapOf("var" to "яркость", "value" to "100")
                BlockType.ARDUINO_MAP_RANGE -> mapOf("var" to "результат", "input" to "датчик", "from_low" to "0", "from_high" to "1023", "to_low" to "0", "to_high" to "255")

                // Arduino Serial
                BlockType.ARDUINO_SERIAL_BEGIN -> mapOf("baud" to "9600")
                BlockType.ARDUINO_SERIAL_PRINTLN -> mapOf("text" to "\"Привет, Arduino!\"")
                BlockType.ARDUINO_SERIAL_PRINT_VAR -> mapOf("var" to "датчик")

                // Arduino Displays
                BlockType.ARDUINO_LCD_INIT -> mapOf("addr" to "0x27", "cols" to "16", "rows" to "2")
                BlockType.ARDUINO_LCD_CLEAR -> emptyMap()
                BlockType.ARDUINO_LCD_PRINT -> mapOf("text" to "\"Hello!\"", "col" to "0", "row" to "0")
                BlockType.ARDUINO_LCD_PRINT_VAR -> mapOf("var" to "датчик", "col" to "0", "row" to "1")
                BlockType.ARDUINO_LCD_BACKLIGHT -> mapOf("state" to "ВКЛ")
                BlockType.ARDUINO_OLED_INIT -> mapOf("width" to "128", "height" to "64", "addr" to "0x3C")
                BlockType.ARDUINO_OLED_CLEAR -> emptyMap()
                BlockType.ARDUINO_OLED_PRINT -> mapOf("text" to "\"OLED Text\"", "x" to "0", "y" to "0", "size" to "1")
                BlockType.ARDUINO_OLED_PRINT_VAR -> mapOf("var" to "датчик", "x" to "0", "y" to "16", "size" to "1")
                BlockType.ARDUINO_TM1637_INIT -> mapOf("clk" to "2", "dio" to "3")
                BlockType.ARDUINO_TM1637_NUMBER -> mapOf("num" to "1234")
                BlockType.ARDUINO_TM1637_CLEAR -> emptyMap()
            }
            return Block(type = type, fields = defaultFields)
        }

        fun getFieldDefinitions(type: BlockType): List<BlockField> {
            return when (type) {
                // Dialog
                BlockType.ASK_INPUT -> listOf(
                    BlockField("question", "Вопрос пользователю", "\"Как тебя зовут? \"", "текст вопроса в кавычках", acceptsBlock = true),
                    BlockField("var", "Имя переменной для ответа", "имя", "название переменной")
                )
                BlockType.ASK_NUMBER -> listOf(
                    BlockField("question", "Вопрос о числе", "\"Сколько тебе лет? \"", "текст вопроса", acceptsBlock = true),
                    BlockField("var", "Имя переменной для числа", "возраст", "название переменной")
                )
                BlockType.SAY -> listOf(
                    BlockField("text", "Что сказать (написать)", "\"Привет!\"", "текст в кавычках, число или переменная", acceptsBlock = true)
                )
                BlockType.SAY_PHRASE -> listOf(
                    BlockField("template", "Фраза с {переменными}", "Привет, {имя}! Тебе {возраст} лет.", "пиши переменные в фигурных скобках {x}")
                )
                BlockType.CLEAR_SCREEN -> emptyList()

                // Variables
                BlockType.SET_VARIABLE -> listOf(
                    BlockField("var", "Название переменной", "счет", "имя переменной"),
                    BlockField("value", "Какое значение сохранить", "10", "число, текст в кавычках или выражение", acceptsBlock = true)
                )
                BlockType.CHANGE_BY -> listOf(
                    BlockField("var", "Какую переменную изменить", "счет", "имя переменной"),
                    BlockField("value", "На сколько увеличить (или -1)", "1", "число или переменная", acceptsBlock = true)
                )
                BlockType.CALCULATE_INTO -> listOf(
                    BlockField("var", "Сохранить итог в", "итог", "имя переменной"),
                    BlockField("left", "Первое число / значение", "a", "число или переменная", acceptsBlock = true),
                    BlockField("op", "Действие (+, -, *, /)", "+", "+, -, *, /, //, %"),
                    BlockField("right", "Второе число / значение", "b", "число или переменная", acceptsBlock = true)
                )
                BlockType.CALCULATE_FORMULA_STRING -> listOf(
                    BlockField("formula", "Строка с математической формулой", "\"2 + 2 * 2\"", "любое выражение в кавычках или переменная"),
                    BlockField("var", "Сохранить результат в", "ответ", "имя переменной")
                )

                // Control
                BlockType.IF_SIMPLE -> listOf(
                    BlockField("condition", "Если верно, что", "счет > 0", "например: счет >= 10", acceptsBlock = true)
                )
                BlockType.IF_ELSE_SIMPLE -> listOf(
                    BlockField("condition", "Если верно, что", "счет > 0", "например: возраст >= 18", acceptsBlock = true)
                )
                BlockType.REPEAT_TIMES -> listOf(
                    BlockField("times", "Сколько раз повторить", "5", "число повторов", acceptsBlock = true),
                    BlockField("var", "Переменная счётчик", "i", "обычно i")
                )
                BlockType.WHILE_LOOP -> listOf(
                    BlockField("condition", "Повторять, пока верно", "счет > 0", "условие цикла", acceptsBlock = true)
                )
                BlockType.FOR_EACH_ITEM -> listOf(
                    BlockField("item", "Как назвать каждый элемент", "элемент", "имя переменной"),
                    BlockField("list", "Из какого списка перебирать", "список_дел", "имя списка", acceptsBlock = true)
                )
                BlockType.WAIT_SECONDS -> listOf(
                    BlockField("seconds", "Пауза в секундах", "1", "число секунд, например 1 или 0.5")
                )
                BlockType.STOP_LOOP, BlockType.NEXT_ROUND, BlockType.STOP_ALL -> emptyList()

                // Math Expressions
                BlockType.EXPR_RANDOM_NUM -> listOf(
                    BlockField("from", "От числа", "1", "начало диапазона", acceptsBlock = true),
                    BlockField("to", "До числа", "10", "конец диапазона", acceptsBlock = true)
                )
                BlockType.EXPR_ROUND -> listOf(
                    BlockField("number", "Число для округления", "3.14", "дробное число или переменная", acceptsBlock = true)
                )
                BlockType.EXPR_ABS -> listOf(
                    BlockField("number", "Число", "-5", "число", acceptsBlock = true)
                )
                BlockType.EXPR_MATH_OP -> listOf(
                    BlockField("left", "Левая часть", "5", "число/переменная", acceptsBlock = true),
                    BlockField("op", "Знак", "+", "+, -, *, /, //, %"),
                    BlockField("right", "Правая часть", "10", "число/переменная", acceptsBlock = true)
                )
                BlockType.EXPR_COMPARE_VALS -> listOf(
                    BlockField("left", "Левое значение", "ответ", "переменная или значение", acceptsBlock = true),
                    BlockField("op", "Сравнение", "==", "==, !=, <, >, <=, >="),
                    BlockField("right", "Правое значение", "\"да\"", "переменная или значение", acceptsBlock = true)
                )
                BlockType.EVAL_EXPRESSION -> listOf(
                    BlockField("expression", "Текст формулы для eval()", "\"10 * 5 + 3\"", "строка формулы")
                )

                // Text
                BlockType.TEXT_TO_UPPER -> listOf(
                    BlockField("var", "Из какой переменной взять", "текст", "переменная с текстом"),
                    BlockField("save_to", "Куда сохранить заглавными", "громкий_текст", "новая переменная")
                )
                BlockType.TEXT_TO_LOWER -> listOf(
                    BlockField("var", "Из какой переменной взять", "текст", "переменная с текстом"),
                    BlockField("save_to", "Куда сохранить строчными", "тихий_текст", "новая переменная")
                )
                BlockType.TEXT_REPLACE -> listOf(
                    BlockField("target", "В тексте", "текст", "имя переменной"),
                    BlockField("old", "Что заменить", "\"кот\"", "что ищем в кавычках"),
                    BlockField("new", "На что заменить", "\"пёс\"", "на что меняем в кавычках"),
                    BlockField("save_to", "Куда сохранить", "новый_текст", "имя переменной")
                )
                BlockType.EXPR_TEXT_CONTAINS -> listOf(
                    BlockField("word", "Искомое слово", "\"привет\"", "слово в кавычках", acceptsBlock = true),
                    BlockField("text", "Где искать (в тексте)", "текст", "переменная с текстом", acceptsBlock = true)
                )
                BlockType.EXPR_TEXT_LENGTH -> listOf(
                    BlockField("text", "Текст или переменная", "текст", "переменная с текстом", acceptsBlock = true)
                )

                // Lists
                BlockType.CREATE_LIST -> listOf(
                    BlockField("var", "Название списка", "числа", "имя списка"),
                    BlockField("items", "Элементы через запятую", "1, 2, 3, 4, 5", "значения через запятую")
                )
                BlockType.ADD_TO_LIST -> listOf(
                    BlockField("list", "В какой список добавить", "числа", "имя списка"),
                    BlockField("item", "Что добавить", "6", "значение или переменная", acceptsBlock = true)
                )
                BlockType.GET_FROM_LIST -> listOf(
                    BlockField("list", "Из списка", "числа", "имя списка"),
                    BlockField("index", "Номер элемента (с 0)", "0", "0 = первый элемент"),
                    BlockField("save_to", "Сохранить в переменную", "первый", "имя переменной")
                )
                BlockType.REMOVE_FROM_LIST -> listOf(
                    BlockField("list", "Из какого списка удалить", "числа", "имя списка"),
                    BlockField("item", "Какой элемент удалить", "6", "значение")
                )
                BlockType.REVERSE_LIST -> listOf(
                    BlockField("list", "Какой список перевернуть", "числа", "имя списка")
                )
                BlockType.EXPR_RANDOM_CHOICE -> listOf(
                    BlockField("list", "Из какого списка выбрать", "числа", "имя списка")
                )
                BlockType.EXPR_LIST_SIZE -> listOf(
                    BlockField("list", "Имя списка", "числа", "имя списка")
                )

                // Functions
                BlockType.CUSTOM_COMMAND_DEF -> listOf(
                    BlockField("name", "Название новой команды", "поздороваться", "назови команду без пробелов"),
                    BlockField("params", "Параметры (если нужны)", "имя", "параметры через запятую или пусто")
                )
                BlockType.CUSTOM_COMMAND_RUN -> listOf(
                    BlockField("call", "Команда для выполнения", "поздороваться(\"Алекс\")", "команда(параметры)")
                )
                BlockType.GIVE_RESULT -> listOf(
                    BlockField("value", "Какой ответ вернуть", "\"готово\"", "значение или переменная", acceptsBlock = true)
                )

                // Advanced
                BlockType.IMPORT_LIBRARY -> listOf(
                    BlockField("lib", "Код библиотеки", "neural_net", "id библиотеки"),
                    BlockField("name", "Название библиотеки", "🧠 Нейросети (torch)", "имя для отображения")
                )
                BlockType.ADD_NOTE -> listOf(
                    BlockField("text", "Текст заметки", "Здесь начинается главная логика", "пояснение к коду")
                )
                BlockType.TRY_DO -> emptyList()
                BlockType.WRITE_FILE -> listOf(
                    BlockField("file", "Имя файла", "\"заметка.txt\"", "имя файла в кавычках"),
                    BlockField("text", "Текст для записи", "\"Привет файл!\"", "текст или переменная", acceptsBlock = true)
                )
                BlockType.RAW_PY -> listOf(
                    BlockField("code", "Код Python", "print(\"Запуск Python кода\")", "любой код Python")
                )

                // Python Extensions: Neural Net
                BlockType.NN_CREATE_MODEL -> listOf(
                    BlockField("inputs", "Количество входов (нейронов)", "4", "число признаков"),
                    BlockField("hidden", "Скрытых нейронов", "16", "размер скрытого слоя"),
                    BlockField("outputs", "Количество выходов", "2", "число классов"),
                    BlockField("var", "Сохранить модель в", "нейросеть", "имя переменной")
                )
                BlockType.NN_TRAIN_EPOCHS -> listOf(
                    BlockField("model", "Модель нейросети", "нейросеть", "переменная модели"),
                    BlockField("epochs", "Число эпох обучения", "10", "например 10 или 50"),
                    BlockField("lr", "Скорость обучения (lr)", "0.01", "обычно 0.01 или 0.001")
                )
                BlockType.NN_PREDICT -> listOf(
                    BlockField("model", "Модель нейросети", "нейросеть", "переменная модели"),
                    BlockField("input", "Входные значения", "[0.5, 0.2, 0.9, 0.1]", "список чисел"),
                    BlockField("save_to", "Куда сохранить ответ", "ответ", "имя переменной")
                )
                BlockType.NN_ACTIVATION -> listOf(
                    BlockField("func", "Функция активации", "ReLU", "ReLU, Sigmoid, Softmax, Tanh"),
                    BlockField("input", "Входное значение", "x", "число или тензор")
                )
                BlockType.NN_CALC_LOSS -> listOf(
                    BlockField("pred", "Предсказание сети", "ответ", "выход модели"),
                    BlockField("target", "Ожидаемый ответ", "1", "истинная метка"),
                    BlockField("save_to", "Куда сохранить ошибку", "ошибка", "имя переменной")
                )

                // Python Extensions: API & Net
                BlockType.API_GET_REQUEST -> listOf(
                    BlockField("url", "Адрес интернет URL (GET)", "\"https://api.ipify.org?format=json\"", "ссылка на API"),
                    BlockField("var", "Сохранить ответ в", "ответ_сервера", "имя переменной")
                )
                BlockType.API_POST_JSON -> listOf(
                    BlockField("url", "Адрес интернет URL (POST)", "\"https://httpbin.org/post\"", "ссылка на API"),
                    BlockField("data", "JSON тело запроса", "{\"user\": \"Alex\"}", "строка JSON или словарь"),
                    BlockField("var", "Сохранить ответ в", "ответ", "имя переменной")
                )
                BlockType.API_GET_MY_IP -> listOf(
                    BlockField("var", "Куда сохранить свой IP", "мой_ip", "имя переменной")
                )
                BlockType.API_PARSE_FIELD -> listOf(
                    BlockField("json_var", "Из ответа переменной", "ответ_сервера", "переменная с JSON"),
                    BlockField("field", "Название поля", "\"ip\"", "ключ в JSON"),
                    BlockField("save_to", "Куда сохранить значение", "ip_адрес", "имя переменной")
                )
                BlockType.API_STATUS_CODE -> listOf(
                    BlockField("response", "Переменная ответа", "ответ_сервера", "переменная")
                )

                // Python Extensions: Random
                BlockType.RANDOM_INT_RANGE -> listOf(
                    BlockField("from", "От числа", "1", "начало"),
                    BlockField("to", "До числа", "100", "конец"),
                    BlockField("var", "Сохранить в переменную", "случайное", "имя переменной")
                )
                BlockType.RANDOM_CHOICE_ITEM -> listOf(
                    BlockField("list", "Из какого списка", "числа", "имя списка"),
                    BlockField("var", "Куда сохранить", "выбор", "имя переменной")
                )
                BlockType.RANDOM_SHUFFLE_LIST -> listOf(
                    BlockField("list", "Имя списка для перемешивания", "числа", "имя списка")
                )
                BlockType.RANDOM_FLOAT_01 -> listOf(
                    BlockField("var", "Куда сохранить дробь", "дробь", "имя переменной")
                )

                // Python Extensions: OS & Sys
                BlockType.OS_LIST_FILES -> listOf(
                    BlockField("path", "Путь к папке", "\".\"", "папка"),
                    BlockField("var", "Сохранить список файлов в", "файлы", "имя переменной")
                )
                BlockType.OS_FILE_EXISTS -> listOf(
                    BlockField("path", "Путь к файлу", "\"заметка.txt\"", "имя файла")
                )
                BlockType.OS_CREATE_FOLDER -> listOf(
                    BlockField("path", "Имя новой папки", "\"новая_папка\"", "путь")
                )
                BlockType.OS_GET_SYSTEM -> listOf(
                    BlockField("var", "Куда сохранить имя ОС", "система", "имя переменной")
                )
                BlockType.OS_EXIT_APP -> emptyList()

                // Python Extensions: Time & Date
                BlockType.TIME_SLEEP_MS -> listOf(
                    BlockField("ms", "Миллисекунды (мс)", "500", "500 = полсекунды")
                )
                BlockType.TIME_CURRENT_TIMESTAMP -> listOf(
                    BlockField("var", "Куда сохранить секунды", "время_сек", "имя переменной")
                )
                BlockType.TIME_FORMATTED_DATE -> listOf(
                    BlockField("format", "Формат даты", "\"%Y-%m-%d %H:%M\"", "формат"),
                    BlockField("var", "Куда сохранить дату", "дата", "имя переменной")
                )
                BlockType.TIME_BENCHMARK -> emptyList()

                // Python Extensions: Math & Stats
                BlockType.MATH_SQRT -> listOf(
                    BlockField("num", "Число для корня", "16", "число"),
                    BlockField("var", "Куда сохранить", "корень", "имя переменной")
                )
                BlockType.MATH_POW -> listOf(
                    BlockField("num", "Число (основание)", "2", "число"),
                    BlockField("power", "Степень", "8", "степень"),
                    BlockField("var", "Куда сохранить", "результат", "имя переменной")
                )
                BlockType.MATH_TRIG_SIN_COS -> listOf(
                    BlockField("func", "Тригонометрическая функция", "sin", "sin, cos, tan"),
                    BlockField("angle", "Угол в радианах", "3.1415 / 2", "радианы"),
                    BlockField("var", "Куда сохранить", "синус", "имя переменной")
                )
                BlockType.MATH_CONSTANTS -> listOf(
                    BlockField("const", "Какая константа (pi, e)", "pi", "pi или e"),
                    BlockField("var", "Куда сохранить", "число_пи", "имя переменной")
                )
                BlockType.STAT_MEAN_MEDIAN -> listOf(
                    BlockField("stat", "Что посчитать", "mean", "mean (среднее) или median (медиана)"),
                    BlockField("list", "Из списка", "числа", "имя списка"),
                    BlockField("var", "Куда сохранить", "среднее", "имя переменной")
                )

                // Python Extensions: Turtle Graphics
                BlockType.TURTLE_FORWARD -> listOf(
                    BlockField("steps", "Шагов вперед (пикселей)", "100", "длина шага")
                )
                BlockType.TURTLE_TURN -> listOf(
                    BlockField("dir", "Куда повернуть", "направо", "направо или налево"),
                    BlockField("degrees", "На сколько градусов (°)", "90", "угол")
                )
                BlockType.TURTLE_PEN_UP_DOWN -> listOf(
                    BlockField("state", "Состояние пера", "опустить", "опустить (рисовать) или поднять")
                )
                BlockType.TURTLE_SET_COLOR -> listOf(
                    BlockField("color", "Цвет пера", "\"red\"", "\"red\", \"blue\", \"green\"")
                )

                // Python Extensions: SQLite
                BlockType.SQLITE_CONNECT -> listOf(
                    BlockField("db", "Имя файла базы", "\"app.db\"", "имя файла"),
                    BlockField("var", "Сохранить подключение в", "база", "имя переменной")
                )
                BlockType.SQLITE_EXECUTE -> listOf(
                    BlockField("db", "Переменная базы", "база", "подключение"),
                    BlockField("sql", "SQL команда", "\"CREATE TABLE IF NOT EXISTS users (id INT, name TEXT)\"", "SQL код")
                )
                BlockType.SQLITE_FETCH_ALL -> listOf(
                    BlockField("db", "Переменная базы", "база", "подключение"),
                    BlockField("query", "SQL запрос", "\"SELECT * FROM users\"", "SQL запрос"),
                    BlockField("var", "Куда сохранить список строк", "строки", "имя переменной")
                )

                // Arduino LED
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> listOf(
                    BlockField("pin", "Номер пина лампочки (0-13)", "13", "13 (встроенный LED), 12, 11, ...")
                )
                BlockType.ARDUINO_DIGITAL_WRITE_LOW -> listOf(
                    BlockField("pin", "Номер пина лампочки (0-13)", "13", "13 (встроенный LED), 12, 11, ...")
                )
                BlockType.ARDUINO_BLINK_LED -> listOf(
                    BlockField("pin", "Номер пина светодиода", "13", "номер цифрового пина Uno"),
                    BlockField("delay_ms", "Пауза мигания (мс)", "1000", "1000 мс = 1 секунда")
                )
                BlockType.ARDUINO_PWM_BRIGHTNESS -> listOf(
                    BlockField("pin", "ШИМ-пин лампочки (~)", "9", "пины Uno с ШИМ (~): 3, 5, 6, 9, 10, 11"),
                    BlockField("brightness", "Яркость (0 - 255)", "128", "0 = выкл, 255 = макс")
                )
                BlockType.ARDUINO_PIN_MODE -> listOf(
                    BlockField("pin", "Номер пина Uno (0-13)", "13", "цифровой пин"),
                    BlockField("mode", "Режим работы", "OUTPUT", "OUTPUT (выход), INPUT (вход), INPUT_PULLUP")
                )
                BlockType.ARDUINO_TOGGLE_PIN -> listOf(
                    BlockField("pin", "Номер пина Uno (0-13)", "13", "номер пина для переключения")
                )

                // Arduino Servo
                BlockType.ARDUINO_SERVO_ATTACH -> listOf(
                    BlockField("servo", "Имя сервопривода", "servo1", "название объекта"),
                    BlockField("pin", "Пин серво (ШИМ ~)", "9", "пины 9, 10, 5, 6, 3, 11")
                )
                BlockType.ARDUINO_SERVO_WRITE -> listOf(
                    BlockField("servo", "Имя сервопривода", "servo1", "название объекта"),
                    BlockField("angle", "Угол поворота (0° - 180°)", "90", "угол от 0 до 180 градусов")
                )
                BlockType.ARDUINO_SERVO_SWEEP -> listOf(
                    BlockField("servo", "Имя сервопривода", "servo1", "название объекта"),
                    BlockField("from", "Начальный угол", "0", "0-180"),
                    BlockField("to", "Конечный угол", "180", "0-180"),
                    BlockField("speed_ms", "Задержка на шаг (мс)", "15", "чем меньше, тем быстрее")
                )

                // Arduino Motors & Drivers
                BlockType.ARDUINO_MOTOR_FORWARD -> listOf(
                    BlockField("motor", "Обозначение мотора", "M1", "имя мотора"),
                    BlockField("speed", "Скорость вращения (0-255)", "255", "0 = стоп, 255 = полная скорость")
                )
                BlockType.ARDUINO_MOTOR_BACKWARD -> listOf(
                    BlockField("motor", "Обозначение мотора", "M1", "имя мотора"),
                    BlockField("speed", "Скорость вращения (0-255)", "255", "0 = стоп, 255 = полная скорость")
                )
                BlockType.ARDUINO_MOTOR_STOP -> listOf(
                    BlockField("motor", "Обозначение мотора", "M1", "имя мотора")
                )
                BlockType.ARDUINO_L298N_DRIVER -> listOf(
                    BlockField("in1", "Пин IN1 (направление)", "5", "цифровой пин Uno"),
                    BlockField("in2", "Пин IN2 (направление)", "6", "цифровой пин Uno"),
                    BlockField("speed", "Скорость (ШИМ 0-255)", "255", "скорость вращения")
                )
                BlockType.ARDUINO_L298N_MOTOR_A -> listOf(
                    BlockField("in1", "Пин IN1 драйвера", "5", "цифровой пин Uno"),
                    BlockField("in2", "Пин IN2 драйвера", "6", "цифровой пин Uno"),
                    BlockField("speed", "Скорость (ШИМ 0-255)", "255", "0 = стоп, 255 = макс"),
                    BlockField("dir", "Направление вращения", "Вперед", "Вперед / Назад / Стоп")
                )
                BlockType.ARDUINO_L298N_MOTOR_B -> listOf(
                    BlockField("in3", "Пин IN3 драйвера", "7", "цифровой пин Uno"),
                    BlockField("in4", "Пин IN4 драйвера", "8", "цифровой пин Uno"),
                    BlockField("speed", "Скорость (ШИМ 0-255)", "255", "0 = стоп, 255 = макс"),
                    BlockField("dir", "Направление вращения", "Вперед", "Вперед / Назад / Стоп")
                )
                BlockType.ARDUINO_L298N_STOP_ALL -> emptyList()
                BlockType.ARDUINO_L9110S_MOTOR -> listOf(
                    BlockField("pin1", "Пин 1 (ШИМ ~)", "5", "пины 3, 5, 6, 9, 10, 11"),
                    BlockField("pin2", "Пин 2 (ШИМ ~)", "6", "пины 3, 5, 6, 9, 10, 11"),
                    BlockField("speed", "Скорость (0-255)", "200", "0-255"),
                    BlockField("dir", "Направление", "Вперед", "Вперед или Назад")
                )
                BlockType.ARDUINO_STEPPER_STEP -> listOf(
                    BlockField("in1", "Пин IN1", "8", "пин Uno"),
                    BlockField("in2", "Пин IN2", "9", "пин Uno"),
                    BlockField("in3", "Пин IN3", "10", "пин Uno"),
                    BlockField("in4", "Пин IN4", "11", "пин Uno"),
                    BlockField("steps", "Количество шагов", "500", "например 500 или -500"),
                    BlockField("rpm", "Скорость (об/мин)", "15", "оборотов в минуту")
                )

                // Arduino Sensors
                BlockType.ARDUINO_DIGITAL_READ -> listOf(
                    BlockField("pin", "Номер цифрового пина", "2", "пины 2-12 Uno"),
                    BlockField("var", "Сохранить сигнал в", "кнопка", "HIGH или LOW")
                )
                BlockType.ARDUINO_ANALOG_READ -> listOf(
                    BlockField("pin", "Аналоговый пин Uno", "A0", "A0, A1, A2, A3, A4, A5"),
                    BlockField("var", "Сохранить значение в", "датчик", "число от 0 до 1023")
                )
                BlockType.ARDUINO_ULTRASONIC -> listOf(
                    BlockField("trig", "Пин Trig (триггер)", "7", "цифровой пин"),
                    BlockField("echo", "Пин Echo (эхо)", "6", "цифровой пин"),
                    BlockField("var", "Сохранить расстояние в (см)", "дистанция", "имя переменной")
                )
                BlockType.ARDUINO_IF_BUTTON -> listOf(
                    BlockField("pin", "Пин кнопки Uno (0-13)", "2", "если на этом пине HIGH")
                )

                // Arduino Buzzer
                BlockType.ARDUINO_BUZZER_TONE -> listOf(
                    BlockField("pin", "Пин зуммера/динамика", "8", "цифровой пин Uno"),
                    BlockField("freq", "Частота звука (Гц)", "440", "например 440 (нота Ля), 1000"),
                    BlockField("duration", "Длительность (мс)", "500", "время звучания в мс")
                )
                BlockType.ARDUINO_BUZZER_NOTONE -> listOf(
                    BlockField("pin", "Пин зуммера", "8", "номер пина")
                )
                BlockType.ARDUINO_BUZZER_BEEP -> listOf(
                    BlockField("pin", "Пин зуммера", "8", "номер пина")
                )

                // Arduino Displays
                BlockType.ARDUINO_LCD_INIT -> listOf(
                    BlockField("addr", "I2C Адрес", "0x27", "0x27 или 0x3F"),
                    BlockField("cols", "Колонок", "16", "16"),
                    BlockField("rows", "Строк", "2", "2")
                )
                BlockType.ARDUINO_LCD_CLEAR -> emptyList()
                BlockType.ARDUINO_LCD_PRINT -> listOf(
                    BlockField("text", "Текст", "\"Hello World!\"", "текст для вывода"),
                    BlockField("col", "Колонка (0-15)", "0", "0-15"),
                    BlockField("row", "Строка (0-1)", "0", "0 или 1")
                )
                BlockType.ARDUINO_LCD_PRINT_VAR -> listOf(
                    BlockField("var", "Имя переменной", "датчик", "переменная"),
                    BlockField("col", "Колонка (0-15)", "0", "0-15"),
                    BlockField("row", "Строка (0-1)", "1", "0 или 1")
                )
                BlockType.ARDUINO_LCD_BACKLIGHT -> listOf(
                    BlockField("state", "Подсветка", "ВКЛ", "ВКЛ или ВЫКЛ")
                )
                BlockType.ARDUINO_OLED_INIT -> listOf(
                    BlockField("width", "Ширина", "128", "128"),
                    BlockField("height", "Высота", "64", "64"),
                    BlockField("addr", "I2C Адрес", "0x3C", "0x3C")
                )
                BlockType.ARDUINO_OLED_CLEAR -> emptyList()
                BlockType.ARDUINO_OLED_PRINT -> listOf(
                    BlockField("text", "Текст", "\"Arduino OLED\"", "сообщение"),
                    BlockField("x", "Координата X (0-127)", "0", "0-127"),
                    BlockField("y", "Координата Y (0-63)", "0", "0-63"),
                    BlockField("size", "Размер шрифта (1-3)", "1", "1, 2 или 3")
                )
                BlockType.ARDUINO_OLED_PRINT_VAR -> listOf(
                    BlockField("var", "Имя переменной", "датчик", "переменная"),
                    BlockField("x", "Координата X (0-127)", "0", "0-127"),
                    BlockField("y", "Координата Y (0-63)", "16", "0-63"),
                    BlockField("size", "Размер шрифта (1-3)", "1", "1, 2 или 3")
                )
                BlockType.ARDUINO_TM1637_INIT -> listOf(
                    BlockField("clk", "Пин CLK", "2", "цифровой пин"),
                    BlockField("dio", "Пин DIO", "3", "цифровой пин")
                )
                BlockType.ARDUINO_TM1637_NUMBER -> listOf(
                    BlockField("num", "Число", "1234", "число от 0 до 9999 или переменная")
                )
                BlockType.ARDUINO_TM1637_CLEAR -> emptyList()

                // Arduino Control
                BlockType.ARDUINO_DELAY_MS -> listOf(
                    BlockField("ms", "Миллисекунды (мс)", "1000", "1000 = 1 секунда, 500 = полсекунды")
                )
                BlockType.ARDUINO_DELAY_SEC -> listOf(
                    BlockField("sec", "Секунды", "1", "пауза в секундах")
                )
                BlockType.ARDUINO_IF_ELSE -> listOf(
                    BlockField("condition", "Условие", "датчик > 500", "например: датчик > 500 или кнопка == HIGH")
                )
                BlockType.ARDUINO_REPEAT_TIMES -> listOf(
                    BlockField("times", "Сколько раз повторить", "10", "число циклов"),
                    BlockField("var", "Переменная цикла", "i", "обычно i")
                )
                BlockType.ARDUINO_LOOP_FOREVER -> emptyList()
                BlockType.ARDUINO_VARIABLE_SET -> listOf(
                    BlockField("var", "Имя переменной", "яркость", "название переменной"),
                    BlockField("value", "Значение", "100", "число или формула")
                )
                BlockType.ARDUINO_MAP_RANGE -> listOf(
                    BlockField("var", "Куда сохранить", "результат", "имя переменной"),
                    BlockField("input", "Входная переменная", "датчик", "исходное значение"),
                    BlockField("from_low", "Мин вход", "0", "0"),
                    BlockField("from_high", "Макс вход", "1023", "1023"),
                    BlockField("to_low", "Мин выход", "0", "0"),
                    BlockField("to_high", "Макс выход", "255", "255")
                )

                // Arduino Serial
                BlockType.ARDUINO_SERIAL_BEGIN -> listOf(
                    BlockField("baud", "Скорость передачи (бод)", "9600", "9600 или 115200")
                )
                BlockType.ARDUINO_SERIAL_PRINTLN -> listOf(
                    BlockField("text", "Текст сообщения", "\"Привет, Arduino!\"", "текст в кавычках")
                )
                BlockType.ARDUINO_SERIAL_PRINT_VAR -> listOf(
                    BlockField("var", "Имя переменной", "датчик", "переменная со значением")
                )
            }
        }
    }
}
