package com.example.model

import java.util.UUID

enum class ProjectType {
    PYTHON,
    ARDUINO
}

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val blocks: List<Block>,
    val type: ProjectType = ProjectType.PYTHON,
    val updatedAt: Long = System.currentTimeMillis()
)

object SampleProjects {

    val all: List<Project> by lazy {
        listOf(
            createDefaultArduinoProject(),
            createArduinoDisplaysProject(),
            createDefaultPythonProject()
        )
    }

    fun createArduinoDisplaysProject(): Project {
        return Project(
            id = "project_arduino_displays",
            name = "Дисплеи LCD и OLED",
            description = "Демонстрация вывода информации на экраны LCD 1602, OLED SSD1306 и TM1637",
            type = ProjectType.ARDUINO,
            blocks = listOf(
                Block(
                    type = BlockType.ARDUINO_LCD_INIT,
                    fields = mapOf("addr" to "0x27", "cols" to "16", "rows" to "2")
                ),
                Block(
                    type = BlockType.ARDUINO_LCD_PRINT,
                    fields = mapOf("text" to "\"Hello Arduino!\"", "col" to "0", "row" to "0")
                ),
                Block(
                    type = BlockType.ARDUINO_OLED_INIT,
                    fields = mapOf("width" to "128", "height" to "64", "addr" to "0x3C")
                ),
                Block(
                    type = BlockType.ARDUINO_OLED_PRINT,
                    fields = mapOf("text" to "\"PyBlocks 2026\"", "x" to "0", "y" to "0", "size" to "1")
                ),
                Block(
                    type = BlockType.ARDUINO_TM1637_INIT,
                    fields = mapOf("clk" to "2", "dio" to "3")
                ),
                Block(
                    type = BlockType.ARDUINO_TM1637_NUMBER,
                    fields = mapOf("num" to "2026")
                ),
                Block(
                    type = BlockType.ARDUINO_ANALOG_READ,
                    fields = mapOf("pin" to "A0", "var" to "датчик")
                ),
                Block(
                    type = BlockType.ARDUINO_LCD_PRINT_VAR,
                    fields = mapOf("var" to "датчик", "col" to "0", "row" to "1")
                ),
                Block(
                    type = BlockType.ARDUINO_DELAY_MS,
                    fields = mapOf("ms" to "1000")
                )
            )
        )
    }

    fun createDefaultArduinoProject(): Project {
        return Project(
            id = "project_arduino_1",
            name = "Маяк и Сервопривод",
            description = "Управление светодиодом, сервоприводом и выводом в монитор порта",
            type = ProjectType.ARDUINO,
            blocks = listOf(
                Block(
                    type = BlockType.ARDUINO_SERIAL_BEGIN,
                    fields = mapOf("baud" to "9600")
                ),
                Block(
                    type = BlockType.ARDUINO_PIN_MODE,
                    fields = mapOf("pin" to "13", "mode" to "OUTPUT")
                ),
                Block(
                    type = BlockType.ARDUINO_SERVO_ATTACH,
                    fields = mapOf("servo" to "servo1", "pin" to "9")
                ),
                Block(
                    type = BlockType.ARDUINO_DIGITAL_WRITE_HIGH,
                    fields = mapOf("pin" to "13")
                ),
                Block(
                    type = BlockType.ARDUINO_SERVO_WRITE,
                    fields = mapOf("servo" to "servo1", "angle" to "90")
                ),
                Block(
                    type = BlockType.ARDUINO_SERIAL_PRINTLN,
                    fields = mapOf("text" to "\"Светодиод ВКЛ, сервопривод 90°\"")
                ),
                Block(
                    type = BlockType.ARDUINO_DELAY_MS,
                    fields = mapOf("ms" to "1000")
                ),
                Block(
                    type = BlockType.ARDUINO_DIGITAL_WRITE_LOW,
                    fields = mapOf("pin" to "13")
                ),
                Block(
                    type = BlockType.ARDUINO_SERVO_WRITE,
                    fields = mapOf("servo" to "servo1", "angle" to "0")
                ),
                Block(
                    type = BlockType.ARDUINO_SERIAL_PRINTLN,
                    fields = mapOf("text" to "\"Светодиод ВЫКЛ, сервопривод 0°\"")
                ),
                Block(
                    type = BlockType.ARDUINO_DELAY_MS,
                    fields = mapOf("ms" to "1000")
                )
            )
        )
    }

    fun createDefaultPythonProject(): Project {
        return Project(
            id = "project_python_1",
            name = "Знакомство с Python",
            description = "Простой интерактивный диалог с вопросами и ответами",
            type = ProjectType.PYTHON,
            blocks = listOf(
                Block(
                    type = BlockType.ASK_INPUT,
                    fields = mapOf("question" to "\"Как тебя зовут? \"", "var" to "имя")
                ),
                Block(
                    type = BlockType.SAY_PHRASE,
                    fields = mapOf("template" to "Рад познакомиться, {имя}!")
                ),
                Block(
                    type = BlockType.ASK_NUMBER,
                    fields = mapOf("question" to "\"Сколько тебе лет? \"", "var" to "возраст")
                ),
                Block(
                    type = BlockType.IF_ELSE_SIMPLE,
                    fields = mapOf("condition" to "возраст >= 18"),
                    children = listOf(
                        Block(
                            type = BlockType.SAY,
                            fields = mapOf("text" to "\"Ты уже взрослый! Впереди много крутых проектов.\"")
                        )
                    ),
                    secondaryChildren = listOf(
                        Block(
                            type = BlockType.SAY,
                            fields = mapOf("text" to "\"Отличный возраст, чтобы учиться программировать играючи!\"")
                        )
                    )
                )
            )
        )
    }

    fun createEmptyProject(type: ProjectType = ProjectType.PYTHON, name: String? = null): Project {
        val defaultName = if (type == ProjectType.ARDUINO) {
            name ?: ("Проект Arduino " + (System.currentTimeMillis() % 1000))
        } else {
            name ?: ("Проект Python " + (System.currentTimeMillis() % 1000))
        }
        val desc = if (type == ProjectType.ARDUINO) {
            "Проект для платы Arduino с блоками управления"
        } else {
            "Проект со скриптами Python"
        }
        return Project(
            id = UUID.randomUUID().toString(),
            name = defaultName,
            description = desc,
            type = type,
            blocks = if (type == ProjectType.ARDUINO) {
                listOf(
                    Block(
                        type = BlockType.ARDUINO_PIN_MODE,
                        fields = mapOf("pin" to "13", "mode" to "OUTPUT")
                    ),
                    Block(
                        type = BlockType.ARDUINO_BLINK_LED,
                        fields = mapOf("pin" to "13", "delay_ms" to "1000")
                    )
                )
            } else {
                emptyList()
            }
        )
    }
}
