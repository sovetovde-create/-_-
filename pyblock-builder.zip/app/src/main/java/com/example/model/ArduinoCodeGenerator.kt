package com.example.model

object ArduinoCodeGenerator {

    data class Analysis(
        val usesServo: Boolean,
        val servoNames: Set<String>,
        val usesUltrasonic: Boolean,
        val usesStepper: Boolean,
        val usesLcd: Boolean,
        val usesOled: Boolean,
        val usesTm1637: Boolean,
        val tm1637Pins: Pair<String, String>?,
        val outputPins: Set<String>,
        val inputPins: Set<String>,
        val baudRate: String?
    )

    /**
     * Translates Russian/arbitrary user variable names into safe ASCII C++ identifiers
     * so that gcc/Arduino IDE will compile without "stray '\321' in program" errors.
     */
    fun toSafeCppIdentifier(name: String): String {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return "var_x"
        // If already pure ASCII alphanumeric + underscore, keep it
        if (trimmed.matches(Regex("^[a-zA-Z_][a-zA-Z0-9_]*$"))) {
            return trimmed
        }
        // Map common Russian words
        val map = mapOf(
            "счет" to "counter",
            "число" to "num",
            "датчик" to "sensorVal",
            "кнопка" to "buttonState",
            "яркость" to "brightness",
            "дистанция" to "distanceCm",
            "расстояние" to "distanceCm",
            "ответ" to "result",
            "скорость" to "speedVal",
            "угол" to "servoAngle",
            "светодиод" to "ledState",
            "результат" to "mappedVal"
        )
        map[trimmed.lowercase()]?.let { return it }

        // General transliteration
        val cyr = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
        val lat = listOf(
            "a","b","v","g","d","e","yo","zh","z","i","y","k","l","m","n","o","p","r","s","t","u","f","kh","ts","ch","sh","shch","","y","","e","yu","ya"
        )
        val sb = StringBuilder("var_")
        for (ch in trimmed.lowercase()) {
            val idx = cyr.indexOf(ch)
            if (idx >= 0) {
                sb.append(lat[idx])
            } else if (ch.isLetterOrDigit() || ch == '_') {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun analyzeBlocks(blocks: List<Block>): Analysis {
        val servoNames = mutableSetOf<String>()
        var usesUltrasonic = false
        var usesStepper = false
        var usesLcd = false
        var usesOled = false
        var usesTm1637 = false
        var tm1637Pins: Pair<String, String>? = null
        val outputPins = mutableSetOf<String>()
        val inputPins = mutableSetOf<String>()
        var baudRate: String? = null

        fun traverse(b: Block) {
            when (b.type) {
                BlockType.ARDUINO_SERVO_ATTACH -> {
                    servoNames.add(b.getField("servo", "servo1"))
                    val p = b.getField("pin", "9")
                    outputPins.add(p)
                }
                BlockType.ARDUINO_SERVO_WRITE, BlockType.ARDUINO_SERVO_SWEEP -> {
                    servoNames.add(b.getField("servo", "servo1"))
                }
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH, BlockType.ARDUINO_DIGITAL_WRITE_LOW,
                BlockType.ARDUINO_BLINK_LED, BlockType.ARDUINO_PWM_BRIGHTNESS,
                BlockType.ARDUINO_TOGGLE_PIN -> {
                    val p = b.getField("pin", "13")
                    outputPins.add(p)
                }
                BlockType.ARDUINO_PIN_MODE -> {
                    val p = b.getField("pin", "13")
                    val mode = b.getField("mode", "OUTPUT")
                    if (mode.contains("INPUT")) inputPins.add(p) else outputPins.add(p)
                }
                BlockType.ARDUINO_MOTOR_FORWARD, BlockType.ARDUINO_MOTOR_BACKWARD, BlockType.ARDUINO_MOTOR_STOP -> {
                    outputPins.add("5")
                    outputPins.add("6")
                    outputPins.add("9")
                }
                BlockType.ARDUINO_L298N_DRIVER -> {
                    outputPins.add(b.getField("in1", "5"))
                    outputPins.add(b.getField("in2", "6"))
                }
                BlockType.ARDUINO_L298N_MOTOR_A -> {
                    outputPins.add(b.getField("in1", "5"))
                    outputPins.add(b.getField("in2", "6"))
                }
                BlockType.ARDUINO_L298N_MOTOR_B -> {
                    outputPins.add(b.getField("in3", "7"))
                    outputPins.add(b.getField("in4", "8"))
                }
                BlockType.ARDUINO_L9110S_MOTOR -> {
                    outputPins.add(b.getField("pin1", "5"))
                    outputPins.add(b.getField("pin2", "6"))
                }
                BlockType.ARDUINO_STEPPER_STEP -> {
                    usesStepper = true
                    outputPins.add(b.getField("in1", "8"))
                    outputPins.add(b.getField("in2", "9"))
                    outputPins.add(b.getField("in3", "10"))
                    outputPins.add(b.getField("in4", "11"))
                }
                BlockType.ARDUINO_BUZZER_TONE, BlockType.ARDUINO_BUZZER_NOTONE, BlockType.ARDUINO_BUZZER_BEEP -> {
                    outputPins.add(b.getField("pin", "8"))
                }
                BlockType.ARDUINO_DIGITAL_READ, BlockType.ARDUINO_IF_BUTTON -> {
                    inputPins.add(b.getField("pin", "2"))
                }
                BlockType.ARDUINO_ULTRASONIC -> {
                    usesUltrasonic = true
                    outputPins.add(b.getField("trig", "7"))
                    inputPins.add(b.getField("echo", "6"))
                }
                BlockType.ARDUINO_SERIAL_BEGIN -> {
                    baudRate = b.getField("baud", "9600")
                }
                BlockType.ARDUINO_SERIAL_PRINTLN, BlockType.ARDUINO_SERIAL_PRINT_VAR -> {
                    if (baudRate == null) baudRate = "9600"
                }
                BlockType.ARDUINO_LCD_INIT, BlockType.ARDUINO_LCD_CLEAR, BlockType.ARDUINO_LCD_PRINT,
                BlockType.ARDUINO_LCD_PRINT_VAR, BlockType.ARDUINO_LCD_BACKLIGHT -> {
                    usesLcd = true
                }
                BlockType.ARDUINO_OLED_INIT, BlockType.ARDUINO_OLED_CLEAR, BlockType.ARDUINO_OLED_PRINT,
                BlockType.ARDUINO_OLED_PRINT_VAR -> {
                    usesOled = true
                }
                BlockType.ARDUINO_TM1637_INIT, BlockType.ARDUINO_TM1637_NUMBER, BlockType.ARDUINO_TM1637_CLEAR -> {
                    usesTm1637 = true
                    if (b.type == BlockType.ARDUINO_TM1637_INIT) {
                        tm1637Pins = Pair(b.getField("clk", "2"), b.getField("dio", "3"))
                    } else if (tm1637Pins == null) {
                        tm1637Pins = Pair("2", "3")
                    }
                }
                else -> {}
            }
            b.children.forEach { traverse(it) }
            b.secondaryChildren.forEach { traverse(it) }
        }

        blocks.forEach { traverse(it) }

        return Analysis(
            usesServo = servoNames.isNotEmpty(),
            servoNames = servoNames,
            usesUltrasonic = usesUltrasonic,
            usesStepper = usesStepper,
            usesLcd = usesLcd,
            usesOled = usesOled,
            usesTm1637 = usesTm1637,
            tm1637Pins = tm1637Pins,
            outputPins = outputPins,
            inputPins = inputPins,
            baudRate = baudRate
        )
    }

    fun generateArduinoIno(blocks: List<Block>): String {
        val analysis = analyzeBlocks(blocks)
        val sb = StringBuilder()

        sb.append("// ==================================================\n")
        sb.append("// Скетч для платы Arduino Uno (ATmega328P)\n")
        sb.append("// Создано визуальными блоками в PyBlocks\n")
        sb.append("// Поддерживает: ШИМ (~3,~5,~6,~9,~10,~11), Серво, L298N, L9110S, Датчики\n")
        sb.append("// ==================================================\n\n")

        if (analysis.usesServo) {
            sb.append("#include <Servo.h>\n")
            analysis.servoNames.forEach { name ->
                val safeName = toSafeCppIdentifier(name)
                sb.append("Servo $safeName;\n")
            }
            sb.append("\n")
        }

        if (analysis.usesStepper) {
            sb.append("#include <Stepper.h>\n")
            sb.append("const int stepsPerRevolution = 2048; // Для мотора 28BYJ-48 с редуктором\n")
            sb.append("Stepper myStepper(stepsPerRevolution, 8, 10, 9, 11);\n\n")
        }

        if (analysis.usesLcd) {
            sb.append("// LCD 1602 I2C дисплей\n")
            sb.append("#include <Wire.h>\n")
            sb.append("#include <LiquidCrystal_I2C.h>\n")
            sb.append("LiquidCrystal_I2C lcd(0x27, 16, 2);\n\n")
        }

        if (analysis.usesOled) {
            sb.append("// OLED SSD1306 дисплей\n")
            sb.append("#include <Wire.h>\n")
            sb.append("#include <Adafruit_GFX.h>\n")
            sb.append("#include <Adafruit_SSD1306.h>\n")
            sb.append("Adafruit_SSD1306 oled(128, 64, &Wire, -1);\n\n")
        }

        if (analysis.usesTm1637) {
            sb.append("// 7-сегментный индикатор TM1637\n")
            sb.append("#include <TM1637Display.h>\n")
            val clk = analysis.tm1637Pins?.first ?: "2"
            val dio = analysis.tm1637Pins?.second ?: "3"
            sb.append("TM1637Display tm1637($clk, $dio);\n\n")
        }

        // Ultrasonic helper function if needed
        if (analysis.usesUltrasonic) {
            sb.append("// Измерение расстояния датчиком HC-SR04 в сантиметрах\n")
            sb.append("long readUltrasonicDistance(int trigPin, int echoPin) {\n")
            sb.append("  digitalWrite(trigPin, LOW);\n")
            sb.append("  delayMicroseconds(2);\n")
            sb.append("  digitalWrite(trigPin, HIGH);\n")
            sb.append("  delayMicroseconds(10);\n")
            sb.append("  digitalWrite(trigPin, LOW);\n")
            sb.append("  long duration = pulseIn(echoPin, HIGH, 25000L); // таймаут 25 мс (~4 метра)\n")
            sb.append("  if (duration == 0) return -1;\n")
            sb.append("  return (duration * 0.0343) / 2;\n")
            sb.append("}\n\n")
        }

        // Global variables declaration
        val declaredVars = mutableMapOf<String, String>() // raw -> safe
        fun findVars(b: Block) {
            when (b.type) {
                BlockType.ARDUINO_VARIABLE_SET, BlockType.ARDUINO_MAP_RANGE,
                BlockType.ARDUINO_DIGITAL_READ, BlockType.ARDUINO_ANALOG_READ,
                BlockType.ARDUINO_ULTRASONIC -> {
                    val raw = b.getField("var", "")
                    if (raw.isNotBlank()) {
                        declaredVars[raw] = toSafeCppIdentifier(raw)
                    }
                }
                else -> {}
            }
            b.children.forEach { findVars(it) }
            b.secondaryChildren.forEach { findVars(it) }
        }
        blocks.forEach { findVars(it) }

        if (declaredVars.isNotEmpty()) {
            sb.append("// Глобальные переменные:\n")
            declaredVars.forEach { (raw, safe) ->
                sb.append("long $safe = 0; // $raw\n")
            }
            sb.append("\n")
        }

        // void setup()
        sb.append("void setup() {\n")
        if (analysis.baudRate != null) {
            sb.append("  Serial.begin(${analysis.baudRate}); // Связь с ПК\n")
        }

        // Setup pins
        analysis.outputPins.forEach { p ->
            if (p.isNotBlank()) sb.append("  pinMode($p, OUTPUT); // Пин $p на выход\n")
        }
        analysis.inputPins.forEach { p ->
            if (p.isNotBlank() && !p.startsWith("A")) sb.append("  pinMode($p, INPUT); // Пин $p на вход\n")
        }

        // Attach servos from blocks that specifically define attach
        blocks.filter { it.type == BlockType.ARDUINO_SERVO_ATTACH }.forEach { b ->
            val sName = toSafeCppIdentifier(b.getField("servo", "servo1"))
            val pin = b.getField("pin", "9")
            sb.append("  $sName.attach($pin); // Подключение сервопривода к пину $pin\n")
        }

        val setupOnlyTypes = setOf(
            BlockType.ARDUINO_SERIAL_BEGIN,
            BlockType.ARDUINO_PIN_MODE,
            BlockType.ARDUINO_SERVO_ATTACH
        )
        val initialSetupBlocks = blocks.filter { it.type in setupOnlyTypes }
        if (analysis.usesServo && initialSetupBlocks.isEmpty()) {
            analysis.servoNames.forEach { sName ->
                val safeName = toSafeCppIdentifier(sName)
                sb.append("  $safeName.attach(9);\n")
            }
        }

        if (analysis.usesLcd) {
            sb.append("  lcd.init();\n")
            sb.append("  lcd.backlight();\n")
        }
        if (analysis.usesOled) {
            sb.append("  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);\n")
            sb.append("  oled.clearDisplay();\n")
            sb.append("  oled.setTextColor(SSD1306_WHITE);\n")
        }
        if (analysis.usesTm1637) {
            sb.append("  tm1637.setBrightness(0x0f);\n")
            sb.append("  tm1637.clear();\n")
        }

        sb.append("}\n\n")

        // void loop()
        sb.append("void loop() {\n")
        val loopBlocks = blocks.filterNot { it.type in setupOnlyTypes }

        if (loopBlocks.isEmpty()) {
            sb.append("  // Добавьте блоки действий в визуальном редакторе PyBlocks\n")
        } else {
            sb.append(generateBlockCode(loopBlocks, indentLevel = 1))
        }

        sb.append("}\n")

        return sb.toString()
    }

    private fun generateBlockCode(blocks: List<Block>, indentLevel: Int): String {
        val sb = StringBuilder()
        val indent = "  ".repeat(indentLevel)

        for (block in blocks) {
            when (block.type) {
                // LED & Digital
                BlockType.ARDUINO_DIGITAL_WRITE_HIGH -> {
                    val p = block.getField("pin", "13")
                    sb.append("${indent}digitalWrite($p, HIGH); // Включить пин $p\n")
                }
                BlockType.ARDUINO_DIGITAL_WRITE_LOW -> {
                    val p = block.getField("pin", "13")
                    sb.append("${indent}digitalWrite($p, LOW); // Выключить пин $p\n")
                }
                BlockType.ARDUINO_BLINK_LED -> {
                    val p = block.getField("pin", "13")
                    val ms = block.getField("delay_ms", "1000")
                    sb.append("${indent}digitalWrite($p, HIGH);\n")
                    sb.append("${indent}delay($ms);\n")
                    sb.append("${indent}digitalWrite($p, LOW);\n")
                    sb.append("${indent}delay($ms);\n")
                }
                BlockType.ARDUINO_PWM_BRIGHTNESS -> {
                    val p = block.getField("pin", "9")
                    val valPwm = block.getField("brightness", "128")
                    sb.append("${indent}analogWrite($p, $valPwm); // ШИМ яркость $valPwm на пине $p\n")
                }
                BlockType.ARDUINO_TOGGLE_PIN -> {
                    val p = block.getField("pin", "13")
                    sb.append("${indent}digitalWrite($p, !digitalRead($p)); // Переключить пин $p\n")
                }

                // Servo
                BlockType.ARDUINO_SERVO_ATTACH -> {
                    val s = toSafeCppIdentifier(block.getField("servo", "servo1"))
                    val p = block.getField("pin", "9")
                    sb.append("${indent}$s.attach($p);\n")
                }
                BlockType.ARDUINO_SERVO_WRITE -> {
                    val s = toSafeCppIdentifier(block.getField("servo", "servo1"))
                    val angle = block.getField("angle", "90")
                    sb.append("${indent}$s.write($angle); // Поворот серво $s на угол $angle°\n")
                }
                BlockType.ARDUINO_SERVO_SWEEP -> {
                    val s = toSafeCppIdentifier(block.getField("servo", "servo1"))
                    val from = block.getField("from", "0")
                    val to = block.getField("to", "180")
                    val spd = block.getField("speed_ms", "15")
                    sb.append("${indent}for (int pos = $from; pos <= $to; pos += 1) {\n")
                    sb.append("${indent}  $s.write(pos);\n")
                    sb.append("${indent}  delay($spd);\n")
                    sb.append("${indent}}\n")
                }

                // Motors & Drivers
                BlockType.ARDUINO_MOTOR_FORWARD -> {
                    val spd = block.getField("speed", "255")
                    sb.append("${indent}// Мотор вперед со скоростью $spd:\n")
                    sb.append("${indent}digitalWrite(5, HIGH);\n")
                    sb.append("${indent}digitalWrite(6, LOW);\n")
                    sb.append("${indent}analogWrite(9, $spd);\n")
                }
                BlockType.ARDUINO_MOTOR_BACKWARD -> {
                    val spd = block.getField("speed", "255")
                    sb.append("${indent}// Мотор назад со скоростью $spd:\n")
                    sb.append("${indent}digitalWrite(5, LOW);\n")
                    sb.append("${indent}digitalWrite(6, HIGH);\n")
                    sb.append("${indent}analogWrite(9, $spd);\n")
                }
                BlockType.ARDUINO_MOTOR_STOP -> {
                    sb.append("${indent}// Остановка мотора:\n")
                    sb.append("${indent}digitalWrite(5, LOW);\n")
                    sb.append("${indent}digitalWrite(6, LOW);\n")
                    sb.append("${indent}analogWrite(9, 0);\n")
                }
                BlockType.ARDUINO_L298N_DRIVER -> {
                    val in1 = block.getField("in1", "5")
                    val in2 = block.getField("in2", "6")
                    val spd = block.getField("speed", "255")
                    sb.append("${indent}// Драйвер L298N:\n")
                    sb.append("${indent}analogWrite($in1, $spd);\n")
                    sb.append("${indent}digitalWrite($in2, LOW);\n")
                }
                BlockType.ARDUINO_L298N_MOTOR_A -> {
                    val in1 = block.getField("in1", "5")
                    val in2 = block.getField("in2", "6")
                    val spd = block.getField("speed", "255")
                    val dir = block.getField("dir", "Вперед")
                    sb.append("${indent}// Драйвер L298N Мотор A ($dir, скорость $spd):\n")
                    if (dir.contains("Наз", ignoreCase = true)) {
                        sb.append("${indent}digitalWrite($in1, LOW);\n")
                        sb.append("${indent}analogWrite($in2, $spd);\n")
                    } else if (dir.contains("Стоп", ignoreCase = true)) {
                        sb.append("${indent}digitalWrite($in1, LOW);\n")
                        sb.append("${indent}digitalWrite($in2, LOW);\n")
                    } else {
                        sb.append("${indent}analogWrite($in1, $spd);\n")
                        sb.append("${indent}digitalWrite($in2, LOW);\n")
                    }
                }
                BlockType.ARDUINO_L298N_MOTOR_B -> {
                    val in3 = block.getField("in3", "7")
                    val in4 = block.getField("in4", "8")
                    val spd = block.getField("speed", "255")
                    val dir = block.getField("dir", "Вперед")
                    sb.append("${indent}// Драйвер L298N Мотор B ($dir, скорость $spd):\n")
                    if (dir.contains("Наз", ignoreCase = true)) {
                        sb.append("${indent}digitalWrite($in3, LOW);\n")
                        sb.append("${indent}analogWrite($in4, $spd);\n")
                    } else if (dir.contains("Стоп", ignoreCase = true)) {
                        sb.append("${indent}digitalWrite($in3, LOW);\n")
                        sb.append("${indent}digitalWrite($in4, LOW);\n")
                    } else {
                        sb.append("${indent}analogWrite($in3, $spd);\n")
                        sb.append("${indent}digitalWrite($in4, LOW);\n")
                    }
                }
                BlockType.ARDUINO_L298N_STOP_ALL -> {
                    sb.append("${indent}// Драйвер L298N: Полная остановка всех моторов\n")
                    sb.append("${indent}digitalWrite(5, LOW);\n")
                    sb.append("${indent}digitalWrite(6, LOW);\n")
                    sb.append("${indent}digitalWrite(7, LOW);\n")
                    sb.append("${indent}digitalWrite(8, LOW);\n")
                }
                BlockType.ARDUINO_L9110S_MOTOR -> {
                    val p1 = block.getField("pin1", "5")
                    val p2 = block.getField("pin2", "6")
                    val spd = block.getField("speed", "200")
                    val dir = block.getField("dir", "Вперед")
                    sb.append("${indent}// Драйвер L9110S ($dir, скорость $spd):\n")
                    if (dir.contains("Наз", ignoreCase = true)) {
                        sb.append("${indent}digitalWrite($p1, LOW);\n")
                        sb.append("${indent}analogWrite($p2, $spd);\n")
                    } else {
                        sb.append("${indent}analogWrite($p1, $spd);\n")
                        sb.append("${indent}digitalWrite($p2, LOW);\n")
                    }
                }
                BlockType.ARDUINO_STEPPER_STEP -> {
                    val steps = block.getField("steps", "500")
                    val rpm = block.getField("rpm", "15")
                    sb.append("${indent}// Шаговый двигатель 28BYJ-48:\n")
                    sb.append("${indent}myStepper.setSpeed($rpm);\n")
                    sb.append("${indent}myStepper.step($steps);\n")
                }

                // Sensors
                BlockType.ARDUINO_DIGITAL_READ -> {
                    val p = block.getField("pin", "2")
                    val rawV = block.getField("var", "кнопка")
                    val v = toSafeCppIdentifier(rawV)
                    sb.append("${indent}$v = digitalRead($p); // Считать пин $p ($rawV)\n")
                }
                BlockType.ARDUINO_ANALOG_READ -> {
                    val p = block.getField("pin", "A0")
                    val rawV = block.getField("var", "датчик")
                    val v = toSafeCppIdentifier(rawV)
                    sb.append("${indent}$v = analogRead($p); // Считать датчик $p (0-1023)\n")
                }
                BlockType.ARDUINO_ULTRASONIC -> {
                    val trig = block.getField("trig", "7")
                    val echo = block.getField("echo", "6")
                    val rawV = block.getField("var", "дистанция")
                    val v = toSafeCppIdentifier(rawV)
                    sb.append("${indent}$v = readUltrasonicDistance($trig, $echo);\n")
                }
                BlockType.ARDUINO_IF_BUTTON -> {
                    val p = block.getField("pin", "2")
                    sb.append("${indent}if (digitalRead($p) == HIGH) {\n")
                    sb.append(generateBlockCode(block.children, indentLevel + 1))
                    sb.append("${indent}}\n")
                }

                // Buzzer
                BlockType.ARDUINO_BUZZER_TONE -> {
                    val p = block.getField("pin", "8")
                    val f = block.getField("freq", "440")
                    val d = block.getField("duration", "500")
                    sb.append("${indent}tone($p, $f, $d); // Звук $f Гц на пине $p\n")
                }
                BlockType.ARDUINO_BUZZER_NOTONE -> {
                    val p = block.getField("pin", "8")
                    sb.append("${indent}noTone($p); // Выключить звук на пине $p\n")
                }
                BlockType.ARDUINO_BUZZER_BEEP -> {
                    val p = block.getField("pin", "8")
                    sb.append("${indent}tone($p, 1000, 150); // Короткий звуковой сигнал\n")
                    sb.append("${indent}delay(150);\n")
                }

                // Control & Timing
                BlockType.ARDUINO_DELAY_MS -> {
                    val ms = block.getField("ms", "1000")
                    sb.append("${indent}delay($ms); // Пауза $ms мс\n")
                }
                BlockType.ARDUINO_DELAY_SEC -> {
                    val sec = block.getField("sec", "1")
                    sb.append("${indent}delay(($sec) * 1000L); // Пауза $sec сек\n")
                }
                BlockType.ARDUINO_IF_ELSE -> {
                    val rawCond = block.getField("condition", "true")
                    val cond = rawCond
                        .replace("датчик", "sensorVal")
                        .replace("кнопка", "buttonState")
                        .replace("дистанция", "distanceCm")
                    sb.append("${indent}if ($cond) {\n")
                    sb.append(generateBlockCode(block.children, indentLevel + 1))
                    if (block.secondaryChildren.isNotEmpty()) {
                        sb.append("${indent}} else {\n")
                        sb.append(generateBlockCode(block.secondaryChildren, indentLevel + 1))
                    }
                    sb.append("${indent}}\n")
                }
                BlockType.ARDUINO_REPEAT_TIMES -> {
                    val times = block.getField("times", "10")
                    val rawV = block.getField("var", "i")
                    val v = toSafeCppIdentifier(rawV)
                    sb.append("${indent}for (int $v = 0; $v < $times; $v++) {\n")
                    sb.append(generateBlockCode(block.children, indentLevel + 1))
                    sb.append("${indent}}\n")
                }
                BlockType.ARDUINO_LOOP_FOREVER -> {
                    sb.append("${indent}while (true) {\n")
                    sb.append(generateBlockCode(block.children, indentLevel + 1))
                    sb.append("${indent}}\n")
                }
                BlockType.ARDUINO_VARIABLE_SET -> {
                    val rawV = block.getField("var", "x")
                    val v = toSafeCppIdentifier(rawV)
                    val valStr = block.getField("value", "0")
                    sb.append("${indent}$v = $valStr;\n")
                }
                BlockType.ARDUINO_MAP_RANGE -> {
                    val rawV = block.getField("var", "результат")
                    val v = toSafeCppIdentifier(rawV)
                    val rawInp = block.getField("input", "датчик")
                    val inp = toSafeCppIdentifier(rawInp)
                    val fl = block.getField("from_low", "0")
                    val fh = block.getField("from_high", "1023")
                    val tl = block.getField("to_low", "0")
                    val th = block.getField("to_high", "255")
                    sb.append("${indent}$v = map($inp, $fl, $fh, $tl, $th);\n")
                }

                // Serial
                BlockType.ARDUINO_SERIAL_BEGIN -> {
                    val b = block.getField("baud", "9600")
                    sb.append("${indent}Serial.begin($b);\n")
                }
                BlockType.ARDUINO_SERIAL_PRINTLN -> {
                    val t = block.getField("text", "\"Привет!\"")
                    sb.append("${indent}Serial.println($t);\n")
                }
                BlockType.ARDUINO_SERIAL_PRINT_VAR -> {
                    val rawV = block.getField("var", "датчик")
                    val v = toSafeCppIdentifier(rawV)
                    sb.append("${indent}Serial.println($v);\n")
                }

                // Displays: LCD 1602 (I2C)
                BlockType.ARDUINO_LCD_INIT -> {
                    val addr = block.getField("addr", "0x27")
                    sb.append("${indent}lcd.init(); // Инициализация LCD $addr\n")
                    sb.append("${indent}lcd.backlight();\n")
                }
                BlockType.ARDUINO_LCD_CLEAR -> {
                    sb.append("${indent}lcd.clear(); // Очистить экран LCD\n")
                }
                BlockType.ARDUINO_LCD_PRINT -> {
                    val t = block.getField("text", "\"Hello\"")
                    val col = block.getField("col", "0")
                    val row = block.getField("row", "0")
                    sb.append("${indent}lcd.setCursor($col, $row);\n")
                    sb.append("${indent}lcd.print($t);\n")
                }
                BlockType.ARDUINO_LCD_PRINT_VAR -> {
                    val rawV = block.getField("var", "датчик")
                    val v = toSafeCppIdentifier(rawV)
                    val col = block.getField("col", "0")
                    val row = block.getField("row", "0")
                    sb.append("${indent}lcd.setCursor($col, $row);\n")
                    sb.append("${indent}lcd.print($v);\n")
                }
                BlockType.ARDUINO_LCD_BACKLIGHT -> {
                    val state = block.getField("state", "ВКЛ")
                    if (state == "ВКЛ" || state.equals("ON", ignoreCase = true)) {
                        sb.append("${indent}lcd.backlight();\n")
                    } else {
                        sb.append("${indent}lcd.noBacklight();\n")
                    }
                }

                // Displays: OLED SSD1306 (128x64)
                BlockType.ARDUINO_OLED_INIT -> {
                    val addr = block.getField("addr", "0x3C")
                    sb.append("${indent}oled.begin(SSD1306_SWITCHCAPVCC, $addr);\n")
                    sb.append("${indent}oled.clearDisplay();\n")
                }
                BlockType.ARDUINO_OLED_CLEAR -> {
                    sb.append("${indent}oled.clearDisplay();\n")
                    sb.append("${indent}oled.display();\n")
                }
                BlockType.ARDUINO_OLED_PRINT -> {
                    val t = block.getField("text", "\"OLED\"")
                    val x = block.getField("x", "0")
                    val y = block.getField("y", "0")
                    val sz = block.getField("size", "1")
                    sb.append("${indent}oled.setTextSize($sz);\n")
                    sb.append("${indent}oled.setCursor($x, $y);\n")
                    sb.append("${indent}oled.print($t);\n")
                    sb.append("${indent}oled.display();\n")
                }
                BlockType.ARDUINO_OLED_PRINT_VAR -> {
                    val rawV = block.getField("var", "датчик")
                    val v = toSafeCppIdentifier(rawV)
                    val x = block.getField("x", "0")
                    val y = block.getField("y", "0")
                    val sz = block.getField("size", "1")
                    sb.append("${indent}oled.setTextSize($sz);\n")
                    sb.append("${indent}oled.setCursor($x, $y);\n")
                    sb.append("${indent}oled.print($v);\n")
                    sb.append("${indent}oled.display();\n")
                }

                // Displays: TM1637 (4-digit 7-segment)
                BlockType.ARDUINO_TM1637_INIT -> {
                    sb.append("${indent}tm1637.setBrightness(0x0f);\n")
                }
                BlockType.ARDUINO_TM1637_NUMBER -> {
                    val num = block.getField("num", "1234")
                    val safeNum = if (num.matches(Regex("^-?\\d+$"))) num else toSafeCppIdentifier(num)
                    sb.append("${indent}tm1637.showNumberDec($safeNum, true); // Показать число на TM1637\n")
                }
                BlockType.ARDUINO_TM1637_CLEAR -> {
                    sb.append("${indent}tm1637.clear();\n")
                }

                else -> {}
            }
        }
        return sb.toString()
    }
}
