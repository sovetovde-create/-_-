package com.example.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage
import com.example.model.Block
import com.example.model.BlockType
import com.example.model.Project
import com.example.model.SampleProjects
import org.json.JSONArray
import org.json.JSONObject

class ProjectRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("pyblocks_projects", Context.MODE_PRIVATE)

    fun getProjects(): List<Project> {
        val jsonStr = prefs.getString("saved_projects", null)
        if (jsonStr.isNullOrEmpty()) {
            val defaults = SampleProjects.all
            saveProjects(defaults)
            return defaults
        }
        return try {
            val loaded = deserializeProjects(jsonStr)
            val filtered = loaded.filterNot { it.id.startsWith("preset_") }
            if (filtered.isEmpty()) {
                val defaults = SampleProjects.all
                saveProjects(defaults)
                defaults
            } else {
                if (filtered.size != loaded.size) {
                    saveProjects(filtered)
                }
                filtered
            }
        } catch (e: Exception) {
            SampleProjects.all
        }
    }

    fun saveProjects(projects: List<Project>) {
        val jsonStr = serializeProjects(projects)
        prefs.edit().putString("saved_projects", jsonStr).apply()
    }

    fun getLanguage(): AppLanguage {
        val code = prefs.getString("app_language", AppLanguage.DEFAULT.code) ?: AppLanguage.DEFAULT.code
        return AppLanguage.fromCode(code)
    }

    fun saveLanguage(language: AppLanguage) {
        prefs.edit().putString("app_language", language.code).apply()
    }

    fun saveProject(project: Project): List<Project> {
        val current = getProjects().toMutableList()
        val index = current.indexOfFirst { it.id == project.id }
        if (index >= 0) {
            current[index] = project.copy(updatedAt = System.currentTimeMillis())
        } else {
            current.add(0, project.copy(updatedAt = System.currentTimeMillis()))
        }
        saveProjects(current)
        return current
    }

    fun deleteProject(projectId: String): List<Project> {
        val current = getProjects().filterNot { it.id == projectId }
        saveProjects(current)
        return current
    }

    private fun serializeProjects(projects: List<Project>): String {
        val array = JSONArray()
        for (p in projects) {
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            obj.put("description", p.description)
            obj.put("type", p.type.name)
            obj.put("updatedAt", p.updatedAt)
            obj.put("blocks", serializeBlocks(p.blocks))
            array.put(obj)
        }
        return array.toString()
    }

    private fun serializeBlocks(blocks: List<Block>): JSONArray {
        val array = JSONArray()
        for (b in blocks) {
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("type", b.type.name)

            val fieldsObj = JSONObject()
            for ((k, v) in b.fields) {
                fieldsObj.put(k, v)
            }
            obj.put("fields", fieldsObj)

            if (b.nestedBlocks.isNotEmpty()) {
                val nestedObj = JSONObject()
                for ((k, v) in b.nestedBlocks) {
                    val singleArr = serializeBlocks(listOf(v))
                    if (singleArr.length() > 0) {
                        nestedObj.put(k, singleArr.getJSONObject(0))
                    }
                }
                obj.put("nestedBlocks", nestedObj)
            }

            if (b.children.isNotEmpty()) {
                obj.put("children", serializeBlocks(b.children))
            }
            if (b.secondaryChildren.isNotEmpty()) {
                obj.put("secondaryChildren", serializeBlocks(b.secondaryChildren))
            }
            array.put(obj)
        }
        return array
    }

    private fun deserializeProjects(jsonStr: String): List<Project> {
        val array = JSONArray(jsonStr)
        val list = mutableListOf<Project>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.getString("id")
            val name = obj.getString("name")
            val desc = obj.optString("description", "")
            val typeStr = obj.optString("type", "PYTHON")
            val type = try {
                com.example.model.ProjectType.valueOf(typeStr)
            } catch (e: Exception) {
                com.example.model.ProjectType.PYTHON
            }
            val updated = obj.optLong("updatedAt", System.currentTimeMillis())
            val blocksArray = obj.getJSONArray("blocks")
            val blocks = deserializeBlocks(blocksArray)
            list.add(Project(id, name, desc, blocks, type, updated))
        }
        return list
    }

    private fun deserializeBlocks(array: JSONArray): List<Block> {
        val list = mutableListOf<Block>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.getString("id")
            val typeStr = obj.getString("type")
            val type = try {
                BlockType.valueOf(typeStr)
            } catch (e: Exception) {
                BlockType.ADD_NOTE
            }

            val fieldsMap = mutableMapOf<String, String>()
            if (obj.has("fields")) {
                val fieldsObj = obj.getJSONObject("fields")
                val keys = fieldsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    fieldsMap[k] = fieldsObj.getString(k)
                }
            }

            val nestedMap = mutableMapOf<String, Block>()
            if (obj.has("nestedBlocks")) {
                val nestedObj = obj.getJSONObject("nestedBlocks")
                val keys = nestedObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val childObj = nestedObj.getJSONObject(k)
                    val wrapperArr = JSONArray().apply { put(childObj) }
                    val deserialized = deserializeBlocks(wrapperArr)
                    if (deserialized.isNotEmpty()) {
                        nestedMap[k] = deserialized[0]
                    }
                }
            }

            val children = if (obj.has("children")) {
                deserializeBlocks(obj.getJSONArray("children"))
            } else {
                emptyList()
            }

            val secondaryChildren = if (obj.has("secondaryChildren")) {
                deserializeBlocks(obj.getJSONArray("secondaryChildren"))
            } else {
                emptyList()
            }

            list.add(Block(id, type, fieldsMap, nestedMap, children, secondaryChildren))
        }
        return list
    }
}
