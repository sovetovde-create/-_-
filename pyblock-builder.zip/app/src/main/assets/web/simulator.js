// Live Interactive Simulator for Python & Arduino in Web

const Simulator = {
  isRunning: false,
  intervalId: null,

  // Arduino state
  state: {
    pin13: false,
    servoAngle: 90,
    motorASpeed: 0,
    motorADir: 'stop',
    motorBSpeed: 0,
    motorBDir: 'stop',
    lcdBacklight: true,
    lcdLine1: '                ',
    lcdLine2: '                ',
    oledLines: [],
    tm1637Value: '----',
    buttonPressed: false,
    potentiometer: 512,
    ultrasonicCm: 25,
    serialLogs: []
  },

  // Python console
  pythonLogs: [],

  start(blocks, isArduino) {
    this.stop();
    this.isRunning = true;
    if (isArduino) {
      this.runArduinoLoop(blocks);
    } else {
      this.runPythonCode(blocks);
    }
  },

  stop() {
    this.isRunning = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.state.motorASpeed = 0;
    this.state.motorBSpeed = 0;
    this.updateUI();
  },

  runPythonCode(blocks) {
    this.pythonLogs.push('>>> Python 3.11 Interactive Session');
    for (const b of blocks) {
      const f = b.fields || {};
      if (b.type === 'SAY') {
        let clean = (f.text || '').replace(/^["']|["']$/g, '');
        this.pythonLogs.push(clean);
      } else if (b.type === 'ASK_INPUT') {
        let clean = (f.prompt || 'Input: ').replace(/^["']|["']$/g, '');
        this.pythonLogs.push(clean + ' User_Test');
      } else if (b.type === 'SET_VAR') {
        this.pythonLogs.push(`[Variable] ${f.var} = ${f.val}`);
      } else if (b.type === 'API_GET') {
        this.pythonLogs.push(`[API GET] Status: 200 OK -> IP: 192.168.1.100`);
      } else if (b.type === 'SQLITE_EXECUTE') {
        this.pythonLogs.push(`[SQLite] Query executed: ${f.sql}`);
      }
    }
    this.updateUI();
  },

  runArduinoLoop(blocks) {
    this.state.serialLogs.push('--- Arduino Uno Initialized (9600 baud) ---');

    let step = 0;
    this.intervalId = setInterval(() => {
      if (!this.isRunning) return;

      const b = blocks[step % blocks.length];
      if (b) {
        const f = b.fields || {};
        switch (b.type) {
          case 'ARDUINO_DIGITAL_WRITE_HIGH':
            if (f.pin === '13') this.state.pin13 = true;
            break;
          case 'ARDUINO_DIGITAL_WRITE_LOW':
            if (f.pin === '13') this.state.pin13 = false;
            break;
          case 'ARDUINO_SERVO_WRITE':
            this.state.servoAngle = parseInt(f.angle || '90', 10);
            break;
          case 'ARDUINO_L298N_MOTOR_A':
            this.state.motorASpeed = parseInt(f.speed || '255', 10);
            this.state.motorADir = f.dir || 'Forward';
            break;
          case 'ARDUINO_L298N_STOP_ALL':
            this.state.motorASpeed = 0;
            this.state.motorBSpeed = 0;
            break;
          case 'ARDUINO_LCD_PRINT':
            let txt = (f.text || '').replace(/^["']|["']$/g, '');
            if (f.row === '1') {
              this.state.lcdLine2 = txt.padEnd(16, ' ');
            } else {
              this.state.lcdLine1 = txt.padEnd(16, ' ');
            }
            break;
          case 'ARDUINO_LCD_CLEAR':
            this.state.lcdLine1 = '                ';
            this.state.lcdLine2 = '                ';
            break;
          case 'ARDUINO_LCD_BACKLIGHT':
            this.state.lcdBacklight = (f.state === 'ON');
            break;
          case 'ARDUINO_OLED_PRINT':
            let otxt = (f.text || '').replace(/^["']|["']$/g, '');
            if (this.state.oledLines.length >= 4) this.state.oledLines.shift();
            this.state.oledLines.push(otxt);
            break;
          case 'ARDUINO_OLED_CLEAR':
            this.state.oledLines = [];
            break;
          case 'ARDUINO_TM1637_NUMBER':
            this.state.tm1637Value = (f.num || '0000').slice(-4).padStart(4, ' ');
            break;
          case 'ARDUINO_SERIAL_PRINTLN':
            let stxt = (f.text || '').replace(/^["']|["']$/g, '');
            this.state.serialLogs.push(stxt);
            if (this.state.serialLogs.length > 20) this.state.serialLogs.shift();
            break;
          default:
            break;
        }
      }

      step++;
      this.updateUI();
    }, 600);
  },

  updateUI() {
    // Pin 13 LED
    const pin13El = document.getElementById('pin13-led');
    if (pin13El) {
      if (this.state.pin13) {
        pin13El.classList.add('active');
      } else {
        pin13El.classList.remove('active');
      }
    }

    // LCD 1602
    const lcdGlass = document.getElementById('sim-lcd-glass');
    if (lcdGlass) {
      if (this.state.lcdBacklight) {
        lcdGlass.classList.remove('off');
      } else {
        lcdGlass.classList.add('off');
      }
      lcdGlass.innerHTML = `<div>${this.escapeHtml(this.state.lcdLine1)}</div><div>${this.escapeHtml(this.state.lcdLine2)}</div>`;
    }

    // OLED 0.96
    const oledGlass = document.getElementById('sim-oled-glass');
    if (oledGlass) {
      oledGlass.innerHTML = this.state.oledLines.map(l => `<div>${this.escapeHtml(l)}</div>`).join('') || '<div style="opacity:0.5;">SSD1306 Ready (128x64)</div>';
    }

    // TM1637
    const tm1637Glass = document.getElementById('sim-tm1637-glass');
    if (tm1637Glass) {
      tm1637Glass.textContent = this.state.tm1637Value;
    }

    // Servo
    const servoAngleText = document.getElementById('servo-angle-text');
    if (servoAngleText) {
      servoAngleText.textContent = `${this.state.servoAngle}°`;
    }

    // Motors
    const motorWheel = document.getElementById('motor-wheel-a');
    if (motorWheel) {
      if (this.state.motorASpeed > 0) {
        motorWheel.style.animation = 'spin 0.4s linear infinite';
      } else {
        motorWheel.style.animation = 'none';
      }
    }

    // Serial monitor
    const serialLogBox = document.getElementById('sim-serial-log');
    if (serialLogBox) {
      serialLogBox.innerHTML = this.state.serialLogs.map(l => `<div>&gt; ${this.escapeHtml(l)}</div>`).join('');
      serialLogBox.scrollTop = serialLogBox.scrollHeight;
    }

    // Python console
    const consoleBox = document.getElementById('sim-python-console');
    if (consoleBox) {
      consoleBox.innerHTML = this.pythonLogs.map(l => `<div>${this.escapeHtml(l)}</div>`).join('');
      consoleBox.scrollTop = consoleBox.scrollHeight;
    }
  },

  escapeHtml(str) {
    return (str || '').replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }
};
