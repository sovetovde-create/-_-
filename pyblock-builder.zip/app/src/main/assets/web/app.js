// Main Application Logic for PyBlocks Web Edition (HTML5 / CSS / JS)

const App = {
  currentProject: {
    id: 'proj_1',
    name: 'Arduino Smart Robot & Displays',
    type: 'ARDUINO', // 'PYTHON' or 'ARDUINO'
    blocks: [
      { id: 'b1', type: 'ARDUINO_LCD_INIT', fields: { addr: '0x27', cols: '16', rows: '2' } },
      { id: 'b2', type: 'ARDUINO_LCD_PRINT', fields: { text: '"Hello Arduino!"', col: '0', row: '0' } },
      { id: 'b3', type: 'ARDUINO_OLED_INIT', fields: { width: '128', height: '64', addr: '0x3C' } },
      { id: 'b4', type: 'ARDUINO_OLED_PRINT', fields: { text: '"PyBlocks OLED"', x: '0', y: '0', size: '1' } },
      { id: 'b5', type: 'ARDUINO_TM1637_INIT', fields: { clk: '2', dio: '3' } },
      { id: 'b6', type: 'ARDUINO_TM1637_NUMBER', fields: { num: '2026' } },
      { id: 'b7', type: 'ARDUINO_L298N_MOTOR_A', fields: { in1: '5', in2: '6', dir: 'Forward', speed: '255' } },
      { id: 'b8', type: 'ARDUINO_SERVO_WRITE', fields: { pin: '9', angle: '90' } },
      { id: 'b9', type: 'ARDUINO_SERIAL_PRINTLN', fields: { text: '"Robot Ready!"' } }
    ]
  },

  selectedTab: 'workspace', // 'workspace', 'code', 'simulator'
  selectedCategory: null,
  searchQuery: '',
  installedLibs: new Set(['math']),

  init() {
    this.renderHeader();
    this.renderCategories();
    this.renderBlocksList();
    this.renderCanvas();
    this.bindEvents();
    this.applyLocalization();
  },

  setMode(type) {
    this.currentProject.type = type;
    if (type === 'PYTHON') {
      this.currentProject.blocks = [
        { id: 'p1', type: 'SAY', fields: { text: '"Hello from Python 3!"' } },
        { id: 'p2', type: 'ASK_INPUT', fields: { prompt: '"Enter name: "', var: 'name' } },
        { id: 'p3', type: 'SET_VAR', fields: { var: 'counter', val: '10' } }
      ];
    } else {
      this.currentProject.blocks = [
        { id: 'a1', type: 'ARDUINO_LCD_INIT', fields: { addr: '0x27', cols: '16', rows: '2' } },
        { id: 'a2', type: 'ARDUINO_LCD_PRINT', fields: { text: '"Hello Arduino!"', col: '0', row: '0' } },
        { id: 'a3', type: 'ARDUINO_OLED_INIT', fields: { width: '128', height: '64', addr: '0x3C' } },
        { id: 'a4', type: 'ARDUINO_OLED_PRINT', fields: { text: '"PyBlocks OLED"', x: '0', y: '0', size: '1' } },
        { id: 'a5', type: 'ARDUINO_TM1637_NUMBER', fields: { num: '2026' } }
      ];
    }
    this.selectedCategory = null;
    this.renderHeader();
    this.renderCategories();
    this.renderBlocksList();
    this.renderCanvas();
  },

  switchTab(tab) {
    this.selectedTab = tab;
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tab);
    });
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.toggle('active', content.id === `${tab}-tab`);
    });

    if (tab === 'code') {
      this.renderCodeView();
    } else if (tab === 'simulator') {
      this.renderSimulatorView();
    }
  },

  renderHeader() {
    const isArduino = this.currentProject.type === 'ARDUINO';
    const modeBadge = document.getElementById('mode-badge');
    if (modeBadge) {
      modeBadge.textContent = isArduino ? 'Arduino Uno' : 'Python 3';
    }

    const tabConvert = document.getElementById('tab-convert-btn');
    if (tabConvert) {
      tabConvert.textContent = isArduino ? Localization.get('convert') : Localization.get('python');
    }
    const tabSim = document.getElementById('tab-sim-btn');
    if (tabSim) {
      tabSim.textContent = isArduino ? Localization.get('board_test') : Localization.get('console');
    }
    const runBtn = document.getElementById('header-run-btn');
    if (runBtn) {
      runBtn.textContent = isArduino ? Localization.get('code') : Localization.get('start');
    }
  },

  renderCategories() {
    const isArduino = this.currentProject.type === 'ARDUINO';
    const catList = document.getElementById('categories-list');
    if (!catList) return;

    catList.innerHTML = '';
    const relevantCats = Object.values(BlockCategories).filter(cat => {
      if (isArduino) return cat.isArduino;
      if (cat.isArduino) return false;
      if (cat.isExt && !this.installedLibs.has(cat.lib)) return false;
      return true;
    });

    relevantCats.forEach((cat, index) => {
      const el = document.createElement('div');
      el.className = `cat-item ${this.selectedCategory === cat.id || (!this.selectedCategory && index === 0) ? 'active' : ''}`;
      el.onclick = () => {
        this.selectedCategory = cat.id;
        document.querySelectorAll('.cat-item').forEach(c => c.classList.remove('active'));
        el.classList.add('active');
        this.renderBlocksList();
      };

      const dot = document.createElement('div');
      dot.className = 'cat-dot';
      dot.style.background = cat.color;
      dot.innerHTML = '●';

      const label = document.createElement('span');
      const lang = Localization.currentLang;
      label.textContent = cat.name[lang] || cat.name.en;

      el.appendChild(dot);
      el.appendChild(label);
      catList.appendChild(el);
    });

    if (!this.selectedCategory && relevantCats.length > 0) {
      this.selectedCategory = relevantCats[0].id;
    }
  },

  renderBlocksList() {
    const isArduino = this.currentProject.type === 'ARDUINO';
    const listEl = document.getElementById('palette-blocks');
    if (!listEl) return;
    listEl.innerHTML = '';

    const lang = Localization.currentLang;
    const entries = Object.entries(BlockDefinitions).filter(([key, def]) => {
      const cat = BlockCategories[def.category];
      if (isArduino && !cat.isArduino) return false;
      if (!isArduino && cat.isArduino) return false;
      if (this.selectedCategory && def.category !== this.selectedCategory) return false;
      if (this.searchQuery) {
        const title = (def.name[lang] || def.name.en).toLowerCase();
        return title.includes(this.searchQuery.toLowerCase());
      }
      return true;
    });

    entries.forEach(([type, def]) => {
      const cat = BlockCategories[def.category];
      const card = document.createElement('div');
      card.className = 'block-card';
      card.style.background = cat.color;

      const title = def.name[lang] || def.name.en;
      card.innerHTML = `<span>${title}</span><span>+</span>`;
      card.onclick = () => this.addBlock(type);
      listEl.appendChild(card);
    });
  },

  addBlock(type) {
    const def = BlockDefinitions[type];
    if (!def) return;
    const fields = {};
    (def.fields || []).forEach(f => {
      fields[f.key] = f.default;
    });
    this.currentProject.blocks.push({
      id: 'b_' + Date.now() + Math.random().toString(36).substring(2, 6),
      type: type,
      fields: fields
    });
    this.renderCanvas();
  },

  renderCanvas() {
    const stack = document.getElementById('blocks-stack');
    if (!stack) return;
    stack.innerHTML = '';
    const lang = Localization.currentLang;

    this.currentProject.blocks.forEach((b, index) => {
      const def = BlockDefinitions[b.type];
      if (!def) return;
      const cat = BlockCategories[def.category] || { color: '#E53935' };

      const el = document.createElement('div');
      el.className = 'canvas-block';
      el.style.background = cat.color;

      // Header row
      const header = document.createElement('div');
      header.className = 'canvas-block-header';
      const title = def.name[lang] || def.name.en;
      header.innerHTML = `<span>${title}</span>`;

      // Actions (Move up, Move down, Delete)
      const actions = document.createElement('div');
      actions.className = 'canvas-block-actions';
      actions.innerHTML = `
        <button onclick="App.moveBlock(${index}, -1)" title="Up">▲</button>
        <button onclick="App.moveBlock(${index}, 1)" title="Down">▼</button>
        <button onclick="App.deleteBlock(${index})" title="Delete">✕</button>
      `;
      header.appendChild(actions);
      el.appendChild(header);

      // Fields row
      if (def.fields && def.fields.length > 0) {
        const fieldsRow = document.createElement('div');
        fieldsRow.className = 'canvas-block-fields';
        def.fields.forEach(f => {
          const val = b.fields[f.key] || f.default;
          const input = document.createElement('input');
          input.className = 'block-pill-input';
          input.value = val;
          input.placeholder = f.label;
          input.oninput = (e) => {
            b.fields[f.key] = e.target.value;
          };
          fieldsRow.appendChild(input);
        });
        el.appendChild(fieldsRow);
      }

      stack.appendChild(el);
    });

    if (this.currentProject.blocks.length === 0) {
      stack.innerHTML = '<div style="text-align:center; padding:40px; color:#94a3b8; font-weight:600;">No blocks added yet. Click blocks from the left palette to add!</div>';
    }
  },

  moveBlock(index, dir) {
    const target = index + dir;
    if (target < 0 || target >= this.currentProject.blocks.length) return;
    const temp = this.currentProject.blocks[index];
    this.currentProject.blocks[index] = this.currentProject.blocks[target];
    this.currentProject.blocks[target] = temp;
    this.renderCanvas();
  },

  deleteBlock(index) {
    this.currentProject.blocks.splice(index, 1);
    this.renderCanvas();
  },

  renderCodeView() {
    const isArduino = this.currentProject.type === 'ARDUINO';
    const editor = document.getElementById('code-content');
    if (!editor) return;
    if (isArduino) {
      editor.textContent = CodeGenerator.generateArduino(this.currentProject.blocks);
    } else {
      editor.textContent = CodeGenerator.generatePython(this.currentProject.blocks);
    }
  },

  renderSimulatorView() {
    const isArduino = this.currentProject.type === 'ARDUINO';
    const pySim = document.getElementById('sim-python-container');
    const ardSim = document.getElementById('sim-arduino-container');
    if (pySim) pySim.style.display = isArduino ? 'none' : 'block';
    if (ardSim) ardSim.style.display = isArduino ? 'block' : 'none';
  },

  toggleRun() {
    if (Simulator.isRunning) {
      Simulator.stop();
      const btn = document.getElementById('sim-run-btn');
      if (btn) btn.textContent = 'RUN';
    } else {
      const isArduino = this.currentProject.type === 'ARDUINO';
      this.switchTab('simulator');
      Simulator.start(this.currentProject.blocks, isArduino);
      const btn = document.getElementById('sim-run-btn');
      if (btn) btn.textContent = 'STOP';
    }
  },

  openSettings() {
    const modal = document.getElementById('settings-modal');
    if (modal) modal.classList.add('active');
  },

  closeSettings() {
    const modal = document.getElementById('settings-modal');
    if (modal) modal.classList.remove('active');
  },

  setLanguage(code) {
    Localization.setLanguage(code);
    this.applyLocalization();
    this.renderCategories();
    this.renderBlocksList();
    this.renderCanvas();
    this.closeSettings();
  },

  applyLocalization() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      el.textContent = Localization.get(key);
    });
    this.renderHeader();
  },

  openLibrariesModal() {
    const modal = document.getElementById('libraries-modal');
    if (modal) modal.classList.add('active');
  },

  closeLibrariesModal() {
    const modal = document.getElementById('libraries-modal');
    if (modal) modal.classList.remove('active');
  },

  addLibrary(lib) {
    this.installedLibs.add(lib);
    this.addBlock('IMPORT_LIB');
    this.closeLibrariesModal();
    this.renderCategories();
    this.renderBlocksList();
  },

  exportWebZip() {
    alert("PyBlocks Web Edition:\nAll files (index.html, style.css, app.js, blocks.js, generator.js, simulator.js, localization.js) are completely standalone and ready to deploy on any web server or GitHub Pages!");
  },

  bindEvents() {
    const searchInput = document.getElementById('palette-search-input');
    if (searchInput) {
      searchInput.oninput = (e) => {
        this.searchQuery = e.target.value;
        this.renderBlocksList();
      };
    }
  }
};

window.addEventListener('DOMContentLoaded', () => {
  App.init();
});
