// Block Definitions & Categories for PyBlocks Web

const BlockCategories = {
  // PYTHON
  DIALOG: { id: 'DIALOG', name: { en: 'Dialogue', ru: 'Общение', uk: 'Спілкування' }, color: '#4C97FF' },
  VARIABLES: { id: 'VARIABLES', name: { en: 'Variables', ru: 'Память', uk: 'Пам\'ять' }, color: '#FF8C1A' },
  CONTROL: { id: 'CONTROL', name: { en: 'Control', ru: 'Управление', uk: 'Керування' }, color: '#FFAB19' },
  MATH: { id: 'MATH', name: { en: 'Math', ru: 'Математика', uk: 'Математика' }, color: '#59C059' },
  EXT_NEURAL: { id: 'EXT_NEURAL', name: { en: 'Neural Nets', ru: 'Нейросети', uk: 'Нейромережі' }, color: '#9C27B0', isExt: true, lib: 'neural' },
  EXT_API: { id: 'EXT_API', name: { en: 'API & Web', ru: 'API & Сеть', uk: 'API & Мережа' }, color: '#00BCD4', isExt: true, lib: 'api' },
  EXT_TURTLE: { id: 'EXT_TURTLE', name: { en: 'Turtle Graphics', ru: 'Графика Turtle', uk: 'Графіка Turtle' }, color: '#009688', isExt: true, lib: 'turtle' },
  EXT_SQLITE: { id: 'EXT_SQLITE', name: { en: 'SQLite DB', ru: 'База SQLite', uk: 'База SQLite' }, color: '#3F51B5', isExt: true, lib: 'sqlite' },

  // ARDUINO
  ARDUINO_LEDS: { id: 'ARDUINO_LEDS', name: { en: 'LEDs & Pins', ru: 'Лампочки', uk: 'Лампочки' }, color: '#E53935', isArduino: true },
  ARDUINO_SERVO: { id: 'ARDUINO_SERVO', name: { en: 'Servo', ru: 'Сервопривод', uk: 'Сервопривід' }, color: '#FB8C00', isArduino: true },
  ARDUINO_MOTORS: { id: 'ARDUINO_MOTORS', name: { en: 'Motors & L298N', ru: 'Моторы и Драйверы', uk: 'Мотори і Драйвери' }, color: '#43A047', isArduino: true },
  ARDUINO_SENSORS: { id: 'ARDUINO_SENSORS', name: { en: 'Sensors', ru: 'Датчики', uk: 'Датчики' }, color: '#00ACC1', isArduino: true },
  ARDUINO_BUZZER: { id: 'ARDUINO_BUZZER', name: { en: 'Buzzer', ru: 'Зуммер', uk: 'Зумер' }, color: '#8E24AA', isArduino: true },
  ARDUINO_DISPLAYS: { id: 'ARDUINO_DISPLAYS', name: { en: 'Displays', ru: 'Экраны', uk: 'Екрани' }, color: '#00897B', isArduino: true },
  ARDUINO_CONTROL: { id: 'ARDUINO_CONTROL', name: { en: 'Control', ru: 'Управление', uk: 'Керування' }, color: '#F59E0B', isArduino: true },
  ARDUINO_SERIAL: { id: 'ARDUINO_SERIAL', name: { en: 'Serial PC', ru: 'Связь ПК', uk: 'Зв\'язок ПК' }, color: '#3949AB', isArduino: true }
};

const BlockDefinitions = {
  // === PYTHON BLOCKS ===
  'SAY': {
    category: 'DIALOG',
    name: { en: 'Say (print text)', ru: 'Сказать (написать)', uk: 'Сказати (написати)' },
    fields: [{ key: 'text', label: 'text', default: '"Hello World!"' }]
  },
  'ASK_INPUT': {
    category: 'DIALOG',
    name: { en: 'Ask and save answer', ru: 'Спросить и сохранить ответ', uk: 'Запитати і зберегти відповідь' },
    fields: [
      { key: 'prompt', label: 'question', default: '"What is your name? "' },
      { key: 'var', label: 'save to', default: 'name' }
    ]
  },
  'SET_VAR': {
    category: 'VARIABLES',
    name: { en: 'Set variable = value', ru: 'Запомнить: переменная = значение', uk: 'Запам\'ятати: змінна = значення' },
    fields: [
      { key: 'var', label: 'var', default: 'counter' },
      { key: 'val', label: 'val', default: '10' }
    ]
  },
  'CHANGE_VAR': {
    category: 'VARIABLES',
    name: { en: 'Change variable by', ru: 'Увеличить переменную на', uk: 'Збільшити змінну на' },
    fields: [
      { key: 'var', label: 'var', default: 'counter' },
      { key: 'by', label: 'by', default: '1' }
    ]
  },
  'REPEAT': {
    category: 'CONTROL',
    name: { en: 'Repeat count times', ru: 'Повторить раз:', uk: 'Повторити разів:' },
    fields: [{ key: 'times', label: 'times', default: '5' }]
  },
  'WAIT': {
    category: 'CONTROL',
    name: { en: 'Wait seconds', ru: 'Подождать секунд', uk: 'Зачекати секунд' },
    fields: [{ key: 'sec', label: 'sec', default: '1' }]
  },

  // Python Extensions
  'IMPORT_LIB': {
    category: 'CONTROL',
    name: { en: 'Import Python library', ru: 'Импортировать библиотеку', uk: 'Імпортувати бібліотеку' },
    fields: [{ key: 'lib', label: 'lib', default: 'torch' }]
  },
  'NN_CREATE': {
    category: 'EXT_NEURAL',
    name: { en: 'Neural Net: Create MLP Model', ru: 'Нейросеть: создать модель', uk: 'Нейромережа: створити модель' },
    fields: [
      { key: 'layers', label: 'layers', default: '[4, 8, 2]' },
      { key: 'var', label: 'model', default: 'model' }
    ]
  },
  'API_GET': {
    category: 'EXT_API',
    name: { en: 'API: HTTP GET request', ru: 'API: отправить запрос GET', uk: 'API: надіслати запит GET' },
    fields: [
      { key: 'url', label: 'url', default: '"https://api.ipify.org?format=json"' },
      { key: 'var', label: 'save to', default: 'response' }
    ]
  },
  'TURTLE_FORWARD': {
    category: 'EXT_TURTLE',
    name: { en: 'Turtle: Move forward', ru: 'Turtle: шаг вперед', uk: 'Turtle: крок вперед' },
    fields: [{ key: 'steps', label: 'steps', default: '100' }]
  },
  'SQLITE_EXECUTE': {
    category: 'EXT_SQLITE',
    name: { en: 'SQLite: Execute SQL query', ru: 'SQLite: выполнить SQL', uk: 'SQLite: виконати SQL' },
    fields: [
      { key: 'sql', label: 'SQL', default: '"CREATE TABLE users (id INT, name TEXT)"' }
    ]
  },

  // === ARDUINO BLOCKS ===
  // LEDs & Pins
  'ARDUINO_DIGITAL_WRITE_HIGH': {
    category: 'ARDUINO_LEDS',
    name: { en: 'Turn LED ON (HIGH)', ru: 'Включить лампочку (HIGH)', uk: 'Увімкнути лампочку (HIGH)' },
    fields: [{ key: 'pin', label: 'Pin', default: '13' }]
  },
  'ARDUINO_DIGITAL_WRITE_LOW': {
    category: 'ARDUINO_LEDS',
    name: { en: 'Turn LED OFF (LOW)', ru: 'Выключить лампочку (LOW)', uk: 'Вимкнути лампочку (LOW)' },
    fields: [{ key: 'pin', label: 'Pin', default: '13' }]
  },
  'ARDUINO_PWM_BRIGHTNESS': {
    category: 'ARDUINO_LEDS',
    name: { en: 'LED Brightness (PWM 0-255)', ru: 'Яркость лампочки (ШИМ 0-255)', uk: 'Яскравість лампочки (ШІМ 0-255)' },
    fields: [
      { key: 'pin', label: 'Pin', default: '9' },
      { key: 'val', label: 'PWM (0-255)', default: '180' }
    ]
  },

  // Servo
  'ARDUINO_SERVO_WRITE': {
    category: 'ARDUINO_SERVO',
    name: { en: 'Servo: Rotate to angle (0-180°)', ru: 'Повернуть сервопривод на угол', uk: 'Повернути сервопривід на кут' },
    fields: [
      { key: 'pin', label: 'Pin', default: '9' },
      { key: 'angle', label: 'Angle (°)', default: '90' }
    ]
  },

  // Motors (L298N)
  'ARDUINO_L298N_MOTOR_A': {
    category: 'ARDUINO_MOTORS',
    name: { en: 'L298N Motor A (IN1, IN2, Speed)', ru: 'L298N Мотор A (IN1, IN2, Скорость)', uk: 'L298N Мотор A (IN1, IN2, Швидкість)' },
    fields: [
      { key: 'in1', label: 'IN1', default: '5' },
      { key: 'in2', label: 'IN2', default: '6' },
      { key: 'dir', label: 'Dir', default: 'Forward' },
      { key: 'speed', label: 'Speed', default: '255' }
    ]
  },
  'ARDUINO_L298N_MOTOR_B': {
    category: 'ARDUINO_MOTORS',
    name: { en: 'L298N Motor B (IN3, IN4, Speed)', ru: 'L298N Мотор B (IN3, IN4, Скорость)', uk: 'L298N Мотор B (IN3, IN4, Швидкість)' },
    fields: [
      { key: 'in3', label: 'IN3', default: '7' },
      { key: 'in4', label: 'IN4', default: '8' },
      { key: 'dir', label: 'Dir', default: 'Forward' },
      { key: 'speed', label: 'Speed', default: '255' }
    ]
  },
  'ARDUINO_L298N_STOP_ALL': {
    category: 'ARDUINO_MOTORS',
    name: { en: 'L298N: Stop all motors', ru: 'L298N: Остановить все моторы', uk: 'L298N: Зупинити всі мотори' },
    fields: []
  },

  // Displays (LCD 1602, OLED SSD1306, TM1637)
  'ARDUINO_LCD_INIT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'LCD 1602: Init screen (I2C 0x27)', ru: 'LCD 1602: Подключить экран (I2C 0x27)', uk: 'LCD 1602: Підключити екран (I2C 0x27)' },
    fields: [
      { key: 'addr', label: 'Address', default: '0x27' },
      { key: 'cols', label: 'Cols', default: '16' },
      { key: 'rows', label: 'Rows', default: '2' }
    ]
  },
  'ARDUINO_LCD_PRINT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'LCD 1602: Print text at (col, row)', ru: 'LCD 1602: Напечатать текст на строке', uk: 'LCD 1602: Надрукувати текст на рядку' },
    fields: [
      { key: 'text', label: 'text', default: '"Hello Arduino!"' },
      { key: 'col', label: 'col', default: '0' },
      { key: 'row', label: 'row', default: '0' }
    ]
  },
  'ARDUINO_LCD_CLEAR': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'LCD 1602: Clear screen', ru: 'LCD 1602: Очистить экран', uk: 'LCD 1602: Очистити екран' },
    fields: []
  },
  'ARDUINO_LCD_BACKLIGHT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'LCD 1602: Backlight (ON / OFF)', ru: 'LCD 1602: Подсветка (ВКЛ / ВЫКЛ)', uk: 'LCD 1602: Підсвічування (Увімк / Вимк)' },
    fields: [{ key: 'state', label: 'state', default: 'ON' }]
  },

  'ARDUINO_OLED_INIT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'OLED 0.96": Init SSD1306 (128x64)', ru: 'OLED 0.96": Подключить SSD1306', uk: 'OLED 0.96": Підключити SSD1306' },
    fields: [
      { key: 'width', label: 'width', default: '128' },
      { key: 'height', label: 'height', default: '64' },
      { key: 'addr', label: 'I2C', default: '0x3C' }
    ]
  },
  'ARDUINO_OLED_PRINT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'OLED 0.96": Print text (X, Y)', ru: 'OLED 0.96": Напечатать текст (X, Y)', uk: 'OLED 0.96": Надрукувати текст (X, Y)' },
    fields: [
      { key: 'text', label: 'text', default: '"PyBlocks OLED"' },
      { key: 'x', label: 'X', default: '0' },
      { key: 'y', label: 'Y', default: '0' },
      { key: 'size', label: 'Font Size', default: '1' }
    ]
  },
  'ARDUINO_OLED_CLEAR': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'OLED 0.96": Clear screen', ru: 'OLED 0.96": Очистить экран', uk: 'OLED 0.96": Очистити екран' },
    fields: []
  },

  'ARDUINO_TM1637_INIT': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'TM1637: Connect 7-Seg (CLK, DIO)', ru: 'TM1637: Подключить 7-сегментный', uk: 'TM1637: Підключити 7-сегментний' },
    fields: [
      { key: 'clk', label: 'CLK', default: '2' },
      { key: 'dio', label: 'DIO', default: '3' }
    ]
  },
  'ARDUINO_TM1637_NUMBER': {
    category: 'ARDUINO_DISPLAYS',
    name: { en: 'TM1637: Show number (0-9999)', ru: 'TM1637: Показать число', uk: 'TM1637: Показати число' },
    fields: [{ key: 'num', label: 'Number', default: '2026' }]
  },

  // Sensors
  'ARDUINO_ANALOG_READ': {
    category: 'ARDUINO_SENSORS',
    name: { en: 'Read analog sensor (A0-A5)', ru: 'Считать аналоговый датчик (A0-A5)', uk: 'Зчитати аналоговий датчик (A0-A5)' },
    fields: [
      { key: 'pin', label: 'Pin', default: 'A0' },
      { key: 'var', label: 'save to', default: 'sensorVal' }
    ]
  },
  'ARDUINO_ULTRASONIC': {
    category: 'ARDUINO_SENSORS',
    name: { en: 'HC-SR04 Ultrasonic sensor (cm)', ru: 'Дальномер HC-SR04 (см)', uk: 'Далекомір HC-SR04 (см)' },
    fields: [
      { key: 'trig', label: 'Trig', default: '7' },
      { key: 'echo', label: 'Echo', default: '6' },
      { key: 'var', label: 'save to', default: 'distCm' }
    ]
  },

  // Buzzer
  'ARDUINO_BUZZER_TONE': {
    category: 'ARDUINO_BUZZER',
    name: { en: 'Play buzzer tone (freq & dur)', ru: 'Издать звук (частота Гц и время)', uk: 'Видати звук (частота Гц і час)' },
    fields: [
      { key: 'pin', label: 'Pin', default: '8' },
      { key: 'freq', label: 'Freq (Hz)', default: '440' },
      { key: 'dur', label: 'Dur (ms)', default: '500' }
    ]
  },

  // Serial
  'ARDUINO_SERIAL_PRINTLN': {
    category: 'ARDUINO_SERIAL',
    name: { en: 'Serial: Print line to monitor', ru: 'Serial: Отправить строку в монитор', uk: 'Serial: Надіслати рядок у монітор' },
    fields: [{ key: 'text', label: 'text', default: '"Sensor ok"' }]
  },

  // Delay
  'ARDUINO_DELAY': {
    category: 'ARDUINO_CONTROL',
    name: { en: 'Wait milliseconds (ms)', ru: 'Подождать миллисекунд (мс)', uk: 'Зачекати мілісекунд (мс)' },
    fields: [{ key: 'ms', label: 'ms', default: '1000' }]
  }
};
