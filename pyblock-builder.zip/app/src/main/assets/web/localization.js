// Localization dictionary for PyBlocks Web (HTML/JS/CSS)
const Localization = {
  currentLang: 'en', // default is English as requested

  languages: [
    { code: 'en', title: 'English', native: 'English', flag: '🇬🇧' },
    { code: 'ru', title: 'Russian', native: 'Русский', flag: '🇷🇺' },
    { code: 'uk', title: 'Ukrainian', native: 'Українська', flag: '🇺🇦' }
  ],

  strings: {
    en: {
      settings: 'Settings',
      language: 'Language',
      select_language: 'Select App Language',
      default_language: 'Default language is English',
      close: 'Close',
      blocks: 'Blocks',
      python: 'Python',
      console: 'Console',
      convert: 'Convert',
      board_test: 'Board Test',
      code: 'CODE',
      start: 'START',
      stop: 'STOP',
      reset: 'Reset',
      rename: 'Rename',
      delete: 'Delete',
      duplicate: 'Duplicate',
      create_project: 'Create Project',
      project_name: 'Project Name',
      save: 'Save',
      add: 'Add',
      libraries: 'Libraries',
      add_library: 'Add Python Library',
      installed: 'Installed',
      all: 'All',
      search: 'Search blocks...',
      displays_and_screens: 'Displays & Screens',
      lcd_display: 'LCD 1602 Display (I2C 0x27)',
      oled_display: 'OLED 0.96" SSD1306 (128x64)',
      tm1637_display: '7-Segment 4-Digit TM1637',
      backlight: 'Backlight',
      motor_driver: 'L298N Dual Motor Driver',
      servo: 'Servo Motor (Pin 9)',
      buzzer: 'Buzzer (Pin 8)',
      sensors: 'Interactive Sensors',
      button_pin: 'Button (Pin 2)',
      ultrasonic: 'HC-SR04 Ultrasonic (cm)',
      potentiometer: 'Potentiometer (A0)',
      serial_monitor: 'Serial Monitor (9600 baud)',
      export_web: 'Download Web Version'
    },
    ru: {
      settings: 'Настройки',
      language: 'Язык',
      select_language: 'Выберите язык приложения',
      default_language: 'По умолчанию установлен английский язык',
      close: 'Закрыть',
      blocks: 'Блоки',
      python: 'Python',
      console: 'Консоль',
      convert: 'Конвертировать',
      board_test: 'Тест платы',
      code: 'КОД',
      start: 'СТАРТ',
      stop: 'СТОП',
      reset: 'Сброс',
      rename: 'Переименовать',
      delete: 'Удалить',
      duplicate: 'Дублировать',
      create_project: 'Создать проект',
      project_name: 'Название проекта',
      save: 'Сохранить',
      add: 'Добавить',
      libraries: 'Библиотеки',
      add_library: 'Добавить библиотеку Python',
      installed: 'Установлено',
      all: 'Все',
      search: 'Поиск команд...',
      displays_and_screens: 'Экраны и Дисплеи',
      lcd_display: 'Дисплей LCD 1602 (I2C 0x27)',
      oled_display: 'OLED 0.96" SSD1306 (128x64)',
      tm1637_display: '7-Сегментный 4-разрядный TM1637',
      backlight: 'Подсветка',
      motor_driver: 'Драйвер моторов L298N',
      servo: 'Сервопривод (Пин 9)',
      buzzer: 'Зуммер (Пин 8)',
      sensors: 'Интерактивные датчики',
      button_pin: 'Кнопка (Пин 2)',
      ultrasonic: 'Дальномер HC-SR04 (см)',
      potentiometer: 'Потенциометр (A0)',
      serial_monitor: 'Монитор порта (9600 бод)',
      export_web: 'Скачать веб-версию'
    },
    uk: {
      settings: 'Налаштування',
      language: 'Мова',
      select_language: 'Оберіть мову додатку',
      default_language: 'За замовчуванням встановлена англійська мова',
      close: 'Закрити',
      blocks: 'Блоки',
      python: 'Python',
      console: 'Консоль',
      convert: 'Конвертувати',
      board_test: 'Тест плати',
      code: 'КОД',
      start: 'СТАРТ',
      stop: 'СТОП',
      reset: 'Скидання',
      rename: 'Перейменувати',
      delete: 'Видалити',
      duplicate: 'Дублювати',
      create_project: 'Створити проєкт',
      project_name: 'Назва проєкту',
      save: 'Зберегти',
      add: 'Додати',
      libraries: 'Бібліотеки',
      add_library: 'Додати бібліотеку Python',
      installed: 'Встановлено',
      all: 'Всі',
      search: 'Пошук команд...',
      displays_and_screens: 'Екрани та Дисплеї',
      lcd_display: 'Дисплей LCD 1602 (I2C 0x27)',
      oled_display: 'OLED 0.96" SSD1306 (128x64)',
      tm1637_display: '7-Сегментний 4-розрядний TM1637',
      backlight: 'Підсвічування',
      motor_driver: 'Драйвер моторів L298N',
      servo: 'Сервопривід (Пін 9)',
      buzzer: 'Зумер (Пін 8)',
      sensors: 'Інтерактивні датчики',
      button_pin: 'Кнопка (Пін 2)',
      ultrasonic: 'Далекомір HC-SR04 (см)',
      potentiometer: 'Потенціометр (A0)',
      serial_monitor: 'Монітор порту (9600 бод)',
      export_web: 'Завантажити веб-версію'
    }
  },

  get(key) {
    const dict = this.strings[this.currentLang] || this.strings.en;
    return dict[key] || this.strings.en[key] || key;
  },

  setLanguage(code) {
    if (this.strings[code]) {
      this.currentLang = code;
      try {
        localStorage.setItem('pyblocks_lang', code);
      } catch (e) {}
    }
  },

  init() {
    try {
      const saved = localStorage.getItem('pyblocks_lang');
      if (saved && this.strings[saved]) {
        this.currentLang = saved;
      }
    } catch (e) {}
  }
};

Localization.init();
