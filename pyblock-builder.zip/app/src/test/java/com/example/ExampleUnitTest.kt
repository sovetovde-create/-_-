package com.example

import com.example.model.Block
import com.example.model.BlockType
import com.example.model.CodeGenerator
import com.example.model.SampleProjects
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCodeGenerator_generatesValidPython() {
    val blocks = listOf(
      Block(type = BlockType.SET_VARIABLE, fields = mapOf("var" to "x", "value" to "10")),
      Block(type = BlockType.IF_SIMPLE, fields = mapOf("condition" to "x > 5"), children = listOf(
        Block(type = BlockType.SAY, fields = mapOf("text" to "\"Greater\""))
      ))
    )
    val pythonCode = CodeGenerator.generatePython(blocks)
    assertTrue(pythonCode.contains("x = 10"))
    assertTrue(pythonCode.contains("if x > 5:"))
    assertTrue(pythonCode.contains("print(\"Greater\")"))
  }

  @Test
  fun testSampleProjects_notEmpty() {
    val projects = SampleProjects.all
    assertTrue(projects.isNotEmpty())
    assertTrue(projects.any { it.name.contains("Знакомство") })
  }
}
